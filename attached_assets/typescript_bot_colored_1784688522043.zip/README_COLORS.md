# 🎨 Telegram Bot — Colored Button Guide

## কিভাবে Green / Blue / Red বাটন হলো?

Telegram Bot API-তে বাটনে `style` property ব্যবহার করে রং দেওয়া হয়।  
এটা **aiogram** (Python) এবং **grammy** (TypeScript/Node.js) — দুটোতেই কাজ করে।

---

## ✅ মাত্র ৩টি রং কাজ করে

| রং | Style Value | কোথায় লাগে |
|----|-------------|------------|
| 🟢 সবুজ | `"success"` | Confirm, Earn, Watch Ads |
| 🔴 লাল  | `"danger"`  | Cancel, Withdrawal, Adult |
| 🔵 নীল  | `"primary"` | Profile, Info, Links |
| ⚪ ধূসর | (কিছু না)   | Default/neutral বাটন |

> ⚠️ এই ৩টির বাইরে অন্য কোনো `style` দিলে Telegram reject করবে।

---

## 🐍 Python (aiogram) — কিভাবে লিখতে হয়

### Reply Keyboard (নিচের বড় বাটন)
```python
from aiogram.types import KeyboardButton, ReplyKeyboardMarkup
from aiogram.utils.keyboard import ReplyKeyboardBuilder

builder = ReplyKeyboardBuilder()
builder.add(KeyboardButton(text="✅ Confirm", style="success"))   # 🟢 সবুজ
builder.add(KeyboardButton(text="❌ Cancel",  style="danger"))    # 🔴 লাল
builder.add(KeyboardButton(text="🔵 Info",    style="primary"))   # 🔵 নীল
builder.add(KeyboardButton(text="⚪ Skip"))                       # ধূসর
keyboard = builder.as_markup(resize_keyboard=True)
```

### Inline Keyboard (message-এর নিচের বাটন)
```python
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder

builder = InlineKeyboardBuilder()
builder.add(InlineKeyboardButton(text="✅ Yes", callback_data="yes", style="success"))
builder.add(InlineKeyboardButton(text="❌ No",  callback_data="no",  style="danger"))
keyboard = builder.as_markup()
```

---

## 📦 TypeScript (grammy) — কিভাবে লিখতে হয়

### Reply Keyboard (নিচের বড় বাটন)
```typescript
import { Keyboard } from "grammy";

const kb = new Keyboard()
  .add({ text: "✅ Confirm", style: "success" })   // 🟢 সবুজ
  .add({ text: "❌ Cancel",  style: "danger"  })   // 🔴 লাল
  .row()
  .add({ text: "🔵 Info",   style: "primary" })    // 🔵 নীল
  .resized().persistent();
```

### Inline Keyboard (message-এর নিচের বাটন)
```typescript
import { InlineKeyboard } from "grammy";

const kb = new InlineKeyboard()
  .add({ text: "✅ Yes", callback_data: "yes", style: "success" })
  .add({ text: "❌ No",  callback_data: "no",  style: "danger"  })
  .row()
  .add({ text: "🔗 Link", url: "https://example.com", style: "primary" });
```

---

## 📁 Python Bot — কোন কোন ফাইল লাগে?

```
bot.py              ← মূল bot ফাইল (সব কোড এখানে)
```

### চালানোর জন্য:
```bash
# Install
pip install aiogram

# Environment variable সেট করো
export BOT_TOKEN="তোমার_bot_token"

# চালাও
python bot.py
```

---

## 📁 TypeScript Bot — কোন কোন ফাইল লাগে?

```
artifacts/api-server/src/bot/
├── index.ts        ← মূল bot logic (keyboard + handlers)
├── db.ts           ← Database functions
└── languages.ts    ← Multi-language strings

lib/db/src/schema/  ← Database table schemas
artifacts/api-server/src/
├── app.ts          ← Express app setup
└── index.ts        ← Entry point
```

### চালানোর জন্য:
```bash
# Install
pnpm install

# Environment variables
TELEGRAM_BOT_TOKEN=তোমার_token
DATABASE_URL=postgresql://...
BOT_USERNAME=তোমার_bot_username

# চালাও
pnpm run dev
```

---

## ⚠️ সাধারণ সমস্যা

| সমস্যা | কারণ | সমাধান |
|--------|------|--------|
| `TelegramUnauthorizedError` | Token ভুল বা revoked | BotFather থেকে নতুন token নাও |
| Button রং নেই | পুরনো Telegram app | App update করো |
| `invalid button style` | ভুল style value | শুধু `success`/`danger`/`primary` ব্যবহার করো |

---

*Telegram Bot Colored Buttons — aiogram + grammy*
