import { Bot, Keyboard, InlineKeyboard, session } from "grammy";
import type { Context, SessionFlavor } from "grammy";
import { logger } from "../lib/logger.js";
import {
  getOrCreateUser, getUserByTelegramId, setUserLanguage,
  getTodayAds, startAdWatch, completeAdWatch,
  getOrCreateDailyTask, markTaskShare, claimDailyBonus,
  getReferralStats, createWithdrawal,
  getActiveChannels, recordChannelJoin, getChannelJoin,
  getWarningCount,
  getNumSetting, seedSettings, saveUserPanelMsg,
  updateUserWallet, updateUserName,
} from "./db.js";
import { tr_, LANGUAGES, bar, type Lang } from "./languages.js";

// ─── Session ──────────────────────────────────────────────────────────────────

interface SessionData {
  state?:
    | "selecting_wallet_method"    // on wallet select keyboard (profile flow)
    | "selecting_withdraw_method"  // on withdraw method keyboard
    | "await_wallet_address"       // typing wallet number/address
    | "await_wallet_confirm"       // confirming wallet save
    | "await_withdraw_address"     // typing withdrawal address
    | "await_withdraw_confirm"     // confirming withdrawal
    | "await_name_update";         // typing new name
  withdrawMethod?: string;
  walletMethod?:   string;
  pendingAddress?: string;
  panelMsgId?:     number;
}
type BotCtx = Context & SessionFlavor<SessionData>;

// ─── Env ──────────────────────────────────────────────────────────────────────

let BOT_USERNAME   = process.env.BOT_USERNAME   ?? "";
const ADULT_BOT_LINK = process.env.ADULT_BOT_LINK ?? "https://t.me/example_adult_bot";
const MOVIE_BOT_LINK = process.env.MOVIE_BOT_LINK ?? "https://t.me/example_movie_bot";
const ADS_URL        = process.env.ADS_URL        ?? "https://www.google.com";

// ─── Payment Methods ──────────────────────────────────────────────────────────

const WITHDRAW_METHODS = [
  { id: "bkash",      emoji: "📱", label: "bKash",          country: "🇧🇩" },
  { id: "nagad",      emoji: "💚", label: "Nagad",          country: "🇧🇩" },
  { id: "rocket",     emoji: "🚀", label: "Rocket",         country: "🇧🇩" },
  { id: "upi",        emoji: "🇮🇳", label: "UPI",           country: "🇮🇳" },
  { id: "paytm",      emoji: "🔵", label: "Paytm",          country: "🇮🇳" },
  { id: "binancepay", emoji: "💛", label: "Binance Pay",    country: "🌐" },
  { id: "usdt_trc20", emoji: "💎", label: "USDT TRC20",     country: "🌐" },
  { id: "usdt_bep20", emoji: "💜", label: "USDT BEP20",     country: "🌐" },
  { id: "bnb",        emoji: "🟡", label: "BNB (BSC)",      country: "🌐" },
  { id: "paypal",     emoji: "🔷", label: "PayPal",         country: "🌐" },
  { id: "ton",        emoji: "💠", label: "TON",            country: "🌐" },
  { id: "ltc",        emoji: "⚪", label: "Litecoin (LTC)", country: "🌐" },
] as const;

function getMethodLabel(id: string): string {
  const m = WITHDRAW_METHODS.find(x => x.id === id);
  return m ? `${m.emoji} ${m.label}` : id.toUpperCase();
}

// Returns the method id for a keyboard button text like "🇧🇩 📱 bKash"
function getMethodIdFromBtnText(text: string): string | undefined {
  return WITHDRAW_METHODS.find(m => text === `${m.country} ${m.emoji} ${m.label}`)?.id;
}

// ─── Decorative constants ─────────────────────────────────────────────────────

const HTML = { parse_mode: "HTML" as const };
const SEP  = "━━━━━━━━━━━━━━━━━━━━━";
const LINE = "─────────────────────";

// ─── Reply Keyboard builders ──────────────────────────────────────────────────
// ALL navigation is via Reply Keyboard (bottom keyboard).
// Inline buttons are only used for: language select, external links, ad watch/verify, task actions.

function mainMenu(lang: Lang): Keyboard {
  return new Keyboard()
    .add({ text: tr_(lang, "profileBtn"),    style: "primary"  })
    .add({ text: tr_(lang, "earnBtn"),       style: "success"  }).row()
    .add({ text: tr_(lang, "withdrawalBtn"), style: "danger"   })
    .add({ text: tr_(lang, "referralBtn"),   style: "primary"  }).row()
    .add({ text: tr_(lang, "adultBtn2"),     style: "danger"   })
    .add({ text: tr_(lang, "movieSeriesBtn"),style: "success"  })
    .resized().persistent();
}

function profileSubMenu(lang: Lang): Keyboard {
  return new Keyboard()
    .add({ text: tr_(lang, "setWalletBtn"),  style: "primary" }).row()
    .add({ text: tr_(lang, "changeLangBtn"), style: "success" }).row()
    .add({ text: tr_(lang, "mainMenuBtn"),   style: "danger"  })
    .resized().persistent();
}

function walletSelectMenu(lang: Lang): Keyboard {
  const kbd = new Keyboard();
  for (let i = 0; i < WITHDRAW_METHODS.length; i += 2) {
    const a = WITHDRAW_METHODS[i]!;
    const b = WITHDRAW_METHODS[i + 1];
    if (b) {
      kbd.add({ text: `${a.country} ${a.emoji} ${a.label}`, style: "primary" })
         .add({ text: `${b.country} ${b.emoji} ${b.label}`, style: "success" }).row();
    } else {
      kbd.add({ text: `${a.country} ${a.emoji} ${a.label}`, style: "primary" }).row();
    }
  }
  kbd.add({ text: tr_(lang, "backBtn"),    style: "danger"  }).row()
     .add({ text: tr_(lang, "mainMenuBtn"), style: "danger" });
  return kbd.resized().persistent();
}

function walletConfirmMenu(lang: Lang): Keyboard {
  return new Keyboard()
    .add({ text: tr_(lang, "confirmBtn"),     style: "success" }).row()
    .add({ text: tr_(lang, "changeMethodBtn"),style: "primary" }).row()
    .add({ text: tr_(lang, "mainMenuBtn"),    style: "danger"  })
    .resized().persistent();
}

function earnSubMenu(lang: Lang): Keyboard {
  return new Keyboard()
    .add({ text: tr_(lang, "watchAdsBtn"),   style: "success" })
    .add({ text: tr_(lang, "dailyTasksBtn"), style: "primary" }).row()
    .add({ text: tr_(lang, "mainMenuBtn"),   style: "danger"  })
    .resized().persistent();
}

function singleHomeMenu(lang: Lang): Keyboard {
  return new Keyboard()
    .add({ text: tr_(lang, "mainMenuBtn"), style: "primary" })
    .resized().persistent();
}

function withdrawMethodMenu(lang: Lang): Keyboard {
  const kbd = new Keyboard();
  for (let i = 0; i < WITHDRAW_METHODS.length; i += 2) {
    const a = WITHDRAW_METHODS[i]!;
    const b = WITHDRAW_METHODS[i + 1];
    if (b) {
      kbd.add({ text: `${a.country} ${a.emoji} ${a.label}`, style: "primary" })
         .add({ text: `${b.country} ${b.emoji} ${b.label}`, style: "success" }).row();
    } else {
      kbd.add({ text: `${a.country} ${a.emoji} ${a.label}`, style: "primary" }).row();
    }
  }
  kbd.add({ text: tr_(lang, "mainMenuBtn"), style: "danger" });
  return kbd.resized().persistent();
}

function withdrawConfirmMenu(lang: Lang): Keyboard {
  return new Keyboard()
    .add({ text: tr_(lang, "confirmBtn"),     style: "success" }).row()
    .add({ text: tr_(lang, "changeMethodBtn"),style: "primary" }).row()
    .add({ text: tr_(lang, "mainMenuBtn"),    style: "danger"  })
    .resized().persistent();
}

function cancelMenu(lang: Lang): Keyboard {
  return new Keyboard()
    .add({ text: tr_(lang, "cancelBtn"),  style: "danger"  }).row()
    .add({ text: tr_(lang, "mainMenuBtn"),style: "primary" })
    .resized().persistent();
}

// ─── Inline keyboard for language select ─────────────────────────────────────

function langKeyboard(): InlineKeyboard {
  return new InlineKeyboard()
    .add({ text: "🇬🇧 English",   callback_data: "lang:en", style: "primary" })
    .add({ text: "🇧🇩 বাংলা",     callback_data: "lang:bn", style: "success" })
    .add({ text: "🇮🇳 हिन्दी",   callback_data: "lang:hi", style: "danger"  }).row()
    .add({ text: "🇸🇦 العربية",   callback_data: "lang:ar", style: "primary" })
    .add({ text: "🇷🇺 Русский",   callback_data: "lang:ru", style: "success" })
    .add({ text: "🇹🇷 Türkçe",    callback_data: "lang:tr", style: "danger"  }).row()
    .add({ text: "🇵🇰 اردو",      callback_data: "lang:ur", style: "primary" })
    .add({ text: "🇮🇳 ਪੰਜਾਬੀ",   callback_data: "lang:pa", style: "success" })
    .add({ text: "🇮🇩 Indonesia", callback_data: "lang:id", style: "danger"  }).row()
    .add({ text: "🇫🇷 Français",  callback_data: "lang:fr", style: "primary" })
    .add({ text: "🇪🇸 Español",   callback_data: "lang:es", style: "success" })
    .add({ text: "🇧🇷 Português", callback_data: "lang:pt", style: "danger"  });
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function getReferralLink(referralCode: string): string {
  if (!BOT_USERNAME) return "⚠️ Bot username not configured";
  return `https://t.me/${BOT_USERNAME}?start=ref_${referralCode}`;
}

/** Delete previous panel + user message, send fresh panel with updated keyboard */
async function showPanel(
  ctx: BotCtx,
  text: string,
  extra: Record<string, unknown> = {},
): Promise<void> {
  const chatId = ctx.chat?.id;
  if (!chatId) return;
  const tgId = String(ctx.from?.id ?? "");

  if (ctx.session.panelMsgId) {
    await ctx.api.deleteMessage(chatId, ctx.session.panelMsgId).catch(() => {});
    ctx.session.panelMsgId = undefined;
  }
  if (ctx.message?.message_id) {
    await ctx.api.deleteMessage(chatId, ctx.message.message_id).catch(() => {});
  }

  const sent = await ctx.api.sendMessage(chatId, text, { ...HTML, ...extra } as any);
  ctx.session.panelMsgId = sent.message_id;
  if (tgId) await saveUserPanelMsg(tgId, sent.message_id).catch(() => {});
}

function clearState(ctx: BotCtx) {
  ctx.session.state          = undefined;
  ctx.session.withdrawMethod = undefined;
  ctx.session.walletMethod   = undefined;
  ctx.session.pendingAddress = undefined;
}

function buildLangSetMessage(lang: Lang): string {
  const MAP: Record<Lang, { flag: string; native: string; english: string }> = {
    en: { flag: "🇬🇧", native: "Language set to English!",       english: "English"    },
    bn: { flag: "🇧🇩", native: "ভাষা বাংলায় সেট হয়েছে!",         english: "Bengali"    },
    hi: { flag: "🇮🇳", native: "भाषा हिंदी में सेट हो गई!",        english: "Hindi"      },
    ar: { flag: "🇸🇦", native: "تم تعيين اللغة إلى العربية!",     english: "Arabic"     },
    ru: { flag: "🇷🇺", native: "Язык установлен на русский!",     english: "Russian"    },
    tr: { flag: "🇹🇷", native: "Dil Türkçe olarak ayarlandı!",    english: "Turkish"    },
    ur: { flag: "🇵🇰", native: "زبان اردو پر سیٹ ہو گئی!",      english: "Urdu"       },
    pa: { flag: "🇮🇳", native: "ਭਾਸ਼ਾ ਪੰਜਾਬੀ ਵਿੱਚ ਸੈੱਟ ਹੋਈ!",     english: "Punjabi"    },
    id: { flag: "🇮🇩", native: "Bahasa diatur ke Indonesia!",    english: "Indonesian" },
    fr: { flag: "🇫🇷", native: "Langue réglée sur le français!", english: "French"     },
    es: { flag: "🇪🇸", native: "¡Idioma establecido en Español!", english: "Spanish"   },
    pt: { flag: "🇧🇷", native: "Idioma definido para Português!", english: "Portuguese" },
  };
  const { flag, native, english } = MAP[lang];
  return `${flag} <b>${native}</b>
<code>${SEP}</code>
✅ <b>${english}</b> selected successfully
🌐 All bot messages will now appear in your language
<code>${LINE}</code>
⚡ <i>Loading your personal dashboard...</i>`;
}

// ─── Main ──────────────────────────────────────────────────────────────────────

export async function startBot() {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) { logger.warn("TELEGRAM_BOT_TOKEN not set — bot will not start"); return; }

  await seedSettings();

  const bot = new Bot<BotCtx>(token);
  bot.use(session({ initial: (): SessionData => ({}) }));
  bot.catch((err) => logger.error({ err: err.error }, "Bot error"));

  await bot.init();
  if (!BOT_USERNAME) BOT_USERNAME = bot.botInfo.username;
  logger.info({ username: BOT_USERNAME }, "Bot username resolved");

  // ── Channel helpers (need bot in scope) ─────────────────────────────────

  async function checkChannelMembershipByTgId(chatId: string, tgUserId: number): Promise<boolean> {
    try {
      const member = await bot.api.getChatMember(chatId, tgUserId);
      return ["member", "administrator", "creator"].includes(member.status);
    } catch { return false; }
  }

  async function checkChannelMembership(channelId: number, tgUserId: number): Promise<boolean> {
    const { db, channelsTable } = await import("@workspace/db");
    const { eq } = await import("drizzle-orm");
    const rows = await db.select().from(channelsTable).where(eq(channelsTable.id, channelId)).limit(1);
    if (!rows[0]) return false;
    return checkChannelMembershipByTgId(rows[0].telegramId, tgUserId);
  }

  async function getUnjoinedChannels(
    userId: number, tgUserId: number,
    channels: Array<{ id: number; telegramId: string; name: string; url: string; reward: string }>,
  ) {
    const unjoined: typeof channels = [];
    for (const ch of channels) {
      const join = await getChannelJoin(userId, ch.id);
      if (join?.rewardPaid) continue;
      if (!await checkChannelMembershipByTgId(ch.telegramId, tgUserId)) unjoined.push(ch);
    }
    return unjoined;
  }

  // ── Panel helpers (need bot session in scope) ────────────────────────────

  type FullUser = Awaited<ReturnType<typeof getUserByTelegramId>>;

  async function handleProfilePanel(ctx: BotCtx, lang: Lang, dbUser: NonNullable<FullUser>) {
    const [maxAds, warnLimit, minWd] = await Promise.all([
      getNumSetting("max_ads_per_day", 10),
      getNumSetting("warn_limit", 3),
      getNumSetting("min_withdrawal", 1.00),
    ]);
    const [todayAds, referrals, warnings] = await Promise.all([
      getTodayAds(dbUser.id),
      getReferralStats(dbUser.id),
      getWarningCount(dbUser.id),
    ]);
    const joined = new Date(dbUser.createdAt).toLocaleDateString("en-GB");
    const walletLine = (dbUser as any).walletMethod
      ? `\n💳 Wallet:        <b>${getMethodLabel((dbUser as any).walletMethod)}</b>`
      : `\n💳 Wallet:        <i>Not set — tap Set Wallet below</i>`;

    const text = tr_(lang, "profileMsg", {
      id:          dbUser.id,
      name:        dbUser.firstName,
      lang:        LANGUAGES[lang],
      balance:     Number(dbUser.balance).toFixed(2),
      totalEarned: Number(dbUser.totalEarned).toFixed(2),
      adsToday:    todayAds?.count ?? 0,
      maxAds,
      referrals:   referrals.count,
      warnings,
      warnLimit,
      minWd:       minWd.toFixed(2),
      joined,
    }) + walletLine;

    await showPanel(ctx, text, { reply_markup: profileSubMenu(lang) });
  }

  async function handleEarnPanel(ctx: BotCtx, lang: Lang, dbUser: NonNullable<FullUser>) {
    const [maxAds, todayAds] = await Promise.all([
      getNumSetting("max_ads_per_day", 10),
      getTodayAds(dbUser.id),
    ]);
    const watched     = todayAds?.count ?? 0;
    const remaining   = Math.max(maxAds - watched, 0);
    const todayEarned = parseFloat(String(todayAds?.todayEarned ?? "0")).toFixed(2);
    const balance     = parseFloat(String(dbUser.balance)).toFixed(2);
    const progress    = bar(watched, maxAds);

    const msg = remaining > 0
      ? tr_(lang, "earnMsg", { bar: progress, watched, max: maxAds, todayEarned, balance, remaining })
      : tr_(lang, "earnDone", { balance, max: maxAds });

    const inlineKbd = new InlineKeyboard();
    if (remaining > 0) inlineKbd.add({ text: tr_(lang, "watchAd"), callback_data: "watch_ad", style: "success" }).row();
    inlineKbd.add({ text: tr_(lang, "refresh"), callback_data: "refresh_balance", style: "primary" });

    // Show earn stats panel (with inline ad-watch button)
    await showPanel(ctx, msg, { reply_markup: inlineKbd });

    // Send a navigation message with the earn sub-menu keyboard
    const chatId = ctx.chat?.id;
    if (chatId) {
      const nav = await ctx.api.sendMessage(chatId,
        `<code>${LINE}</code>\n👇 <b>Choose from the menu below</b>`,
        { ...HTML, reply_markup: earnSubMenu(lang) }
      );
      ctx.session.panelMsgId = nav.message_id;
      const tgId = String(ctx.from?.id ?? "");
      if (tgId) await saveUserPanelMsg(tgId, nav.message_id).catch(() => {});
    }
  }

  async function handleEarnPanelEdit(ctx: BotCtx, lang: Lang, dbUser: NonNullable<FullUser>) {
    const [maxAds, todayAds] = await Promise.all([
      getNumSetting("max_ads_per_day", 10),
      getTodayAds(dbUser.id),
    ]);
    const watched     = todayAds?.count ?? 0;
    const remaining   = Math.max(maxAds - watched, 0);
    const todayEarned = parseFloat(String(todayAds?.todayEarned ?? "0")).toFixed(2);
    const balance     = parseFloat(String(dbUser.balance)).toFixed(2);
    const progress    = bar(watched, maxAds);

    const msg = remaining > 0
      ? tr_(lang, "earnMsg", { bar: progress, watched, max: maxAds, todayEarned, balance, remaining })
      : tr_(lang, "earnDone", { balance, max: maxAds });

    const inlineKbd = new InlineKeyboard();
    if (remaining > 0) inlineKbd.add({ text: tr_(lang, "watchAd"), callback_data: "watch_ad", style: "success" }).row();
    inlineKbd.add({ text: tr_(lang, "refresh"), callback_data: "refresh_balance", style: "primary" });

    await ctx.editMessageText(msg, { ...HTML, reply_markup: inlineKbd }).catch(() => {});
  }

  async function buildTaskPanelData(dbUser: NonNullable<FullUser>, lang: Lang, tgUserId: number) {
    const [task, todayAds, adsThreshold, dailyBonus, referralReward, channels] = await Promise.all([
      getOrCreateDailyTask(dbUser.id),
      getTodayAds(dbUser.id),
      getNumSetting("ads_task_threshold", 5),
      getNumSetting("daily_bonus", 0.20),
      getNumSetting("referral_reward", 0.05),
      getActiveChannels(),
    ]);

    const adsWatched = todayAds?.count ?? 0;
    const taskObj = { ...task, adsDone: task.adsDone || adsWatched >= adsThreshold };
    const shareReward = (dailyBonus * 0.25).toFixed(2);
    const adsReward   = (dailyBonus * 0.25).toFixed(2);
    const chanReward  = channels.length > 0 ? (dailyBonus * 0.25 / channels.length).toFixed(2) : "0.05";
    const done = tr_(lang, "taskDonePrefix");
    const pend = tr_(lang, "taskPendingPrefix");
    const lines: string[] = [];

    lines.push(`${taskObj.adsDone ? done : pend}${tr_(lang, "taskWatchAds", { threshold: adsThreshold, reward: adsReward })}`);
    lines.push(`${taskObj.shareDone ? done : pend}${tr_(lang, "taskShare", { reward: shareReward })}`);

    const channelJoins: boolean[] = [];
    for (const ch of channels) {
      const joined = await getChannelJoin(dbUser.id, ch.id);
      channelJoins.push(!!joined?.rewardPaid);
      lines.push(`${channelJoins.at(-1) ? done : pend}${tr_(lang, "taskChannel", { name: ch.name, reward: chanReward })}`);
    }
    lines.push(`${taskObj.referralDone ? done : pend}${tr_(lang, "taskReferral", { reward: referralReward.toFixed(2) })}`);

    const totalTasks = 2 + channels.length + 1;
    let doneCount = [taskObj.adsDone, taskObj.shareDone, taskObj.referralDone].filter(Boolean).length
      + channelJoins.filter(Boolean).length;

    const msg = tr_(lang, "dailyTaskMsg", {
      tasks: lines.join("\n"), done: doneCount, total: totalTasks, bonus: dailyBonus.toFixed(2),
    });

    const kbd = new InlineKeyboard();
    if (!taskObj.shareDone) {
      const link = dbUser.referralCode ? getReferralLink(dbUser.referralCode) : "";
      if (link && !link.startsWith("⚠️"))
        kbd.add({ text: tr_(lang, "taskShareBtn"), url: `https://t.me/share/url?url=${encodeURIComponent(link)}`, style: "primary" }).row();
      kbd.add({ text: tr_(lang, "taskVerifyBtn") + " ✓ Share", callback_data: "task_share", style: "success" }).row();
    }
    for (let i = 0; i < channels.length; i++) {
      if (!channelJoins[i]) {
        const ch = channels[i]!;
        kbd.add({ text: `📢 ${ch.name}`, url: ch.url, style: "primary" }).row();
        kbd.add({ text: `${tr_(lang, "taskVerifyBtn")} — ${ch.name}`, callback_data: `task_channel:${ch.id}`, style: "success" }).row();
      }
    }
    if (doneCount >= totalTasks && !taskObj.bonusClaimed)
      kbd.add({ text: tr_(lang, "claimBonus"), callback_data: "task_claim", style: "success" });

    return { msg, kbd };
  }

  async function handleTaskPanel(ctx: BotCtx, lang: Lang, dbUser: NonNullable<FullUser>) {
    const tgUserId = ctx.from?.id ?? 0;
    const { msg, kbd } = await buildTaskPanelData(dbUser, lang, tgUserId);
    await showPanel(ctx, msg, { reply_markup: kbd });

    const chatId = ctx.chat?.id;
    if (chatId) {
      const nav = await ctx.api.sendMessage(chatId,
        `<code>${LINE}</code>\n📋 <b>Complete tasks then return to Menu</b>`,
        { ...HTML, reply_markup: singleHomeMenu(lang) }
      );
      ctx.session.panelMsgId = nav.message_id;
      const tgId = String(ctx.from?.id ?? "");
      if (tgId) await saveUserPanelMsg(tgId, nav.message_id).catch(() => {});
    }
  }

  async function handleTaskPanelEdit(ctx: BotCtx, lang: Lang, dbUser: NonNullable<FullUser>) {
    const tgUserId = ctx.from?.id ?? 0;
    const { msg, kbd } = await buildTaskPanelData(dbUser, lang, tgUserId);
    await ctx.editMessageText(msg, { ...HTML, reply_markup: kbd }).catch(() => {});
  }

  async function handleReferralPanel(ctx: BotCtx, lang: Lang, dbUser: NonNullable<FullUser>) {
    const [refReward, stats] = await Promise.all([
      getNumSetting("referral_reward", 0.05),
      getReferralStats(dbUser.id),
    ]);
    const link = dbUser.referralCode ? getReferralLink(dbUser.referralCode) : "N/A";
    const shareText = encodeURIComponent("💰 Join & earn real money watching ads!");
    const inlineKbd = new InlineKeyboard()
      .add({ text: tr_(lang, "shareLink"), url: `https://t.me/share/url?url=${encodeURIComponent(link)}&text=${shareText}`, style: "success" });

    await showPanel(ctx, tr_(lang, "referralMsg", {
      refReward: refReward.toFixed(2), count: stats.count, earned: stats.earned.toFixed(2), link,
    }), { reply_markup: inlineKbd });

    const chatId = ctx.chat?.id;
    if (chatId) {
      const nav = await ctx.api.sendMessage(chatId,
        `<code>${LINE}</code>\n👥 <b>Share your link above, then go back when done</b>`,
        { ...HTML, reply_markup: singleHomeMenu(lang) }
      );
      ctx.session.panelMsgId = nav.message_id;
      const tgId = String(ctx.from?.id ?? "");
      if (tgId) await saveUserPanelMsg(tgId, nav.message_id).catch(() => {});
    }
  }

  // ─── /start ────────────────────────────────────────────────────────────────

  bot.command("start", async (ctx) => {
    const from    = ctx.from!;
    const refCode = ctx.match?.startsWith("ref_") ? ctx.match.slice(4) : undefined;
    const dbUser  = await getOrCreateUser(
      String(from.id), from.first_name, from.last_name ?? null, from.username ?? null, refCode,
    );
    const lang   = (dbUser.language as Lang) ?? "en";
    const chatId = ctx.chat.id;
    const tgId   = String(from.id);

    clearState(ctx);

    if (ctx.session.panelMsgId) {
      await ctx.api.deleteMessage(chatId, ctx.session.panelMsgId).catch(() => {});
      ctx.session.panelMsgId = undefined;
    }
    if (dbUser.lastPanelMsgId) {
      await ctx.api.deleteMessage(chatId, dbUser.lastPanelMsgId).catch(() => {});
    }
    await ctx.deleteMessage().catch(() => {});

    const sent = await ctx.api.sendMessage(chatId, tr_(lang, "welcome"), {
      ...HTML, reply_markup: langKeyboard(),
    });
    ctx.session.panelMsgId = sent.message_id;
    await saveUserPanelMsg(tgId, sent.message_id).catch(() => {});
  });

  // ─── Language select (inline callback) ────────────────────────────────────

  bot.callbackQuery(/^lang:(.+)$/, async (ctx) => {
    const lang = ctx.match![1] as Lang;
    const tgId = String(ctx.from.id);
    await setUserLanguage(tgId, lang);
    await ctx.answerCallbackQuery();
    clearState(ctx);

    await ctx.editMessageText(buildLangSetMessage(lang), HTML).catch(() => {});

    const chatId = ctx.chat?.id;
    if (chatId) {
      const sent = await ctx.api.sendMessage(chatId, tr_(lang, "menuMsg"), {
        ...HTML, reply_markup: mainMenu(lang),
      });
      ctx.session.panelMsgId = sent.message_id;
      await saveUserPanelMsg(tgId, sent.message_id).catch(() => {});
    }
  });

  // ─── Text handler ─────────────────────────────────────────────────────────
  // All reply keyboard navigation + text input states live here.

  bot.on("message:text", async (ctx) => {
    const tgId = String(ctx.from.id);
    const text = ctx.message.text.trim();

    let dbUser = await getUserByTelegramId(tgId);
    if (!dbUser) { await ctx.reply(tr_("en", "startFirst"), HTML); return; }
    const lang = (dbUser.language as Lang) ?? "en";

    if (dbUser.isBanned) {
      await showPanel(ctx, tr_(lang, "banned"), { reply_markup: mainMenu(lang) });
      return;
    }

    // ── Global shortcuts: Cancel / Main Menu ─────────────────────────────

    if (text === tr_(lang, "cancelBtn") || text === tr_(lang, "mainMenuBtn")) {
      clearState(ctx);
      await showPanel(ctx, tr_(lang, "menuMsg"), { reply_markup: mainMenu(lang) });
      return;
    }

    // ══════════════════════════════════════════════════════════════════════
    //  STATE MACHINE
    // ══════════════════════════════════════════════════════════════════════

    // ── await_wallet_address: user typing wallet number ───────────────────

    if (ctx.session.state === "await_wallet_address") {
      const method  = ctx.session.walletMethod!;
      ctx.session.pendingAddress = text;
      ctx.session.state = "await_wallet_confirm";
      await showPanel(ctx,
        tr_(lang, "confirmWalletMsg", { method: getMethodLabel(method), address: text }),
        { reply_markup: walletConfirmMenu(lang) }
      );
      return;
    }

    // ── await_wallet_confirm: Confirm / Change Method ─────────────────────

    if (ctx.session.state === "await_wallet_confirm") {
      if (text === tr_(lang, "confirmBtn")) {
        const method  = ctx.session.walletMethod!;
        const address = ctx.session.pendingAddress!;
        clearState(ctx);
        await updateUserWallet(tgId, method, address);
        await showPanel(ctx,
          tr_(lang, "walletUpdated", { method: getMethodLabel(method), address }),
          { reply_markup: profileSubMenu(lang) }
        );
        return;
      }
      if (text === tr_(lang, "changeMethodBtn")) {
        ctx.session.state          = "selecting_wallet_method";
        ctx.session.pendingAddress = undefined;
        await showPanel(ctx, tr_(lang, "updateWalletMsg"), { reply_markup: walletSelectMenu(lang) });
        return;
      }
      // Any other text while confirming → re-show confirm panel
      await showPanel(ctx,
        tr_(lang, "confirmWalletMsg", {
          method: getMethodLabel(ctx.session.walletMethod!),
          address: ctx.session.pendingAddress!,
        }),
        { reply_markup: walletConfirmMenu(lang) }
      );
      return;
    }

    // ── await_withdraw_address: user typing withdrawal address ────────────

    if (ctx.session.state === "await_withdraw_address") {
      const method  = ctx.session.withdrawMethod!;
      ctx.session.pendingAddress = text;
      ctx.session.state = "await_withdraw_confirm";
      dbUser = (await getUserByTelegramId(tgId))!;
      const balance = Number(dbUser.balance).toFixed(2);
      await showPanel(ctx,
        tr_(lang, "confirmWdMsg", { method: getMethodLabel(method), address: text, balance }),
        { reply_markup: withdrawConfirmMenu(lang) }
      );
      return;
    }

    // ── await_withdraw_confirm: Confirm / Change Method ───────────────────

    if (ctx.session.state === "await_withdraw_confirm") {
      if (text === tr_(lang, "confirmBtn")) {
        const method  = ctx.session.withdrawMethod!;
        const address = ctx.session.pendingAddress!;
        clearState(ctx);
        dbUser = (await getUserByTelegramId(tgId))!;
        const balance = Number(dbUser.balance);
        const minWd   = await getNumSetting("min_withdrawal", 1.00);
        if (balance < minWd) {
          await showPanel(ctx, tr_(lang, "withdrawLow", { balance: balance.toFixed(2), minWd: minWd.toFixed(2) }), { reply_markup: mainMenu(lang) });
          return;
        }
        const result = await createWithdrawal(dbUser.id, balance, method, address);
        if (result.ok) {
          await showPanel(ctx, tr_(lang, "withdrawConfirm", { amount: balance.toFixed(2), method: getMethodLabel(method), address }), { reply_markup: mainMenu(lang) });
        } else if (result.reason === "pending") {
          await showPanel(ctx, tr_(lang, "withdrawPending"), { reply_markup: mainMenu(lang) });
        } else {
          await showPanel(ctx, tr_(lang, "withdrawLow", { balance: balance.toFixed(2), minWd: minWd.toFixed(2) }), { reply_markup: mainMenu(lang) });
        }
        return;
      }
      if (text === tr_(lang, "changeMethodBtn")) {
        ctx.session.state          = "selecting_withdraw_method";
        ctx.session.pendingAddress = undefined;
        dbUser = (await getUserByTelegramId(tgId))!;
        const balance = Number(dbUser.balance);
        const minWd   = await getNumSetting("min_withdrawal", 1.00);
        await showPanel(ctx, tr_(lang, "withdrawMsg", { balance: balance.toFixed(2), minWd: minWd.toFixed(2) }), { reply_markup: withdrawMethodMenu(lang) });
        return;
      }
      return; // ignore other input while confirming
    }

    // ── await_name_update: user typing new name ────────────────────────────

    if (ctx.session.state === "await_name_update") {
      const newName = text.slice(0, 64);
      clearState(ctx);
      await updateUserName(tgId, newName);
      await showPanel(ctx, tr_(lang, "nameUpdated", { name: newName }), { reply_markup: profileSubMenu(lang) });
      return;
    }

    // ══════════════════════════════════════════════════════════════════════
    //  PAYMENT METHOD BUTTON DETECTION
    //  (same button text used in both wallet-select and withdraw-method menus)
    // ══════════════════════════════════════════════════════════════════════

    const methodId = getMethodIdFromBtnText(text);
    if (methodId) {
      const isWithdrawFlow = ctx.session.state === "selecting_withdraw_method";
      const isWalletFlow   = ctx.session.state === "selecting_wallet_method";

      if (isWithdrawFlow) {
        ctx.session.withdrawMethod = methodId;
        ctx.session.state          = "await_withdraw_address";
        await showPanel(ctx,
          tr_(lang, "withdrawAddress", { method: getMethodLabel(methodId) }),
          { reply_markup: cancelMenu(lang) }
        );
        return;
      }

      if (isWalletFlow || ctx.session.state === undefined) {
        // Default to wallet save flow (from profile → set wallet)
        ctx.session.walletMethod = methodId;
        ctx.session.state        = "await_wallet_address";
        await showPanel(ctx,
          tr_(lang, "enterWalletAddress", { method: getMethodLabel(methodId) }),
          { reply_markup: cancelMenu(lang) }
        );
        return;
      }
    }

    // ══════════════════════════════════════════════════════════════════════
    //  MAIN MENU NAVIGATION
    // ══════════════════════════════════════════════════════════════════════

    // ── 👤 User Profile ───────────────────────────────────────────────────

    if (text === tr_(lang, "profileBtn")) {
      clearState(ctx);
      await handleProfilePanel(ctx, lang, dbUser);
      return;
    }

    // ── 💰 Earn ───────────────────────────────────────────────────────────

    if (text === tr_(lang, "earnBtn")) {
      clearState(ctx);
      await showPanel(ctx, tr_(lang, "earnCategoryMsg"), { reply_markup: earnSubMenu(lang) });
      return;
    }

    // ── 💸 Withdrawal ─────────────────────────────────────────────────────

    if (text === tr_(lang, "withdrawalBtn")) {
      clearState(ctx);
      dbUser = (await getUserByTelegramId(tgId))!;
      const minWd   = await getNumSetting("min_withdrawal", 1.00);
      const balance = Number(dbUser.balance);
      if (balance < minWd) {
        await showPanel(ctx, tr_(lang, "withdrawLow", { balance: balance.toFixed(2), minWd: minWd.toFixed(2) }), { reply_markup: mainMenu(lang) });
        return;
      }
      ctx.session.state = "selecting_withdraw_method";
      await showPanel(ctx, tr_(lang, "withdrawMsg", { balance: balance.toFixed(2), minWd: minWd.toFixed(2) }), { reply_markup: withdrawMethodMenu(lang) });
      return;
    }

    // ── 👥 Referral ───────────────────────────────────────────────────────

    if (text === tr_(lang, "referralBtn")) {
      clearState(ctx);
      await handleReferralPanel(ctx, lang, dbUser);
      return;
    }

    // ── 🔞 Adult ──────────────────────────────────────────────────────────

    if (text === tr_(lang, "adultBtn2")) {
      clearState(ctx);
      const inlineKbd = new InlineKeyboard().add({ text: "🔞 Open Adult Content", url: ADULT_BOT_LINK, style: "danger" });
      await showPanel(ctx, `🔞 <b>ADULT CONTENT BOT</b>
<code>${SEP}</code>
🎬 Exclusive premium adult content
🔗 Tap below to access the bot.
<code>${LINE}</code>
⚠️ <i>18+ only. By opening you confirm you are of legal age.</i>`, { reply_markup: inlineKbd });

      // Update reply keyboard to Home only
      const chatId = ctx.chat?.id;
      if (chatId) {
        const nav = await ctx.api.sendMessage(chatId,
          "👇", { reply_markup: singleHomeMenu(lang) }
        );
        ctx.session.panelMsgId = nav.message_id;
        await saveUserPanelMsg(tgId, nav.message_id).catch(() => {});
      }
      return;
    }

    // ── 🎬 Movie-Series ───────────────────────────────────────────────────

    if (text === tr_(lang, "movieSeriesBtn")) {
      clearState(ctx);
      const inlineKbd = new InlineKeyboard().add({ text: "🎬 Open Movie & Series Bot", url: MOVIE_BOT_LINK, style: "primary" });
      await showPanel(ctx, `🎬 <b>MOVIE &amp; SERIES BOT</b>
<code>${SEP}</code>
🍿 Stream &amp; download movies and web series for free!
🌟 Latest releases · HD quality · All genres
<code>${LINE}</code>
🔗 Tap below to open:`, { reply_markup: inlineKbd });

      const chatId = ctx.chat?.id;
      if (chatId) {
        const nav = await ctx.api.sendMessage(chatId,
          "👇", { reply_markup: singleHomeMenu(lang) }
        );
        ctx.session.panelMsgId = nav.message_id;
        await saveUserPanelMsg(tgId, nav.message_id).catch(() => {});
      }
      return;
    }

    // ══════════════════════════════════════════════════════════════════════
    //  PROFILE SUB-MENU
    // ══════════════════════════════════════════════════════════════════════

    // ── 💳 Set Wallet ─────────────────────────────────────────────────────

    if (text === tr_(lang, "setWalletBtn")) {
      ctx.session.state = "selecting_wallet_method";
      await showPanel(ctx, tr_(lang, "updateWalletMsg"), { reply_markup: walletSelectMenu(lang) });
      return;
    }

    // ── 🌐 Change Language ────────────────────────────────────────────────

    if (text === tr_(lang, "changeLangBtn")) {
      clearState(ctx);
      await showPanel(ctx, tr_(lang, "selectLang"), { reply_markup: langKeyboard() });
      return;
    }

    // ── ⬅️ Back (from wallet select → profile) ────────────────────────────

    if (text === tr_(lang, "backBtn")) {
      clearState(ctx);
      dbUser = (await getUserByTelegramId(tgId))!;
      await handleProfilePanel(ctx, lang, dbUser);
      return;
    }

    // ══════════════════════════════════════════════════════════════════════
    //  EARN SUB-MENU
    // ══════════════════════════════════════════════════════════════════════

    // ── 📺 Watch Ads ──────────────────────────────────────────────────────

    if (text === tr_(lang, "watchAdsBtn")) {
      clearState(ctx);
      dbUser = (await getUserByTelegramId(tgId))!;
      await handleEarnPanel(ctx, lang, dbUser);
      return;
    }

    // ── 📋 Daily Tasks ────────────────────────────────────────────────────

    if (text === tr_(lang, "dailyTasksBtn")) {
      clearState(ctx);
      dbUser = (await getUserByTelegramId(tgId))!;
      await handleTaskPanel(ctx, lang, dbUser);
      return;
    }

    // Unknown text
    await showPanel(ctx, tr_(lang, "unknownCmd"), { reply_markup: mainMenu(lang) });
  });

  // ─── Watch ad (inline callback) ───────────────────────────────────────────

  bot.callbackQuery("watch_ad", async (ctx) => {
    await ctx.answerCallbackQuery();
    const tgId   = String(ctx.from.id);
    const dbUser = await getUserByTelegramId(tgId);
    if (!dbUser || dbUser.isBanned) return;
    const lang = (dbUser.language as Lang) ?? "en";

    const channels = await getActiveChannels();
    if (channels.length > 0) {
      const unjoined = await getUnjoinedChannels(dbUser.id, ctx.from.id, channels);
      if (unjoined.length > 0) {
        const channelList = unjoined.map(c => `  • <a href="${c.url}">${c.name}</a>`).join("\n");
        const kbd = new InlineKeyboard();
        for (const c of unjoined) kbd.add({ text: `📢 ${c.name}`, url: c.url, style: "primary" }).row();
        kbd.add({ text: tr_(lang, "joinedVerify"), callback_data: "verify_channels", style: "success" });
        await ctx.editMessageText(tr_(lang, "channelRequired", { channels: channelList }), { ...HTML, reply_markup: kbd });
        return;
      }
    }

    const result = await startAdWatch(dbUser.id);
    if (!result.ok) {
      const msg = result.alreadyPending
        ? tr_(lang, "adAlreadyPending")
        : tr_(lang, "adsLimit", { max: await getNumSetting("max_ads_per_day", 10), balance: Number(dbUser.balance).toFixed(2) });
      await ctx.editMessageText(msg, HTML);
      return;
    }

    const kbd = new InlineKeyboard()
      .add({ text: tr_(lang, "watchNow"), url: ADS_URL, style: "primary" }).row()
      .add({ text: tr_(lang, "adVerify"), callback_data: `ad_done:${result.token}`, style: "success" });
    await ctx.editMessageText(tr_(lang, "adStarted"), { ...HTML, reply_markup: kbd });
  });

  // ─── Ad complete ──────────────────────────────────────────────────────────

  bot.callbackQuery(/^ad_done:(.+)$/, async (ctx) => {
    const token  = ctx.match![1]!;
    const tgId   = String(ctx.from.id);
    const dbUser = await getUserByTelegramId(tgId);
    if (!dbUser) { await ctx.answerCallbackQuery(); return; }
    const lang = (dbUser.language as Lang) ?? "en";

    const result = await completeAdWatch(dbUser.id, token);
    if (result.banned) {
      await ctx.answerCallbackQuery("🚫 Account banned");
      await ctx.editMessageText(tr_(lang, "adCheatBan"), HTML);
      return;
    }
    if (result.cheated) {
      const [warnCount, warnLimit] = await Promise.all([getWarningCount(dbUser.id), getNumSetting("warn_limit", 3)]);
      await ctx.answerCallbackQuery("❌ Too fast!");
      await ctx.editMessageText(tr_(lang, "adFailed", { warnCount, warnLimit }), HTML);
      return;
    }
    if (!result.ok) { await ctx.answerCallbackQuery("⚠️ Error"); return; }

    const [maxAds, adReward] = await Promise.all([getNumSetting("max_ads_per_day", 10), getNumSetting("ad_reward", 0.01)]);
    await ctx.answerCallbackQuery(`✅ +$${adReward.toFixed(2)} credited!`);

    const balance   = parseFloat(result.balance ?? "0").toFixed(2);
    const watched   = result.watched ?? 0;
    const remaining = maxAds - watched;
    const kbd = new InlineKeyboard();
    if (remaining > 0) kbd.add({ text: tr_(lang, "watchAd"), callback_data: "watch_ad", style: "success" }).row();
    kbd.add({ text: tr_(lang, "refresh"), callback_data: "refresh_balance", style: "primary" });
    await ctx.editMessageText(tr_(lang, "adComplete", { balance, watched, max: maxAds }), { ...HTML, reply_markup: kbd });
  });

  // ─── Refresh balance ──────────────────────────────────────────────────────

  bot.callbackQuery("refresh_balance", async (ctx) => {
    await ctx.answerCallbackQuery("🔄 Refreshed!");
    const tgId   = String(ctx.from.id);
    const dbUser = await getUserByTelegramId(tgId);
    if (!dbUser) return;
    const lang = (dbUser.language as Lang) ?? "en";
    await handleEarnPanelEdit(ctx, lang, dbUser);
  });

  // ─── Verify channels ──────────────────────────────────────────────────────

  bot.callbackQuery("verify_channels", async (ctx) => {
    await ctx.answerCallbackQuery();
    const tgId   = String(ctx.from.id);
    const dbUser = await getUserByTelegramId(tgId);
    if (!dbUser) return;
    const lang = (dbUser.language as Lang) ?? "en";
    const channels     = await getActiveChannels();
    const stillUnjoined = await getUnjoinedChannels(dbUser.id, ctx.from.id, channels);
    if (stillUnjoined.length > 0) {
      const channelList = stillUnjoined.map(c => `  • <a href="${c.url}">${c.name}</a>`).join("\n");
      const kbd = new InlineKeyboard();
      for (const c of stillUnjoined) kbd.add({ text: `📢 ${c.name}`, url: c.url, style: "primary" }).row();
      kbd.add({ text: tr_(lang, "joinedVerify"), callback_data: "verify_channels", style: "success" });
      await ctx.editMessageText(tr_(lang, "channelRequired", { channels: channelList }), { ...HTML, reply_markup: kbd });
      return;
    }
    for (const ch of channels) {
      const join = await getChannelJoin(dbUser.id, ch.id);
      if (!join?.rewardPaid) await recordChannelJoin(dbUser.id, ch.id);
    }
    const freshUser = await getUserByTelegramId(tgId);
    if (freshUser) await handleEarnPanelEdit(ctx, lang, freshUser);
  });

  // ─── Task: channel verify ─────────────────────────────────────────────────

  bot.callbackQuery(/^task_channel:(\d+)$/, async (ctx) => {
    const channelId = parseInt(ctx.match![1]!);
    const tgId      = String(ctx.from.id);
    const dbUser    = await getUserByTelegramId(tgId);
    if (!dbUser) { await ctx.answerCallbackQuery(); return; }
    const lang = (dbUser.language as Lang) ?? "en";
    const isMember = await checkChannelMembership(channelId, ctx.from.id);
    if (!isMember) { await ctx.answerCallbackQuery("❌ " + tr_(lang, "channelNotJoined")); return; }
    const result = await recordChannelJoin(dbUser.id, channelId);
    await ctx.answerCallbackQuery(result.alreadyClaimed ? "✅ Already claimed" : `✅ +$${Number(result.reward).toFixed(2)}`);
    const freshUser = await getUserByTelegramId(tgId);
    if (freshUser) await handleTaskPanelEdit(ctx, lang, freshUser);
  });

  // ─── Task: share ──────────────────────────────────────────────────────────

  bot.callbackQuery("task_share", async (ctx) => {
    await ctx.answerCallbackQuery("✅ Share confirmed!");
    const tgId   = String(ctx.from.id);
    const dbUser = await getUserByTelegramId(tgId);
    if (!dbUser) return;
    const lang = (dbUser.language as Lang) ?? "en";
    await markTaskShare(dbUser.id);
    const freshUser = await getUserByTelegramId(tgId);
    if (freshUser) await handleTaskPanelEdit(ctx, lang, freshUser);
  });

  // ─── Task: claim bonus ────────────────────────────────────────────────────

  bot.callbackQuery("task_claim", async (ctx) => {
    await ctx.answerCallbackQuery();
    const tgId   = String(ctx.from.id);
    const dbUser = await getUserByTelegramId(tgId);
    if (!dbUser) return;
    const lang   = (dbUser.language as Lang) ?? "en";
    const result = await claimDailyBonus(dbUser.id);
    if (result.ok) {
      const bonus = await getNumSetting("daily_bonus", 0.20);
      await ctx.editMessageText(tr_(lang, "bonusClaimed", {
        bonus: bonus.toFixed(2),
        balance: parseFloat(result.balance ?? "0").toFixed(2),
      }), HTML);
    } else if (result.reason === "alreadyClaimed") {
      await ctx.answerCallbackQuery(tr_(lang, "alreadyClaimed"));
    } else {
      await ctx.answerCallbackQuery(tr_(lang, "tasksNotComplete"));
    }
  });

  // ─── Start polling ────────────────────────────────────────────────────────

  bot.start({
    onStart: (info) => logger.info({ username: info.username }, "Bot started"),
  }).catch((err) => logger.error({ err }, "Bot failed to start"));

  return bot;
}
