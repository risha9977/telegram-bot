export type Lang = "en" | "bn" | "hi" | "ar" | "ru" | "tr" | "ur" | "pa" | "id" | "fr" | "es" | "pt";

export const LANGUAGES: Record<Lang, string> = {
  en: "🇬🇧 English",
  bn: "🇧🇩 বাংলা",
  hi: "🇮🇳 हिन्दी",
  ar: "🇸🇦 العربية",
  ru: "🇷🇺 Русский",
  tr: "🇹🇷 Türkçe",
  ur: "🇵🇰 اردو",
  pa: "🇮🇳 ਪੰਜਾਬੀ",
  id: "🇮🇩 Indonesia",
  fr: "🇫🇷 Français",
  es: "🇪🇸 Español",
  pt: "🇧🇷 Português",
};

export function escHtml(s: string): string {
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

export function bar(n: number, max: number, w = 10): string {
  const f = Math.min(Math.round((Math.max(n, 0) / Math.max(max, 1)) * w), w);
  return "▰".repeat(f) + "░".repeat(w - f);
}

// ─── Decorative separators ────────────────────────────────────────────────────
const SEP  = "━━━━━━━━━━━━━━━━━━━━━━━━━";
const LINE = "─────────────────────────";
const DBL  = "══════════════════════════";

// ─── Telegram Premium Custom Emoji helper ─────────────────────────────────────
// <tg-emoji> shows animated premium emoji to Telegram Premium users.
// Non-premium users see the fallback text emoji (works perfectly either way).
const pe = (_id: string, fb: string): string => fb;

// ── Animated Premium Emoji variables ─────────────────────────────────────────
const $fire     = pe("5199982628387815413", "🔥");
const $gem      = pe("5471952986970267163", "💎");
const $star     = pe("5368324170671202286", "⭐");
const $crown    = pe("5415765372354901993", "👑");
const $trophy   = pe("5415765372354901993", "🏆");
const $rocket   = pe("5315965544429987682", "🚀");
const $zap      = pe("5416040106720475628", "⚡");
const $check    = pe("5368324170671202286", "✅");
const $cross    = pe("5199982628387815413", "❌");
const $ban      = pe("5415765372354901993", "🚫");
const $warn     = pe("5199982628387815413", "⚠️");
const $lock     = pe("5415765372354901993", "🔒");
const $party    = pe("5199982628387815413", "🎉");
const $gift     = pe("5199982628387815413", "🎁");
const $sparkle  = pe("5368324170671202286", "✨");
const $shine    = pe("5368324170671202286", "🌟");
const $moon     = pe("5368324170671202286", "🌙");
const $money    = pe("5463163590754375938", "💰");
const $cashfly  = pe("5463163590754375938", "💸");
const $dollar   = pe("5463163590754375938", "💵");
const $wallet   = pe("5463163590754375938", "💼");
const $people   = pe("5368324170671202286", "👥");
const $user     = pe("5368324170671202286", "👤");
const $globe    = pe("5471952986970267163", "🌐");
const $tv       = pe("5199982628387815413", "📺");
const $chart    = pe("5471952986970267163", "📊");
const $chart2   = pe("5471952986970267163", "📈");
const $bell     = pe("5368324170671202286", "🔔");
const $movie    = pe("5199982628387815413", "🎬");
const $clip     = pe("5471952986970267163", "📋");
const $share    = pe("5368324170671202286", "📨");
const $link     = pe("5416040106720475628", "🔗");
const $refresh  = pe("5199982628387815413", "🔄");
const $phone    = pe("5471952986970267163", "📱");
const $bank     = pe("5415765372354901993", "🏦");
const $mailbox  = pe("5368324170671202286", "📬");
const $clock    = pe("5199982628387815413", "⏰");
const $hourglass= pe("5199982628387815413", "⏳");
const $cal      = pe("5471952986970267163", "📅");
const $inbox    = pe("5368324170671202286", "📩");
const $idcard   = pe("5415765372354901993", "🆔");
const $note     = pe("5471952986970267163", "📝");
const $mega     = pe("5368324170671202286", "📢");
const $diamond  = pe("5471952986970267163", "💠");
const $target   = pe("5471952986970267163", "🎯");
const $coins    = pe("5463163590754375938", "🪙");
const $up       = pe("5471952986970267163", "📈");

export const t: Record<Lang, Record<string, string>> = {
  // ─────────────────────────── ENGLISH ────────────────────────────
  en: {
    earn:      "💰 Earn",
    profile:   "👤 Profile",
    dailyTask: "📋 Daily Tasks",
    referral:  "👥 Referral",
    withdraw:  "💸 Withdraw",
    language:  "🌐 Language",
    adultBot:  "🔞 Adult",
    movieBot:  "🎬 Movies",
    rules:     "📜 Rules",

    welcome: `${$movie} <b>Welcome to DesiXX Video Bot!</b>
<code>${SEP}</code>
${$money} Watch ads — earn <b>real money</b>
${$people} Refer friends — <b>instant bonus</b> credited
${$clip} Daily tasks — unlock <b>extra rewards</b>
${$cashfly} Withdraw via <b>bKash · Nagad · USDT</b>
<code>${LINE}</code>
${$globe} <b>Choose your language to begin:</b>`,

    langSet:    "${$check} <b>Language set to English!</b>",
    menuMsg:    `${$shine} <b>Main Menu</b>\n<code>${LINE}</code>\n${$zap} Tap a button below to continue:`,
    selectLang: `${$globe} <b>Select Your Language:</b>`,

    earnMsg: `${$money} <b>EARN CENTER</b>
<code>${SEP}</code>
${$chart} <b>Progress:</b>  <code>{bar}</code>  <b>{watched} / {max}</b>
<code>${LINE}</code>
${$dollar} <i>Today Earned:</i>  <b>$ {todayEarned}</b>
${$wallet} <i>Your Balance:</i>  <b>$ {balance}</b>
${$zap} Per Ad: <b>$0.01</b>  ·  <b>{remaining}</b> ads left
<code>${LINE}</code>`,

    earnDone: `${$check} <b>All Ads Done for Today!</b>
<code>${SEP}</code>
${$party} Great work! You watched all <b>{max}</b> ads.
${$wallet} <i>Current Balance:</i> <b>$ {balance}</b>
<code>${LINE}</code>
${$moon} Come back <b>tomorrow</b> for more earnings!`,

    watchAd: "📺 Watch Ad  (+$0.01)",
    refresh:  "🔄 Refresh Balance",

    adStarted: `${$tv} <b>Ad Ready — Watch Now!</b>
<code>${SEP}</code>
${$clock} Watch for at least <b>10 seconds</b>
${$check} Then tap <b>I Watched It</b> below
<code>${LINE}</code>
<blockquote>${$warn} Skipping = <b>Warning issued</b>
${$lock} Unique token — <b>one use only</b></blockquote>`,

    watchNow:   "▶️ Open Ad",
    adVerify:   "✅ I Watched It",
    adComplete: `${$check} <b>+$0.01 Credited Successfully!</b>
<code>${SEP}</code>
${$wallet} Balance: <b>$ {balance}</b>
${$chart} Today: <b>{watched} / {max}</b> ads watched
<code>${LINE}</code>
${$fire} <i>Keep going — every ad counts!</i>`,

    adFailed: `${$warn} <b>Verification Failed — Too Fast!</b>
<code>${SEP}</code>
You must watch the <b>full ad</b> before verifying.
<code>${LINE}</code>
<blockquote>${$warn} Warning <b>{warnCount} / {warnLimit}</b> issued.
${$ban} At <b>{warnLimit}</b> warnings → <b>permanent ban</b></blockquote>`,

    adCheatBan: `${$ban} <b>Account Permanently Banned</b>
<code>${SEP}</code>
<blockquote>You exceeded the allowed violation limit.
This action is <b>irreversible</b>.</blockquote>
<code>${LINE}</code>
${$inbox} Contact support if you believe this is an error.`,

    adAlreadyPending: `${$hourglass} <b>Ad in progress</b> — complete it before starting a new one.`,
    adsLimit: `${$check} <b>All {max} ads watched today!</b>
<code>${SEP}</code>
${$wallet} Balance: <b>$ {balance}</b>
${$moon} See you <b>tomorrow</b> for more!`,

    channelRequired: `${$lock} <b>Join Required Channels First</b>
<code>${SEP}</code>
You must join <b>all</b> channels below to start earning:

{channels}
<code>${LINE}</code>
${$check} After joining, tap <b>I Joined All</b>.`,

    joinedVerify:      "✅ I Joined All",
    channelNotJoined:  "❌ Not joined yet — please join first.",
    channelJoinReward: `${$party} Joined channel! <b>+\${reward}</b> credited.`,

    profileMsg: `${$user} <b>MY PROFILE</b>
<code>${SEP}</code>
${$idcard} <i>User ID:</i>   <code>{id}</code>
${$user} <i>Name:</i>      <b>{name}</b>
${$globe} <i>Language:</i>  {lang}
<code>${LINE}</code>
${$wallet} <i>Balance:</i>      <b>$ {balance}</b>
${$up} <i>Total Earned:</i> <b>$ {totalEarned}</b>
<code>${LINE}</code>
${$chart} <i>Today's Ads:</i>  <b>{adsToday} / {maxAds}</b>
${$people} <i>Referrals:</i>   <b>{referrals}</b>
${$warn} <i>Warnings:</i>    <b>{warnings} / {warnLimit}</b>
${$cal} <i>Joined:</i>      <b>{joined}</b>
<code>${LINE}</code>
<blockquote>📜 <b>RULES</b>
▸ Max <b>{maxAds}</b> ads per day
▸ No bots, scripts, or cheating
▸ Min withdrawal: <b>$ {minWd}</b>
▸ <b>{warnLimit}</b> violations = permanent ban
▸ One account per person</blockquote>`,

    referralMsg: `${$people} <b>REFERRAL PROGRAM</b>
<code>${SEP}</code>
${$shine} Invite friends — earn <b>$ {refReward}</b> per person!
<code>${LINE}</code>
${$people} <i>Total Referrals:</i>  <b>{count}</b>
${$money} <i>Referral Earnings:</i> <b>$ {earned}</b>
<code>${LINE}</code>
${$link} <b>Your Referral Link:</b>
<code>{link}</code>
<code>${LINE}</code>
${$share} <i>Share your link — earn instantly when friends join!</i>`,

    shareLink: "📨 Share Link",

    dailyTaskMsg: `${$clip} <b>DAILY TASKS</b>
<code>${SEP}</code>
${$sparkle} Complete all tasks — unlock your bonus!
${$refresh} Resets every midnight
<code>${LINE}</code>
{tasks}
<code>${LINE}</code>
${$check} Progress: <b>{done} / {total}</b>
${$gift} Daily Bonus: <b>$ {bonus}</b>`,

    taskWatchAds:   `${$tv} Watch <b>{threshold}</b> ads today  →  <b>+$ {reward}</b>`,
    taskShare:      `${$share} Share bot with 1 friend  →  <b>+$ {reward}</b>`,
    taskChannel:    `${$mega} Join: <b>{name}</b>  →  <b>+$ {reward}</b>`,
    taskReferral:   `${$people} Bring 1 new user  →  <b>+$ {reward}</b>`,
    taskDonePrefix:    "✅ ",
    taskPendingPrefix: "⬜ ",
    claimBonus:     "🎁 Claim Daily Bonus",
    bonusClaimed: `${$gift} <b>Daily Bonus Claimed!</b>
<code>${SEP}</code>
${$money} Bonus: <b>+$ {bonus}</b>
${$wallet} New Balance: <b>$ {balance}</b>`,

    alreadyClaimed:   `${$check} Today's bonus already claimed!`,
    tasksNotComplete: `${$warn} Complete all tasks first!`,
    taskShareBtn:     "📨 Share Bot",
    taskVerifyBtn:    "✅ Verify",

    withdrawMsg: `${$cashfly} <b>WITHDRAW</b>
<code>${SEP}</code>
${$wallet} Your Balance: <b>$ {balance}</b>
${$warn} Minimum: <b>$ {minWd}</b>
<code>${LINE}</code>
${$phone} <b>Select payment method:</b>`,

    withdrawLow: `${$cross} <b>Insufficient Balance</b>
<code>${SEP}</code>
You need at least <b>$ {minWd}</b> to withdraw.
${$wallet} <i>Your Balance:</i> <b>$ {balance}</b>`,

    withdrawAddress:  `${$note} Enter your <b>{method}</b> number or wallet address:`,
    withdrawConfirm: `${$check} <b>Withdrawal Request Submitted!</b>
<code>${SEP}</code>
${$dollar} Amount:  <b>$ {amount}</b>
${$bank} Method:  <b>{method}</b>
${$mailbox} Address: <code>{address}</code>
<code>${LINE}</code>
${$clock} Payment processed within <b>24 hours</b>.`,

    withdrawPending: `${$hourglass} You already have a <b>pending withdrawal</b>. Please wait.`,
    withdrawSelect:  "Select payment method:",

    banned: `${$ban} <b>Account Banned</b>
<code>${SEP}</code>
<blockquote>Your account has been banned for violating the rules.</blockquote>
<code>${LINE}</code>
${$inbox} Contact support if you believe this is an error.`,

    startFirst: `${$warn} Please send /start to begin.`,
    unknownCmd: `Use the menu buttons below to navigate. 👇`,
    profileBtn: "👤 User Profile",
    earnBtn: "💰 Earn",
    withdrawalBtn: "💸 Withdraw",
    referralBtn: "👥 Referral",
    adultBtn2: "🔞 Adult",
    movieSeriesBtn: "🎬 Movies",
    setWalletBtn: "💳 Set Wallet",
    changeLangBtn: "🌐 Change Language",
    watchAdsBtn: "📺 Watch Ads",
    dailyTasksBtn: "📋 Daily Tasks",
    confirmBtn: "✅ Confirm",
    changeMethodBtn: "🔄 Change Method",
    cancelBtn: "❌ Cancel",
    mainMenuBtn: "🏠 Main Menu",
    backBtn: "⬅️ Back",
    confirmWalletMsg: `${$check} <b>Confirm Save Wallet</b>\n<code>${SEP}</code>\n💳 Method: <b>{method}</b>\n${$mailbox} Address: <code>{address}</code>`,
    confirmWdMsg: `${$check} <b>Confirm Withdrawal</b>\n<code>${SEP}</code>\n💳 Method: <b>{method}</b>\n${$mailbox} Address: <code>{address}</code>\n${$dollar} Amount: <b>$ {balance}</b>`,
    walletUpdated: `${$check} <b>Wallet Updated!</b>\n<code>${SEP}</code>\n💳 Method: <b>{method}</b>\n${$mailbox} Address: <code>{address}</code>`,
    updateWalletMsg: `💳 <b>Update Wallet</b>\n<code>${SEP}</code>\n${$phone} Select your payment method:`,
    nameUpdated: `${$check} <b>Name Updated!</b>\n<code>${SEP}</code>\n${$user} New name: <b>{name}</b>`,
    earnCategoryMsg: `${$money} <b>EARN CENTER</b>\n<code>${SEP}</code>\n${$rocket} Choose how to earn today:\n<code>${LINE}</code>\n${$tv} <b>Watch Ads</b>  —  +$0.01 per ad\n${$clip} <b>Daily Tasks</b>  —  bonus on completion\n${$people} <b>Referral</b>  —  earn per friend\n<code>${LINE}</code>\n${$zap} <i>All earnings are instant</i>`,
  },

  // ─────────────────────────── BENGALI ────────────────────────────
  bn: {
    earn:      "💰 আয়",
    profile:   "👤 প্রোফাইল",
    dailyTask: "📋 ডেইলি টাস্ক",
    referral:  "👥 রেফারেল",
    withdraw:  "💸 উইথড্র",
    language:  "🌐 ভাষা",
    adultBot:  "🔞 Adult",
    movieBot:  "🎬 মুভিজ",
    rules:     "📜 নিয়মাবলী",

    welcome: `${$movie} <b>DesiXX Video Bot-এ স্বাগতম!</b>
<code>${SEP}</code>
${$money} বিজ্ঞাপন দেখুন — <b>আসল টাকা</b> আয় করুন
${$people} বন্ধু আনুন — <b>তাৎক্ষণিক বোনাস</b> পান
${$clip} ডেইলি টাস্ক করুন — <b>এক্সট্রা পুরস্কার</b>
${$cashfly} <b>bKash · Nagad · USDT</b>-তে উইথড্র করুন
<code>${LINE}</code>
${$globe} <b>শুরু করতে আপনার ভাষা বেছে নিন:</b>`,

    langSet:    `${$check} <b>ভাষা বাংলায় সেট হয়েছে!</b>`,
    menuMsg:    `${$shine} <b>মেইন মেনু</b>\n<code>${LINE}</code>\n${$zap} নিচের বাটন চাপুন:`,
    selectLang: `${$globe} <b>ভাষা বেছে নিন:</b>`,

    earnMsg: `${$money} <b>আয় কেন্দ্র</b>
<code>${SEP}</code>
${$chart} <b>অগ্রগতি:</b>  <code>{bar}</code>  <b>{watched} / {max}</b>
<code>${LINE}</code>
${$dollar} <i>আজ আয়:</i>        <b>$ {todayEarned}</b>
${$wallet} <i>আপনার ব্যালেন্স:</i> <b>$ {balance}</b>
${$zap} প্রতি বিজ্ঞাপন: <b>$0.01</b>  ·  <b>{remaining}</b>টি বাকি
<code>${LINE}</code>`,

    earnDone: `${$check} <b>আজকের সব বিজ্ঞাপন দেখা শেষ!</b>
<code>${SEP}</code>
${$party} দারুণ! আপনি সব <b>{max}</b>টি বিজ্ঞাপন দেখেছেন।
${$wallet} <i>বর্তমান ব্যালেন্স:</i> <b>$ {balance}</b>
<code>${LINE}</code>
${$moon} আরো আয়ের জন্য <b>আগামীকাল</b> আসুন!`,

    watchAd: "📺 বিজ্ঞাপন দেখুন  (+$0.01)",
    refresh:  "🔄 ব্যালেন্স রিফ্রেশ",

    adStarted: `${$tv} <b>বিজ্ঞাপন প্রস্তুত — এখনই দেখুন!</b>
<code>${SEP}</code>
${$clock} কমপক্ষে <b>১০ সেকেন্ড</b> দেখুন
${$check} তারপর নিচে <b>আমি দেখেছি</b> চাপুন
<code>${LINE}</code>
<blockquote>${$warn} আগে চাপলে = <b>সতর্কতা জারি</b>
${$lock} প্রতিটির আলাদা টোকেন — <b>একবার ব্যবহারযোগ্য</b></blockquote>`,

    watchNow:   "▶️ বিজ্ঞাপন খুলুন",
    adVerify:   "✅ আমি দেখেছি",
    adComplete: `${$check} <b>+$0.01 সফলভাবে ক্রেডিট হয়েছে!</b>
<code>${SEP}</code>
${$wallet} ব্যালেন্স: <b>$ {balance}</b>
${$chart} আজ: <b>{watched} / {max}</b> বিজ্ঞাপন দেখা হয়েছে
<code>${LINE}</code>
${$fire} <i>চালিয়ে যান — প্রতিটি বিজ্ঞাপনই গুরুত্বপূর্ণ!</i>`,

    adFailed: `${$warn} <b>যাচাই ব্যর্থ — অনেক তাড়াতাড়ি!</b>
<code>${SEP}</code>
সম্পূর্ণ বিজ্ঞাপন না দেখে যাচাই করা যাবে না।
<code>${LINE}</code>
<blockquote>${$warn} সতর্কতা <b>{warnCount} / {warnLimit}</b> জারি হয়েছে।
${$ban} <b>{warnLimit}</b>টি সতর্কতায় → <b>স্থায়ীভাবে ব্যান</b></blockquote>`,

    adCheatBan: `${$ban} <b>অ্যাকাউন্ট স্থায়ীভাবে ব্যান</b>
<code>${SEP}</code>
<blockquote>অনুমোদিত লঙ্ঘনের সীমা অতিক্রম করেছেন।
এই সিদ্ধান্ত <b>অপরিবর্তনযোগ্য</b>।</blockquote>
<code>${LINE}</code>
${$inbox} ভুল মনে হলে সাপোর্টে যোগাযোগ করুন।`,

    adAlreadyPending: `${$hourglass} <b>বিজ্ঞাপন চলছে</b> — নতুনটি শুরুর আগে সেটি শেষ করুন।`,
    adsLimit: `${$check} <b>আজকের সব {max}টি বিজ্ঞাপন দেখা হয়েছে!</b>
<code>${SEP}</code>
${$wallet} ব্যালেন্স: <b>$ {balance}</b>
${$moon} আগামীকাল আবার আসুন!`,

    channelRequired: `${$lock} <b>প্রয়োজনীয় চ্যানেলে আগে যোগ দিন</b>
<code>${SEP}</code>
আয় শুরু করতে <b>সব</b> চ্যানেলে যোগ দিন:

{channels}
<code>${LINE}</code>
${$check} যোগ দেওয়ার পর <b>আমি যোগ দিয়েছি</b> চাপুন।`,

    joinedVerify:      "✅ আমি সবখানে যোগ দিয়েছি",
    channelNotJoined:  "❌ এখনো যোগ দেননি — আগে যোগ দিন।",
    channelJoinReward: `${$party} চ্যানেলে যোগ দেওয়া হয়েছে! <b>+\${reward}</b> ক্রেডিট।`,

    profileMsg: `${$user} <b>আমার প্রোফাইল</b>
<code>${SEP}</code>
${$idcard} <i>ইউজার আইডি:</i>  <code>{id}</code>
${$user} <i>নাম:</i>           <b>{name}</b>
${$globe} <i>ভাষা:</i>          {lang}
<code>${LINE}</code>
${$wallet} <i>ব্যালেন্স:</i>       <b>$ {balance}</b>
${$up} <i>মোট আয়:</i>         <b>$ {totalEarned}</b>
<code>${LINE}</code>
${$chart} <i>আজকের বিজ্ঞাপন:</i>  <b>{adsToday} / {maxAds}</b>
${$people} <i>রেফারেল:</i>         <b>{referrals}</b>
${$warn} <i>সতর্কতা:</i>          <b>{warnings} / {warnLimit}</b>
${$cal} <i>যোগদান:</i>           <b>{joined}</b>
<code>${LINE}</code>
<blockquote>📜 <b>নিয়মাবলী</b>
▸ দিনে সর্বোচ্চ <b>{maxAds}</b>টি বিজ্ঞাপন
▸ বট, স্ক্রিপ্ট বা চিটিং নিষিদ্ধ
▸ উইথড্রের জন্য সর্বনিম্ন <b>$ {minWd}</b>
▸ <b>{warnLimit}</b>টি লঙ্ঘনে স্থায়ী ব্যান
▸ একজন ব্যক্তি — একটি অ্যাকাউন্ট</blockquote>`,

    referralMsg: `${$people} <b>রেফারেল প্রোগ্রাম</b>
<code>${SEP}</code>
${$shine} বন্ধু আনুন — প্রতিজনে <b>$ {refReward}</b> আয়!
<code>${LINE}</code>
${$people} <i>মোট রেফারেল:</i>   <b>{count}</b>
${$money} <i>রেফারেল আয়:</i>    <b>$ {earned}</b>
<code>${LINE}</code>
${$link} <b>আপনার রেফারেল লিংক:</b>
<code>{link}</code>
<code>${LINE}</code>
${$share} <i>লিংক শেয়ার করুন — বন্ধু যোগ দিলেই তাৎক্ষণিক আয়!</i>`,

    shareLink: "📨 লিংক শেয়ার করুন",

    dailyTaskMsg: `${$clip} <b>ডেইলি টাস্ক</b>
<code>${SEP}</code>
${$sparkle} সব টাস্ক করুন — বোনাস আনলক করুন!
${$refresh} প্রতিদিন মধ্যরাতে রিসেট
<code>${LINE}</code>
{tasks}
<code>${LINE}</code>
${$check} অগ্রগতি: <b>{done} / {total}</b>
${$gift} ডেইলি বোনাস: <b>$ {bonus}</b>`,

    taskWatchAds:   `${$tv} আজ <b>{threshold}</b>টি বিজ্ঞাপন দেখুন  →  <b>+$ {reward}</b>`,
    taskShare:      `${$share} বট ১ বন্ধুকে শেয়ার করুন  →  <b>+$ {reward}</b>`,
    taskChannel:    `${$mega} যোগ দিন: <b>{name}</b>  →  <b>+$ {reward}</b>`,
    taskReferral:   `${$people} ১ নতুন ইউজার আনুন  →  <b>+$ {reward}</b>`,
    taskDonePrefix:    "✅ ",
    taskPendingPrefix: "⬜ ",
    claimBonus:     "🎁 ডেইলি বোনাস নিন",
    bonusClaimed: `${$gift} <b>ডেইলি বোনাস পেয়েছেন!</b>
<code>${SEP}</code>
${$money} বোনাস: <b>+$ {bonus}</b>
${$wallet} নতুন ব্যালেন্স: <b>$ {balance}</b>`,

    alreadyClaimed:   `${$check} আজকের বোনাস ইতিমধ্যে নেওয়া হয়েছে!`,
    tasksNotComplete: `${$warn} আগে সব টাস্ক সম্পন্ন করুন!`,
    taskShareBtn:     "📨 বট শেয়ার করুন",
    taskVerifyBtn:    "✅ যাচাই করুন",

    withdrawMsg: `${$cashfly} <b>উইথড্র</b>
<code>${SEP}</code>
${$wallet} আপনার ব্যালেন্স: <b>$ {balance}</b>
${$warn} সর্বনিম্ন: <b>$ {minWd}</b>
<code>${LINE}</code>
${$phone} <b>পেমেন্ট পদ্ধতি বেছে নিন:</b>`,

    withdrawLow: `${$cross} <b>ব্যালেন্স যথেষ্ট নেই</b>
<code>${SEP}</code>
উইথড্রের জন্য কমপক্ষে <b>$ {minWd}</b> প্রয়োজন।
${$wallet} <i>আপনার ব্যালেন্স:</i> <b>$ {balance}</b>`,

    withdrawAddress:  `${$note} আপনার <b>{method}</b> নম্বর বা ওয়ালেট ঠিকানা দিন:`,
    withdrawConfirm: `${$check} <b>উইথড্র রিকোয়েস্ট জমা হয়েছে!</b>
<code>${SEP}</code>
${$dollar} পরিমাণ:   <b>$ {amount}</b>
${$bank} পদ্ধতি:    <b>{method}</b>
${$mailbox} ঠিকানা:  <code>{address}</code>
<code>${LINE}</code>
${$clock} <b>২৪ ঘন্টার</b> মধ্যে পেমেন্ট প্রক্রিয়া হবে।`,

    withdrawPending: `${$hourglass} ইতিমধ্যে একটি <b>পেন্ডিং উইথড্র</b> আছে। অপেক্ষা করুন।`,
    withdrawSelect:  "পেমেন্ট পদ্ধতি বেছে নিন:",

    banned: `${$ban} <b>অ্যাকাউন্ট ব্যান</b>
<code>${SEP}</code>
<blockquote>নিয়ম লঙ্ঘনের কারণে অ্যাকাউন্ট ব্যান করা হয়েছে।</blockquote>
<code>${LINE}</code>
${$inbox} ভুল মনে হলে সাপোর্টে যোগাযোগ করুন।`,

    startFirst: `${$warn} শুরু করতে /start পাঠান।`,
    unknownCmd: `নেভিগেট করতে মেনু বাটন ব্যবহার করুন। 👇`,
    profileBtn: "👤 ইউজার প্রোফাইল",
    earnBtn: "💰 আয়",
    withdrawalBtn: "💸 উইথড্র",
    referralBtn: "👥 রেফারেল",
    adultBtn2: "🔞 এডাল্ট",
    movieSeriesBtn: "🎬 মুভি-সিরিজ",
    setWalletBtn: "💳 ওয়ালেট সেট",
    changeLangBtn: "🌐 ভাষা পরিবর্তন",
    watchAdsBtn: "📺 বিজ্ঞাপন দেখুন",
    dailyTasksBtn: "📋 ডেইলি টাস্ক",
    confirmBtn: "✅ নিশ্চিত করুন",
    changeMethodBtn: "🔄 পদ্ধতি পরিবর্তন",
    cancelBtn: "❌ বাতিল",
    mainMenuBtn: "🏠 মেইন মেনু",
    backBtn: "⬅️ পিছনে",
    confirmWalletMsg: `${$check} <b>ওয়ালেট সেভ নিশ্চিত করুন</b>\n<code>${SEP}</code>\n💳 পদ্ধতি: <b>{method}</b>\n${$mailbox} ঠিকানা: <code>{address}</code>`,
    confirmWdMsg: `${$check} <b>উইথড্র নিশ্চিত করুন</b>\n<code>${SEP}</code>\n💳 পদ্ধতি: <b>{method}</b>\n${$mailbox} ঠিকানা: <code>{address}</code>\n${$dollar} পরিমাণ: <b>$ {balance}</b>`,
    walletUpdated: `${$check} <b>ওয়ালেট আপডেট হয়েছে!</b>\n<code>${SEP}</code>\n💳 পদ্ধতি: <b>{method}</b>\n${$mailbox} ঠিকানা: <code>{address}</code>`,
    updateWalletMsg: `💳 <b>ওয়ালেট আপডেট করুন</b>\n<code>${SEP}</code>\n${$phone} পেমেন্ট পদ্ধতি বেছে নিন:`,
    nameUpdated: `${$check} <b>নাম আপডেট হয়েছে!</b>\n<code>${SEP}</code>\n${$user} নতুন নাম: <b>{name}</b>`,
    earnCategoryMsg: `${$money} <b>আয় কেন্দ্র</b>\n<code>${SEP}</code>\n${$rocket} কীভাবে আয় করতে চান বেছে নিন:\n<code>${LINE}</code>\n${$tv} <b>বিজ্ঞাপন দেখুন</b>  —  প্রতি বিজ্ঞাপনে +$0.01\n${$clip} <b>ডেইলি টাস্ক</b>  —  সম্পূর্ণ করলে বোনাস\n${$people} <b>রেফারেল</b>  —  প্রতি বন্ধুতে আয়\n<code>${LINE}</code>\n${$zap} <i>সব আয় তাৎক্ষণিক</i>`,
  },

  // ─────────────────────────── HINDI ──────────────────────────────
  hi: {
    earn:      "💰 कमाई",
    profile:   "👤 प्रोफ़ाइल",
    dailyTask: "📋 दैनिक कार्य",
    referral:  "👥 रेफ़रल",
    withdraw:  "💸 निकालें",
    language:  "🌐 भाषा",
    adultBot:  "🔞 Adult",
    movieBot:  "🎬 Movies",
    rules:     "📜 नियम",

    welcome: `${$movie} <b>DesiXX Video Bot में स्वागत है!</b>
<code>${SEP}</code>
${$money} विज्ञापन देखें — <b>असली पैसे</b> कमाएँ
${$people} दोस्त लाएँ — <b>तुरंत बोनस</b> पाएँ
${$clip} दैनिक कार्य — <b>अतिरिक्त पुरस्कार</b>
${$cashfly} <b>bKash · Nagad · USDT</b> में निकालें
<code>${LINE}</code>
${$globe} <b>शुरू करने के लिए भाषा चुनें:</b>`,

    langSet:    `${$check} <b>भाषा हिंदी में सेट हो गई!</b>`,
    menuMsg:    `${$shine} <b>मुख्य मेनू</b>\n<code>${LINE}</code>\n${$zap} नीचे बटन दबाएँ:`,
    selectLang: `${$globe} <b>अपनी भाषा चुनें:</b>`,

    earnMsg: `${$money} <b>कमाई केंद्र</b>
<code>${SEP}</code>
${$chart} <b>प्रगति:</b>  <code>{bar}</code>  <b>{watched} / {max}</b>
<code>${LINE}</code>
${$dollar} <i>आज की कमाई:</i>   <b>$ {todayEarned}</b>
${$wallet} <i>आपका बैलेंस:</i>  <b>$ {balance}</b>
${$zap} प्रति विज्ञापन: <b>$0.01</b>  ·  <b>{remaining}</b> बाकी
<code>${LINE}</code>`,

    earnDone: `${$check} <b>आज के सभी विज्ञापन देख लिए!</b>
<code>${SEP}</code>
${$party} बढ़िया! आपने सभी <b>{max}</b> विज्ञापन देखे।
${$wallet} <i>वर्तमान बैलेंस:</i> <b>$ {balance}</b>
<code>${LINE}</code>
${$moon} अधिक कमाई के लिए <b>कल</b> आएँ!`,

    watchAd: "📺 विज्ञापन देखें  (+$0.01)",
    refresh:  "🔄 बैलेंस रिफ्रेश",

    adStarted: `${$tv} <b>विज्ञापन तैयार है — अभी देखें!</b>
<code>${SEP}</code>
${$clock} कम से कम <b>10 सेकंड</b> देखें
${$check} फिर नीचे <b>मैंने देखा</b> दबाएँ
<code>${LINE}</code>
<blockquote>${$warn} जल्दी दबाने पर = <b>चेतावनी जारी</b>
${$lock} हर विज्ञापन का अलग टोकन — <b>एक बार उपयोग</b></blockquote>`,

    watchNow:   "▶️ विज्ञापन खोलें",
    adVerify:   "✅ मैंने देखा",
    adComplete: `${$check} <b>+$0.01 सफलतापूर्वक जमा!</b>
<code>${SEP}</code>
${$wallet} बैलेंस: <b>$ {balance}</b>
${$chart} आज: <b>{watched} / {max}</b> विज्ञापन देखे
<code>${LINE}</code>
${$fire} <i>जारी रखें — हर विज्ञापन मायने रखता है!</i>`,

    adFailed: `${$warn} <b>सत्यापन विफल — बहुत जल्दी!</b>
<code>${SEP}</code>
सत्यापन से पहले पूरा विज्ञापन देखना जरूरी है।
<code>${LINE}</code>
<blockquote>${$warn} चेतावनी <b>{warnCount} / {warnLimit}</b> जारी।
${$ban} <b>{warnLimit}</b> चेतावनियों पर → <b>स्थायी बैन</b></blockquote>`,

    adCheatBan: `${$ban} <b>खाता स्थायी रूप से बैन</b>
<code>${SEP}</code>
<blockquote>आपने अनुमत उल्लंघन सीमा पार कर ली।
यह निर्णय <b>अपरिवर्तनीय</b> है।</blockquote>
<code>${LINE}</code>
${$inbox} गलती लगे तो सहायता से संपर्क करें।`,

    adAlreadyPending: `${$hourglass} <b>विज्ञापन चल रहा है</b> — नया शुरू करने से पहले इसे पूरा करें।`,
    adsLimit: `${$check} <b>आज के सभी {max} विज्ञापन देख लिए!</b>
<code>${SEP}</code>
${$wallet} बैलेंस: <b>$ {balance}</b>
${$moon} कल फिर आएँ!`,

    channelRequired: `${$lock} <b>पहले आवश्यक चैनल जॉइन करें</b>
<code>${SEP}</code>
कमाई शुरू करने के लिए <b>सभी</b> चैनल जॉइन करें:

{channels}
<code>${LINE}</code>
${$check} जॉइन करने के बाद <b>मैंने जॉइन किया</b> दबाएँ।`,

    joinedVerify:      "✅ मैंने सब जॉइन किया",
    channelNotJoined:  "❌ अभी जॉइन नहीं किया — पहले जॉइन करें।",
    channelJoinReward: `${$party} चैनल जॉइन किया! <b>+\${reward}</b> जमा।`,

    profileMsg: `${$user} <b>मेरी प्रोफ़ाइल</b>
<code>${SEP}</code>
${$idcard} <i>यूज़र ID:</i>     <code>{id}</code>
${$user} <i>नाम:</i>          <b>{name}</b>
${$globe} <i>भाषा:</i>         {lang}
<code>${LINE}</code>
${$wallet} <i>बैलेंस:</i>         <b>$ {balance}</b>
${$up} <i>कुल कमाई:</i>       <b>$ {totalEarned}</b>
<code>${LINE}</code>
${$chart} <i>आज के विज्ञापन:</i> <b>{adsToday} / {maxAds}</b>
${$people} <i>रेफ़रल:</i>         <b>{referrals}</b>
${$warn} <i>चेतावनियाँ:</i>      <b>{warnings} / {warnLimit}</b>
${$cal} <i>शामिल हुए:</i>      <b>{joined}</b>
<code>${LINE}</code>
<blockquote>📜 <b>नियम</b>
▸ प्रतिदिन अधिकतम <b>{maxAds}</b> विज्ञापन
▸ बॉट, स्क्रिप्ट या धोखाधड़ी वर्जित
▸ न्यूनतम निकासी: <b>$ {minWd}</b>
▸ <b>{warnLimit}</b> उल्लंघन = स्थायी बैन
▸ एक व्यक्ति — एक खाता</blockquote>`,

    referralMsg: `${$people} <b>रेफ़रल प्रोग्राम</b>
<code>${SEP}</code>
${$shine} दोस्त लाएँ — प्रति व्यक्ति <b>$ {refReward}</b> कमाएँ!
<code>${LINE}</code>
${$people} <i>कुल रेफ़रल:</i>   <b>{count}</b>
${$money} <i>रेफ़रल कमाई:</i>  <b>$ {earned}</b>
<code>${LINE}</code>
${$link} <b>आपका रेफ़रल लिंक:</b>
<code>{link}</code>
<code>${LINE}</code>
${$share} <i>लिंक शेयर करें — दोस्त जुड़े तो तुरंत कमाई!</i>`,

    shareLink: "📨 लिंक शेयर करें",

    dailyTaskMsg: `${$clip} <b>दैनिक कार्य</b>
<code>${SEP}</code>
${$sparkle} सभी कार्य पूरे करें — बोनस अनलॉक करें!
${$refresh} रोज़ रात 12 बजे रीसेट
<code>${LINE}</code>
{tasks}
<code>${LINE}</code>
${$check} प्रगति: <b>{done} / {total}</b>
${$gift} दैनिक बोनस: <b>$ {bonus}</b>`,

    taskWatchAds:   `${$tv} आज <b>{threshold}</b> विज्ञापन देखें  →  <b>+$ {reward}</b>`,
    taskShare:      `${$share} बॉट 1 दोस्त से शेयर करें  →  <b>+$ {reward}</b>`,
    taskChannel:    `${$mega} जॉइन करें: <b>{name}</b>  →  <b>+$ {reward}</b>`,
    taskReferral:   `${$people} 1 नया यूज़र लाएँ  →  <b>+$ {reward}</b>`,
    taskDonePrefix:    "✅ ",
    taskPendingPrefix: "⬜ ",
    claimBonus:     "🎁 दैनिक बोनस लें",
    bonusClaimed: `${$gift} <b>दैनिक बोनस मिल गया!</b>
<code>${SEP}</code>
${$money} बोनस: <b>+$ {bonus}</b>
${$wallet} नया बैलेंस: <b>$ {balance}</b>`,

    alreadyClaimed:   `${$check} आज का बोनस पहले ही लिया जा चुका है!`,
    tasksNotComplete: `${$warn} पहले सभी कार्य पूरे करें!`,
    taskShareBtn:     "📨 बॉट शेयर करें",
    taskVerifyBtn:    "✅ सत्यापित करें",

    withdrawMsg: `${$cashfly} <b>निकासी</b>
<code>${SEP}</code>
${$wallet} आपका बैलेंस: <b>$ {balance}</b>
${$warn} न्यूनतम: <b>$ {minWd}</b>
<code>${LINE}</code>
${$phone} <b>भुगतान विधि चुनें:</b>`,

    withdrawLow: `${$cross} <b>अपर्याप्त बैलेंस</b>
<code>${SEP}</code>
निकासी के लिए कम से कम <b>$ {minWd}</b> चाहिए।
${$wallet} <i>आपका बैलेंस:</i> <b>$ {balance}</b>`,

    withdrawAddress:  `${$note} अपना <b>{method}</b> नंबर या वॉलेट पता दर्ज करें:`,
    withdrawConfirm: `${$check} <b>निकासी अनुरोध सबमिट!</b>
<code>${SEP}</code>
${$dollar} राशि:     <b>$ {amount}</b>
${$bank} विधि:     <b>{method}</b>
${$mailbox} पता:     <code>{address}</code>
<code>${LINE}</code>
${$clock} <b>24 घंटे</b> में भुगतान प्रक्रिया होगी।`,

    withdrawPending: `${$hourglass} पहले से एक <b>लंबित निकासी</b> है। प्रतीक्षा करें।`,
    withdrawSelect:  "भुगतान विधि चुनें:",

    banned: `${$ban} <b>खाता बैन</b>
<code>${SEP}</code>
<blockquote>नियमों के उल्लंघन के कारण आपका खाता बैन किया गया।</blockquote>
<code>${LINE}</code>
${$inbox} गलती लगे तो सहायता से संपर्क करें।`,

    startFirst: `${$warn} शुरू करने के लिए /start भेजें।`,
    unknownCmd: `नेविगेट करने के लिए मेनू बटन का उपयोग करें। 👇`,
    profileBtn: "👤 यूज़र प्रोफ़ाइल",
    earnBtn: "💰 कमाएँ",
    withdrawalBtn: "💸 निकालें",
    referralBtn: "👥 रेफ़रल",
    adultBtn2: "🔞 एडल्ट",
    movieSeriesBtn: "🎬 मूवी-सीरीज़",
    setWalletBtn: "💳 वॉलेट सेट करें",
    changeLangBtn: "🌐 भाषा बदलें",
    watchAdsBtn: "📺 विज्ञापन देखें",
    dailyTasksBtn: "📋 दैनिक कार्य",
    confirmBtn: "✅ पुष्टि करें",
    changeMethodBtn: "🔄 विधि बदलें",
    cancelBtn: "❌ रद्द करें",
    mainMenuBtn: "🏠 मुख्य मेनू",
    backBtn: "⬅️ वापस",
    confirmWalletMsg: `${$check} <b>वॉलेट सेव पुष्टि</b>\n<code>${SEP}</code>\n💳 विधि: <b>{method}</b>\n${$mailbox} पता: <code>{address}</code>`,
    confirmWdMsg: `${$check} <b>निकासी पुष्टि</b>\n<code>${SEP}</code>\n💳 विधि: <b>{method}</b>\n${$mailbox} पता: <code>{address}</code>\n${$dollar} राशि: <b>$ {balance}</b>`,
    walletUpdated: `${$check} <b>वॉलेट अपडेट हो गया!</b>\n<code>${SEP}</code>\n💳 विधि: <b>{method}</b>\n${$mailbox} पता: <code>{address}</code>`,
    updateWalletMsg: `💳 <b>वॉलेट अपडेट करें</b>\n<code>${SEP}</code>\n${$phone} भुगतान विधि चुनें:`,
    nameUpdated: `${$check} <b>नाम अपडेट हो गया!</b>\n<code>${SEP}</code>\n${$user} नया नाम: <b>{name}</b>`,
    earnCategoryMsg: `${$money} <b>कमाई केंद्र</b>\n<code>${SEP}</code>\n${$rocket} आज कमाने का तरीका चुनें:\n<code>${LINE}</code>\n${$tv} <b>विज्ञापन देखें</b>  —  प्रति विज्ञापन +$0.01\n${$clip} <b>दैनिक कार्य</b>  —  पूरा करने पर बोनस\n${$people} <b>रेफ़रल</b>  —  प्रति दोस्त कमाएँ\n<code>${LINE}</code>\n${$zap} <i>सभी कमाई तुरंत</i>`,
  },

  // ─────────────────────────── ARABIC ─────────────────────────────
  ar: {
    earn:      "💰 الكسب",
    profile:   "👤 الملف",
    dailyTask: "📋 المهام",
    referral:  "👥 الإحالة",
    withdraw:  "💸 السحب",
    language:  "🌐 اللغة",
    adultBot:  "🔞 Adult",
    movieBot:  "🎬 Movies",
    rules:     "📜 القواعد",

    welcome: `${$movie} <b>أهلاً بك في DesiXX Video Bot!</b>
<code>${SEP}</code>
${$money} شاهد الإعلانات — اكسب <b>أموالاً حقيقية</b>
${$people} ادعُ أصدقاء — <b>مكافأة فورية</b>
${$clip} المهام اليومية — <b>مكافآت إضافية</b>
${$cashfly} اسحب عبر <b>bKash · Nagad · USDT</b>
<code>${LINE}</code>
${$globe} <b>اختر لغتك للبدء:</b>`,

    langSet:    `${$check} <b>تم تعيين اللغة إلى العربية!</b>`,
    menuMsg:    `${$shine} <b>القائمة الرئيسية</b>\n<code>${LINE}</code>\n${$zap} اضغط على زر:`,
    selectLang: `${$globe} <b>اختر اللغة:</b>`,

    earnMsg: `${$money} <b>مركز الكسب</b>
<code>${SEP}</code>
${$chart} <b>التقدم:</b>  <code>{bar}</code>  <b>{watched} / {max}</b>
<code>${LINE}</code>
${$dollar} <i>كسب اليوم:</i>  <b>$ {todayEarned}</b>
${$wallet} <i>رصيدك:</i>     <b>$ {balance}</b>
${$zap} لكل إعلان: <b>$0.01</b>  ·  <b>{remaining}</b> متبقٍ
<code>${LINE}</code>`,

    earnDone: `${$check} <b>شاهدت جميع إعلانات اليوم!</b>
<code>${SEP}</code>
${$party} رائع! شاهدت جميع <b>{max}</b> إعلانات.
${$wallet} <i>الرصيد:</i> <b>$ {balance}</b>
<code>${LINE}</code>
${$moon} عُد <b>غداً</b> للمزيد!`,

    watchAd: "📺 شاهد إعلاناً  (+$0.01)",
    refresh:  "🔄 تحديث الرصيد",

    adStarted: `${$tv} <b>الإعلان جاهز — شاهد الآن!</b>
<code>${SEP}</code>
${$clock} شاهد لمدة <b>10 ثوانٍ</b> على الأقل
${$check} ثم اضغط <b>شاهدت</b>
<code>${LINE}</code>
<blockquote>${$warn} الضغط المبكر = <b>تحذير يُصدر</b>
${$lock} رمز فريد — <b>استخدام واحد فقط</b></blockquote>`,

    watchNow:   "▶️ فتح الإعلان",
    adVerify:   "✅ شاهدت",
    adComplete: `${$check} <b>+$0.01 أضيف بنجاح!</b>
<code>${SEP}</code>
${$wallet} الرصيد: <b>$ {balance}</b>
${$chart} اليوم: <b>{watched} / {max}</b> إعلان
<code>${LINE}</code>
${$fire} <i>استمر — كل إعلان يهم!</i>`,

    adFailed: `${$warn} <b>سريع جداً — فشل التحقق!</b>
<code>${SEP}</code>
يجب مشاهدة الإعلان كاملاً قبل التحقق.
<code>${LINE}</code>
<blockquote>${$warn} تحذير <b>{warnCount} / {warnLimit}</b> صدر.
${$ban} عند <b>{warnLimit}</b> تحذيرات → <b>حظر دائم</b></blockquote>`,

    adCheatBan: `${$ban} <b>تم حظر الحساب نهائياً</b>
<code>${SEP}</code>
<blockquote>تجاوزت حد الانتهاكات المسموح.
هذا القرار <b>نهائي</b>.</blockquote>
<code>${LINE}</code>
${$inbox} تواصل مع الدعم إن كان خطأً.`,

    adAlreadyPending: `${$hourglass} <b>يوجد إعلان جارٍ</b> — أكمله أولاً.`,
    adsLimit: `${$check} <b>شاهدت جميع {max} إعلانات اليوم!</b>
<code>${SEP}</code>
${$wallet} الرصيد: <b>$ {balance}</b>
${$moon} عُد <b>غداً</b>!`,

    channelRequired: `${$lock} <b>انضم للقنوات المطلوبة أولاً</b>
<code>${SEP}</code>
يجب الانضمام لـ<b>جميع</b> القنوات للبدء:

{channels}
<code>${LINE}</code>
${$check} بعد الانضمام اضغط <b>انضممت للكل</b>.`,

    joinedVerify:      "✅ انضممت للكل",
    channelNotJoined:  "❌ لم تنضم بعد — انضم أولاً.",
    channelJoinReward: `${$party} انضممت للقناة! <b>+\${reward}</b> أضيف.`,

    profileMsg: `${$user} <b>ملفي الشخصي</b>
<code>${SEP}</code>
${$idcard} <i>معرف المستخدم:</i> <code>{id}</code>
${$user} <i>الاسم:</i>          <b>{name}</b>
${$globe} <i>اللغة:</i>          {lang}
<code>${LINE}</code>
${$wallet} <i>الرصيد:</i>           <b>$ {balance}</b>
${$up} <i>إجمالي الكسب:</i>    <b>$ {totalEarned}</b>
<code>${LINE}</code>
${$chart} <i>إعلانات اليوم:</i>  <b>{adsToday} / {maxAds}</b>
${$people} <i>الإحالات:</i>        <b>{referrals}</b>
${$warn} <i>التحذيرات:</i>       <b>{warnings} / {warnLimit}</b>
${$cal} <i>تاريخ الانضمام:</i> <b>{joined}</b>
<code>${LINE}</code>
<blockquote>📜 <b>القواعد</b>
▸ أقصى <b>{maxAds}</b> إعلانات يومياً
▸ لا بوتات أو غش
▸ الحد الأدنى للسحب <b>$ {minWd}</b>
▸ <b>{warnLimit}</b> انتهاكات = حظر دائم
▸ حساب واحد لكل شخص</blockquote>`,

    referralMsg: `${$people} <b>برنامج الإحالة</b>
<code>${SEP}</code>
${$shine} ادعُ أصدقاء — اكسب <b>$ {refReward}</b> لكل شخص!
<code>${LINE}</code>
${$people} <i>إجمالي الإحالات:</i>  <b>{count}</b>
${$money} <i>أرباح الإحالة:</i>    <b>$ {earned}</b>
<code>${LINE}</code>
${$link} <b>رابط إحالتك:</b>
<code>{link}</code>
<code>${LINE}</code>
${$share} <i>شارك الرابط — اكسب فوراً عند انضمامهم!</i>`,

    shareLink: "📨 مشاركة الرابط",

    dailyTaskMsg: `${$clip} <b>المهام اليومية</b>
<code>${SEP}</code>
${$sparkle} أكمل جميع المهام — احصل على المكافأة!
${$refresh} تُعاد يومياً منتصف الليل
<code>${LINE}</code>
{tasks}
<code>${LINE}</code>
${$check} التقدم: <b>{done} / {total}</b>
${$gift} المكافأة اليومية: <b>$ {bonus}</b>`,

    taskWatchAds:   `${$tv} شاهد <b>{threshold}</b> إعلانات اليوم  →  <b>+$ {reward}</b>`,
    taskShare:      `${$share} شارك البوت مع صديق  →  <b>+$ {reward}</b>`,
    taskChannel:    `${$mega} انضم: <b>{name}</b>  →  <b>+$ {reward}</b>`,
    taskReferral:   `${$people} أحضر مستخدماً جديداً  →  <b>+$ {reward}</b>`,
    taskDonePrefix:    "✅ ",
    taskPendingPrefix: "⬜ ",
    claimBonus:     "🎁 احصل على المكافأة اليومية",
    bonusClaimed: `${$gift} <b>تم الحصول على المكافأة اليومية!</b>
<code>${SEP}</code>
${$money} المكافأة: <b>+$ {bonus}</b>
${$wallet} الرصيد الجديد: <b>$ {balance}</b>`,

    alreadyClaimed:   `${$check} طالبت بمكافأة اليوم بالفعل!`,
    tasksNotComplete: `${$warn} أكمل جميع المهام أولاً!`,
    taskShareBtn:     "📨 شارك البوت",
    taskVerifyBtn:    "✅ تحقق",

    withdrawMsg: `${$cashfly} <b>سحب الأموال</b>
<code>${SEP}</code>
${$wallet} رصيدك:     <b>$ {balance}</b>
${$warn} الحد الأدنى: <b>$ {minWd}</b>
<code>${LINE}</code>
${$phone} <b>اختر طريقة الدفع:</b>`,

    withdrawLow: `${$cross} <b>رصيد غير كافٍ</b>
<code>${SEP}</code>
تحتاج <b>$ {minWd}</b> على الأقل للسحب.
${$wallet} <i>رصيدك:</i> <b>$ {balance}</b>`,

    withdrawAddress:  `${$note} أدخل رقم <b>{method}</b> أو عنوان المحفظة:`,
    withdrawConfirm: `${$check} <b>طلب السحب مُرسَل!</b>
<code>${SEP}</code>
${$dollar} المبلغ:   <b>$ {amount}</b>
${$bank} الطريقة:  <b>{method}</b>
${$mailbox} العنوان:  <code>{address}</code>
<code>${LINE}</code>
${$clock} الدفع خلال <b>24 ساعة</b>.`,

    withdrawPending: `${$hourglass} لديك <b>طلب سحب معلق</b>. انتظر معالجته.`,
    withdrawSelect:  "اختر طريقة الدفع:",

    banned: `${$ban} <b>تم حظر الحساب</b>
<code>${SEP}</code>
<blockquote>تم حظر حسابك بسبب انتهاك القواعد.</blockquote>
<code>${LINE}</code>
${$inbox} تواصل مع الدعم إن كان خطأً.`,

    startFirst: `${$warn} أرسل /start للبدء.`,
    unknownCmd: `استخدم أزرار القائمة للتنقل. 👇`,
    profileBtn: "👤 الملف الشخصي",
    earnBtn: "💰 اكسب",
    withdrawalBtn: "💸 اسحب",
    referralBtn: "👥 إحالة",
    adultBtn2: "🔞 للبالغين",
    movieSeriesBtn: "🎬 أفلام-مسلسلات",
    setWalletBtn: "💳 إعداد المحفظة",
    changeLangBtn: "🌐 تغيير اللغة",
    watchAdsBtn: "📺 شاهد إعلانات",
    dailyTasksBtn: "📋 المهام اليومية",
    confirmBtn: "✅ تأكيد",
    changeMethodBtn: "🔄 تغيير الطريقة",
    cancelBtn: "❌ إلغاء",
    mainMenuBtn: "🏠 القائمة الرئيسية",
    backBtn: "⬅️ رجوع",
    confirmWalletMsg: `${$check} <b>تأكيد حفظ المحفظة</b>\n<code>${SEP}</code>\n💳 الطريقة: <b>{method}</b>\n${$mailbox} العنوان: <code>{address}</code>`,
    confirmWdMsg: `${$check} <b>تأكيد السحب</b>\n<code>${SEP}</code>\n💳 الطريقة: <b>{method}</b>\n${$mailbox} العنوان: <code>{address}</code>\n${$dollar} المبلغ: <b>$ {balance}</b>`,
    walletUpdated: `${$check} <b>تم تحديث المحفظة!</b>\n<code>${SEP}</code>\n💳 الطريقة: <b>{method}</b>\n${$mailbox} العنوان: <code>{address}</code>`,
    updateWalletMsg: `💳 <b>تحديث المحفظة</b>\n<code>${SEP}</code>\n${$phone} اختر طريقة الدفع:`,
    nameUpdated: `${$check} <b>تم تحديث الاسم!</b>\n<code>${SEP}</code>\n${$user} الاسم الجديد: <b>{name}</b>`,
    earnCategoryMsg: `${$money} <b>مركز الكسب</b>\n<code>${SEP}</code>\n${$rocket} اختر كيفية الكسب:\n<code>${LINE}</code>\n${$tv} <b>شاهد إعلانات</b>  —  +$0.01 لكل إعلان\n${$clip} <b>مهام يومية</b>  —  مكافأة عند الإنجاز\n${$people} <b>إحالة</b>  —  اكسب لكل صديق\n<code>${LINE}</code>\n${$zap} <i>جميع المكاسب فورية</i>`,
  },

  // ─────────────────────────── RUSSIAN ────────────────────────────
  ru: {
    earn:      "💰 Заработок",
    profile:   "👤 Профиль",
    dailyTask: "📋 Задания",
    referral:  "👥 Рефералы",
    withdraw:  "💸 Вывод",
    language:  "🌐 Язык",
    adultBot:  "🔞 Adult",
    movieBot:  "🎬 Фильмы",
    rules:     "📜 Правила",

    welcome: `${$movie} <b>Добро пожаловать в DesiXX Video Bot!</b>
<code>${SEP}</code>
${$money} Смотрите рекламу — зарабатывайте <b>реальные деньги</b>
${$people} Приглашайте друзей — <b>мгновенный бонус</b>
${$clip} Ежедневные задания — <b>дополнительные награды</b>
${$cashfly} Вывод через <b>bKash · Nagad · USDT</b>
<code>${LINE}</code>
${$globe} <b>Выберите язык для начала:</b>`,

    langSet:    `${$check} <b>Язык установлен на русский!</b>`,
    menuMsg:    `${$shine} <b>Главное меню</b>\n<code>${LINE}</code>\n${$zap} Нажмите кнопку:`,
    selectLang: `${$globe} <b>Выберите язык:</b>`,

    earnMsg: `${$money} <b>ЦЕНТР ЗАРАБОТКА</b>
<code>${SEP}</code>
${$chart} <b>Прогресс:</b>  <code>{bar}</code>  <b>{watched} / {max}</b>
<code>${LINE}</code>
${$dollar} <i>Заработано сегодня:</i>  <b>$ {todayEarned}</b>
${$wallet} <i>Ваш баланс:</i>          <b>$ {balance}</b>
${$zap} За рекламу: <b>$0.01</b>  ·  Осталось: <b>{remaining}</b>
<code>${LINE}</code>`,

    earnDone: `${$check} <b>Все реклама на сегодня просмотрена!</b>
<code>${SEP}</code>
${$party} Отличная работа! Просмотрено <b>{max}</b> реклам.
${$wallet} <i>Текущий баланс:</i> <b>$ {balance}</b>
<code>${LINE}</code>
${$moon} Возвращайтесь <b>завтра</b> за новыми!`,

    watchAd: "📺 Смотреть рекламу  (+$0.01)",
    refresh:  "🔄 Обновить баланс",

    adStarted: `${$tv} <b>Реклама готова — смотрите!</b>
<code>${SEP}</code>
${$clock} Смотрите не менее <b>10 секунд</b>
${$check} Затем нажмите <b>Я посмотрел</b>
<code>${LINE}</code>
<blockquote>${$warn} Ранний клик = <b>предупреждение</b>
${$lock} Уникальный токен — <b>только один раз</b></blockquote>`,

    watchNow:   "▶️ Открыть рекламу",
    adVerify:   "✅ Я посмотрел",
    adComplete: `${$check} <b>+$0.01 успешно начислено!</b>
<code>${SEP}</code>
${$wallet} Баланс: <b>$ {balance}</b>
${$chart} Сегодня: <b>{watched} / {max}</b> реклам
<code>${LINE}</code>
${$fire} <i>Продолжайте — каждая реклама важна!</i>`,

    adFailed: `${$warn} <b>Слишком быстро — верификация не пройдена!</b>
<code>${SEP}</code>
Необходимо просмотреть <b>полную</b> рекламу перед верификацией.
<code>${LINE}</code>
<blockquote>${$warn} Предупреждение <b>{warnCount} / {warnLimit}</b>.
${$ban} При <b>{warnLimit}</b> предупреждениях → <b>постоянная блокировка</b></blockquote>`,

    adCheatBan: `${$ban} <b>Аккаунт заблокирован навсегда</b>
<code>${SEP}</code>
<blockquote>Превышен лимит нарушений.
Это решение <b>окончательное</b>.</blockquote>
<code>${LINE}</code>
${$inbox} Свяжитесь с поддержкой, если считаете это ошибкой.`,

    adAlreadyPending: `${$hourglass} <b>Реклама в процессе</b> — завершите её перед новой.`,
    adsLimit: `${$check} <b>Все {max} реклам просмотрены!</b>
<code>${SEP}</code>
${$wallet} Баланс: <b>$ {balance}</b>
${$moon} Возвращайтесь <b>завтра</b>!`,

    channelRequired: `${$lock} <b>Сначала вступите в каналы</b>
<code>${SEP}</code>
Для начала заработка вступите во <b>все</b> каналы:

{channels}
<code>${LINE}</code>
${$check} После вступления нажмите <b>Я вступил</b>.`,

    joinedVerify:      "✅ Я вступил во все",
    channelNotJoined:  "❌ Ещё не вступили — вступите сначала.",
    channelJoinReward: `${$party} Вступили в канал! <b>+\${reward}</b> начислено.`,

    profileMsg: `${$user} <b>МОЙ ПРОФИЛЬ</b>
<code>${SEP}</code>
${$idcard} <i>ID пользователя:</i>  <code>{id}</code>
${$user} <i>Имя:</i>               <b>{name}</b>
${$globe} <i>Язык:</i>              {lang}
<code>${LINE}</code>
${$wallet} <i>Баланс:</i>              <b>$ {balance}</b>
${$up} <i>Всего заработано:</i>   <b>$ {totalEarned}</b>
<code>${LINE}</code>
${$chart} <i>Реклама сегодня:</i>  <b>{adsToday} / {maxAds}</b>
${$people} <i>Рефералы:</i>          <b>{referrals}</b>
${$warn} <i>Предупреждения:</i>    <b>{warnings} / {warnLimit}</b>
${$cal} <i>Дата регистрации:</i> <b>{joined}</b>
<code>${LINE}</code>
<blockquote>📜 <b>ПРАВИЛА</b>
▸ Макс. <b>{maxAds}</b> реклам в день
▸ Боты и читинг запрещены
▸ Минимальный вывод: <b>$ {minWd}</b>
▸ <b>{warnLimit}</b> нарушений = постоянный бан
▸ Один аккаунт на человека</blockquote>`,

    referralMsg: `${$people} <b>РЕФЕРАЛЬНАЯ ПРОГРАММА</b>
<code>${SEP}</code>
${$shine} Приглашайте друзей — зарабатывайте <b>$ {refReward}</b> за каждого!
<code>${LINE}</code>
${$people} <i>Всего рефералов:</i>   <b>{count}</b>
${$money} <i>Реферальный доход:</i> <b>$ {earned}</b>
<code>${LINE}</code>
${$link} <b>Ваша реферальная ссылка:</b>
<code>{link}</code>
<code>${LINE}</code>
${$share} <i>Делитесь ссылкой — зарабатывайте мгновенно!</i>`,

    shareLink: "📨 Поделиться ссылкой",

    dailyTaskMsg: `${$clip} <b>ЕЖЕДНЕВНЫЕ ЗАДАНИЯ</b>
<code>${SEP}</code>
${$sparkle} Выполните все задания — получите бонус!
${$refresh} Сбрасывается каждую полночь
<code>${LINE}</code>
{tasks}
<code>${LINE}</code>
${$check} Прогресс: <b>{done} / {total}</b>
${$gift} Ежедневный бонус: <b>$ {bonus}</b>`,

    taskWatchAds:   `${$tv} Посмотрите <b>{threshold}</b> реклам сегодня  →  <b>+$ {reward}</b>`,
    taskShare:      `${$share} Поделитесь ботом с другом  →  <b>+$ {reward}</b>`,
    taskChannel:    `${$mega} Вступите: <b>{name}</b>  →  <b>+$ {reward}</b>`,
    taskReferral:   `${$people} Приведите нового пользователя  →  <b>+$ {reward}</b>`,
    taskDonePrefix:    "✅ ",
    taskPendingPrefix: "⬜ ",
    claimBonus:     "🎁 Получить ежедневный бонус",
    bonusClaimed: `${$gift} <b>Ежедневный бонус получен!</b>
<code>${SEP}</code>
${$money} Бонус: <b>+$ {bonus}</b>
${$wallet} Новый баланс: <b>$ {balance}</b>`,

    alreadyClaimed:   `${$check} Бонус сегодня уже получен!`,
    tasksNotComplete: `${$warn} Сначала выполните все задания!`,
    taskShareBtn:     "📨 Поделиться ботом",
    taskVerifyBtn:    "✅ Проверить",

    withdrawMsg: `${$cashfly} <b>ВЫВОД СРЕДСТВ</b>
<code>${SEP}</code>
${$wallet} Ваш баланс: <b>$ {balance}</b>
${$warn} Минимум: <b>$ {minWd}</b>
<code>${LINE}</code>
${$phone} <b>Выберите способ оплаты:</b>`,

    withdrawLow: `${$cross} <b>Недостаточный баланс</b>
<code>${SEP}</code>
Необходимо минимум <b>$ {minWd}</b> для вывода.
${$wallet} <i>Ваш баланс:</i> <b>$ {balance}</b>`,

    withdrawAddress:  `${$note} Введите ваш номер <b>{method}</b> или адрес кошелька:`,
    withdrawConfirm: `${$check} <b>Запрос на вывод подан!</b>
<code>${SEP}</code>
${$dollar} Сумма:   <b>$ {amount}</b>
${$bank} Способ:  <b>{method}</b>
${$mailbox} Адрес:   <code>{address}</code>
<code>${LINE}</code>
${$clock} Оплата в течение <b>24 часов</b>.`,

    withdrawPending: `${$hourglass} У вас уже есть <b>ожидающий вывод</b>. Подождите.`,
    withdrawSelect:  "Выберите способ:",

    banned: `${$ban} <b>Аккаунт заблокирован</b>
<code>${SEP}</code>
<blockquote>Ваш аккаунт заблокирован за нарушение правил.</blockquote>
<code>${LINE}</code>
${$inbox} Свяжитесь с поддержкой, если считаете это ошибкой.`,

    startFirst: `${$warn} Отправьте /start для начала.`,
    unknownCmd: `Используйте кнопки меню для навигации. 👇`,
    profileBtn: "👤 Профиль",
    earnBtn: "💰 Заработать",
    withdrawalBtn: "💸 Вывод",
    referralBtn: "👥 Рефералы",
    adultBtn2: "🔞 Взрослые",
    movieSeriesBtn: "🎬 Фильмы-Сериалы",
    setWalletBtn: "💳 Настроить кошелёк",
    changeLangBtn: "🌐 Сменить язык",
    watchAdsBtn: "📺 Смотреть рекламу",
    dailyTasksBtn: "📋 Ежедневные задания",
    confirmBtn: "✅ Подтвердить",
    changeMethodBtn: "🔄 Сменить способ",
    cancelBtn: "❌ Отмена",
    mainMenuBtn: "🏠 Главное меню",
    backBtn: "⬅️ Назад",
    confirmWalletMsg: `${$check} <b>Подтвердить сохранение кошелька</b>\n<code>${SEP}</code>\n💳 Способ: <b>{method}</b>\n${$mailbox} Адрес: <code>{address}</code>`,
    confirmWdMsg: `${$check} <b>Подтвердить вывод</b>\n<code>${SEP}</code>\n💳 Способ: <b>{method}</b>\n${$mailbox} Адрес: <code>{address}</code>\n${$dollar} Сумма: <b>$ {balance}</b>`,
    walletUpdated: `${$check} <b>Кошелёк обновлён!</b>\n<code>${SEP}</code>\n💳 Способ: <b>{method}</b>\n${$mailbox} Адрес: <code>{address}</code>`,
    updateWalletMsg: `💳 <b>Обновить кошелёк</b>\n<code>${SEP}</code>\n${$phone} Выберите способ оплаты:`,
    nameUpdated: `${$check} <b>Имя обновлено!</b>\n<code>${SEP}</code>\n${$user} Новое имя: <b>{name}</b>`,
    earnCategoryMsg: `${$money} <b>ЦЕНТР ЗАРАБОТКА</b>\n<code>${SEP}</code>\n${$rocket} Выберите способ заработка:\n<code>${LINE}</code>\n${$tv} <b>Смотреть рекламу</b>  —  +$0.01 за рекламу\n${$clip} <b>Ежедневные задания</b>  —  бонус за выполнение\n${$people} <b>Рефералы</b>  —  зарабатывайте за друзей\n<code>${LINE}</code>\n${$zap} <i>Все начисления мгновенны</i>`,
  },

  // ─────────────────────────── TURKISH ────────────────────────────
  tr: {
    earn:      "💰 Kazan",
    profile:   "👤 Profil",
    dailyTask: "📋 Görevler",
    referral:  "👥 Referans",
    withdraw:  "💸 Çekim",
    language:  "🌐 Dil",
    adultBot:  "🔞 Adult",
    movieBot:  "🎬 Filmler",
    rules:     "📜 Kurallar",

    welcome: `${$movie} <b>DesiXX Video Bot'a Hoş Geldiniz!</b>
<code>${SEP}</code>
${$money} Reklamları izleyin — <b>gerçek para</b> kazanın
${$people} Arkadaş davet edin — <b>anında bonus</b>
${$clip} Günlük görevler — <b>ekstra ödüller</b>
${$cashfly} <b>bKash · Nagad · USDT</b> ile çekim
<code>${LINE}</code>
${$globe} <b>Başlamak için dilinizi seçin:</b>`,

    langSet:    `${$check} <b>Dil Türkçe olarak ayarlandı!</b>`,
    menuMsg:    `${$shine} <b>Ana Menü</b>\n<code>${LINE}</code>\n${$zap} Aşağıdaki butona basın:`,
    selectLang: `${$globe} <b>Dilinizi Seçin:</b>`,

    earnMsg: `${$money} <b>KAZANÇ MERKEZİ</b>
<code>${SEP}</code>
${$chart} <b>İlerleme:</b>  <code>{bar}</code>  <b>{watched} / {max}</b>
<code>${LINE}</code>
${$dollar} <i>Bugün Kazanılan:</i>  <b>$ {todayEarned}</b>
${$wallet} <i>Bakiyeniz:</i>        <b>$ {balance}</b>
${$zap} Reklam başına: <b>$0.01</b>  ·  <b>{remaining}</b> kaldı
<code>${LINE}</code>`,

    earnDone: `${$check} <b>Bugünkü Tüm Reklamlar İzlendi!</b>
<code>${SEP}</code>
${$party} Harika! Tüm <b>{max}</b> reklamı izlediniz.
${$wallet} <i>Bakiyeniz:</i> <b>$ {balance}</b>
<code>${LINE}</code>
${$moon} Daha fazlası için <b>yarın</b> gelin!`,

    watchAd: "📺 Reklam İzle  (+$0.01)",
    refresh:  "🔄 Bakiyeyi Yenile",

    adStarted: `${$tv} <b>Reklam Hazır — Şimdi İzleyin!</b>
<code>${SEP}</code>
${$clock} En az <b>10 saniye</b> izleyin
${$check} Ardından <b>İzledim</b> butonuna basın
<code>${LINE}</code>
<blockquote>${$warn} Erken basmak = <b>Uyarı verilir</b>
${$lock} Benzersiz token — <b>tek kullanımlık</b></blockquote>`,

    watchNow:   "▶️ Reklamı Aç",
    adVerify:   "✅ İzledim",
    adComplete: `${$check} <b>+$0.01 Başarıyla Yüklendi!</b>
<code>${SEP}</code>
${$wallet} Bakiye: <b>$ {balance}</b>
${$chart} Bugün: <b>{watched} / {max}</b> reklam
<code>${LINE}</code>
${$fire} <i>Devam edin — her reklam önemli!</i>`,

    adFailed: `${$warn} <b>Doğrulama Başarısız — Çok Hızlı!</b>
<code>${SEP}</code>
Doğrulamadan önce tam reklamı izlemelisiniz.
<code>${LINE}</code>
<blockquote>${$warn} Uyarı <b>{warnCount} / {warnLimit}</b> verildi.
${$ban} <b>{warnLimit}</b> uyarıda → <b>kalıcı ban</b></blockquote>`,

    adCheatBan: `${$ban} <b>Hesap Kalıcı Olarak Banlandı</b>
<code>${SEP}</code>
<blockquote>İzin verilen ihlal limitini aştınız.
Bu karar <b>kesindir</b>.</blockquote>
<code>${LINE}</code>
${$inbox} Hata olduğunu düşünüyorsanız destek ile iletişime geçin.`,

    adAlreadyPending: `${$hourglass} <b>Reklam devam ediyor</b> — yeni başlatmadan önce tamamlayın.`,
    adsLimit: `${$check} <b>Bugünkü {max} reklam izlendi!</b>
<code>${SEP}</code>
${$wallet} Bakiye: <b>$ {balance}</b>
${$moon} <b>Yarın</b> görüşürüz!`,

    channelRequired: `${$lock} <b>Önce Gerekli Kanallara Katılın</b>
<code>${SEP}</code>
Kazanmaya başlamak için <b>tüm</b> kanallara katılın:

{channels}
<code>${LINE}</code>
${$check} Katıldıktan sonra <b>Hepsine Katıldım</b> butonuna basın.`,

    joinedVerify:      "✅ Hepsine Katıldım",
    channelNotJoined:  "❌ Henüz katılmadınız — önce katılın.",
    channelJoinReward: `${$party} Kanala katıldınız! <b>+\${reward}</b> yüklendi.`,

    profileMsg: `${$user} <b>PROFİLİM</b>
<code>${SEP}</code>
${$idcard} <i>Kullanıcı ID:</i>   <code>{id}</code>
${$user} <i>İsim:</i>            <b>{name}</b>
${$globe} <i>Dil:</i>             {lang}
<code>${LINE}</code>
${$wallet} <i>Bakiye:</i>             <b>$ {balance}</b>
${$up} <i>Toplam Kazanılan:</i> <b>$ {totalEarned}</b>
<code>${LINE}</code>
${$chart} <i>Bugün Reklam:</i>  <b>{adsToday} / {maxAds}</b>
${$people} <i>Referanslar:</i>   <b>{referrals}</b>
${$warn} <i>Uyarılar:</i>       <b>{warnings} / {warnLimit}</b>
${$cal} <i>Katıldı:</i>        <b>{joined}</b>
<code>${LINE}</code>
<blockquote>📜 <b>KURALLAR</b>
▸ Günde maksimum <b>{maxAds}</b> reklam
▸ Bot veya hile yasaktır
▸ Minimum çekim: <b>$ {minWd}</b>
▸ <b>{warnLimit}</b> ihlal = kalıcı ban
▸ Kişi başına bir hesap</blockquote>`,

    referralMsg: `${$people} <b>REFERANS PROGRAMI</b>
<code>${SEP}</code>
${$shine} Arkadaş davet edin — kişi başı <b>$ {refReward}</b> kazanın!
<code>${LINE}</code>
${$people} <i>Toplam Referans:</i>  <b>{count}</b>
${$money} <i>Referans Kazancı:</i> <b>$ {earned}</b>
<code>${LINE}</code>
${$link} <b>Referans Linkiniz:</b>
<code>{link}</code>
<code>${LINE}</code>
${$share} <i>Linki paylaşın — arkadaş katılınca anında kazanın!</i>`,

    shareLink: "📨 Linki Paylaş",

    dailyTaskMsg: `${$clip} <b>GÜNLÜK GÖREVLER</b>
<code>${SEP}</code>
${$sparkle} Görevleri tamamlayın — bonusu açın!
${$refresh} Her gece yarısı sıfırlanır
<code>${LINE}</code>
{tasks}
<code>${LINE}</code>
${$check} İlerleme: <b>{done} / {total}</b>
${$gift} Günlük Bonus: <b>$ {bonus}</b>`,

    taskWatchAds:   `${$tv} Bugün <b>{threshold}</b> reklam izle  →  <b>+$ {reward}</b>`,
    taskShare:      `${$share} Botu 1 arkadaşla paylaş  →  <b>+$ {reward}</b>`,
    taskChannel:    `${$mega} Katıl: <b>{name}</b>  →  <b>+$ {reward}</b>`,
    taskReferral:   `${$people} 1 yeni kullanıcı getir  →  <b>+$ {reward}</b>`,
    taskDonePrefix:    "✅ ",
    taskPendingPrefix: "⬜ ",
    claimBonus:     "🎁 Günlük Bonusu Al",
    bonusClaimed: `${$gift} <b>Günlük Bonus Alındı!</b>
<code>${SEP}</code>
${$money} Bonus: <b>+$ {bonus}</b>
${$wallet} Yeni Bakiye: <b>$ {balance}</b>`,

    alreadyClaimed:   `${$check} Bugünkü bonus zaten alındı!`,
    tasksNotComplete: `${$warn} Önce tüm görevleri tamamlayın!`,
    taskShareBtn:     "📨 Botu Paylaş",
    taskVerifyBtn:    "✅ Doğrula",

    withdrawMsg: `${$cashfly} <b>ÇEKİM</b>
<code>${SEP}</code>
${$wallet} Bakiye:  <b>$ {balance}</b>
${$warn} Minimum: <b>$ {minWd}</b>
<code>${LINE}</code>
${$phone} <b>Ödeme yöntemini seçin:</b>`,

    withdrawLow: `${$cross} <b>Yetersiz Bakiye</b>
<code>${SEP}</code>
Çekim için en az <b>$ {minWd}</b> gerekli.
${$wallet} <i>Bakiyeniz:</i> <b>$ {balance}</b>`,

    withdrawAddress:  `${$note} <b>{method}</b> numaranızı veya cüzdan adresinizi girin:`,
    withdrawConfirm: `${$check} <b>Çekim Talebi Gönderildi!</b>
<code>${SEP}</code>
${$dollar} Miktar:  <b>$ {amount}</b>
${$bank} Yöntem:  <b>{method}</b>
${$mailbox} Adres:   <code>{address}</code>
<code>${LINE}</code>
${$clock} <b>24 saat</b> içinde ödeme yapılır.`,

    withdrawPending: `${$hourglass} <b>Bekleyen bir çekim talebi</b> var. İşlenmesini bekleyin.`,
    withdrawSelect:  "Yöntem seçin:",

    banned: `${$ban} <b>Hesap Banlandı</b>
<code>${SEP}</code>
<blockquote>Hesabınız kural ihlali nedeniyle banlandı.</blockquote>
<code>${LINE}</code>
${$inbox} Hata olduğunu düşünüyorsanız destek ile iletişime geçin.`,

    startFirst: `${$warn} Başlamak için /start gönderin.`,
    unknownCmd: `Gezinmek için menü butonlarını kullanın. 👇`,
    profileBtn: "👤 Kullanıcı Profili",
    earnBtn: "💰 Kazan",
    withdrawalBtn: "💸 Para Çek",
    referralBtn: "👥 Referans",
    adultBtn2: "🔞 Yetişkin",
    movieSeriesBtn: "🎬 Film-Dizi",
    setWalletBtn: "💳 Cüzdan Ayarla",
    changeLangBtn: "🌐 Dil Değiştir",
    watchAdsBtn: "📺 Reklam İzle",
    dailyTasksBtn: "📋 Günlük Görevler",
    confirmBtn: "✅ Onayla",
    changeMethodBtn: "🔄 Yöntem Değiştir",
    cancelBtn: "❌ İptal",
    mainMenuBtn: "🏠 Ana Menü",
    backBtn: "⬅️ Geri",
    confirmWalletMsg: `${$check} <b>Cüzdanı Kaydet</b>\n<code>${SEP}</code>\n💳 Yöntem: <b>{method}</b>\n${$mailbox} Adres: <code>{address}</code>`,
    confirmWdMsg: `${$check} <b>Çekimi Onayla</b>\n<code>${SEP}</code>\n💳 Yöntem: <b>{method}</b>\n${$mailbox} Adres: <code>{address}</code>\n${$dollar} Miktar: <b>$ {balance}</b>`,
    walletUpdated: `${$check} <b>Cüzdan Güncellendi!</b>\n<code>${SEP}</code>\n💳 Yöntem: <b>{method}</b>\n${$mailbox} Adres: <code>{address}</code>`,
    updateWalletMsg: `💳 <b>Cüzdan Güncelle</b>\n<code>${SEP}</code>\n${$phone} Ödeme yöntemini seçin:`,
    nameUpdated: `${$check} <b>İsim Güncellendi!</b>\n<code>${SEP}</code>\n${$user} Yeni isim: <b>{name}</b>`,
    earnCategoryMsg: `${$money} <b>KAZANÇ MERKEZİ</b>\n<code>${SEP}</code>\n${$rocket} Nasıl kazanmak istediğinizi seçin:\n<code>${LINE}</code>\n${$tv} <b>Reklam İzle</b>  —  reklam başına +$0.01\n${$clip} <b>Günlük Görevler</b>  —  tamamlamak için bonus\n${$people} <b>Referans</b>  —  her arkadaş için kazan\n<code>${LINE}</code>\n${$zap} <i>Tüm kazançlar anında eklenir</i>`,
  },

  // ─────────────────────────── URDU ───────────────────────────────
  ur: {
    earn:      "💰 کمائیں",
    profile:   "👤 پروفائل",
    dailyTask: "📋 روزانہ کام",
    referral:  "👥 ریفرل",
    withdraw:  "💸 نکاسی",
    language:  "🌐 زبان",
    adultBot:  "🔞 Adult",
    movieBot:  "🎬 Movies",
    rules:     "📜 اصول",

    welcome: `${$movie} <b>DesiXX Video Bot میں خوش آمدید!</b>
<code>${SEP}</code>
${$money} اشتہار دیکھیں — <b>حقیقی پیسے کمائیں</b>
${$people} دوست بلائیں — <b>فوری بونس</b> پائیں
${$clip} روزانہ کام — <b>اضافی انعام</b>
${$cashfly} <b>bKash · Nagad · USDT</b> میں نکاسی
<code>${LINE}</code>
${$globe} <b>شروع کرنے کے لیے زبان چنیں:</b>`,

    langSet:    `${$check} <b>زبان اردو میں سیٹ ہو گئی!</b>`,
    menuMsg:    `${$shine} <b>مین مینو</b>\n<code>${LINE}</code>\n${$zap} نیچے بٹن دبائیں:`,
    selectLang: `${$globe} <b>زبان چنیں:</b>`,

    earnMsg: `${$money} <b>کمائی مرکز</b>
<code>${SEP}</code>
${$chart} <b>پیشرفت:</b>  <code>{bar}</code>  <b>{watched} / {max}</b>
<code>${LINE}</code>
${$dollar} <i>آج کمایا:</i>    <b>$ {todayEarned}</b>
${$wallet} <i>آپ کا بیلنس:</i> <b>$ {balance}</b>
${$zap} فی اشتہار: <b>$0.01</b>  ·  <b>{remaining}</b> باقی
<code>${LINE}</code>`,

    earnDone: `${$check} <b>آج کے تمام اشتہار دیکھ لیے!</b>
<code>${SEP}</code>
${$party} شاندار! آپ نے تمام <b>{max}</b> اشتہار دیکھے۔
${$wallet} <i>بیلنس:</i> <b>$ {balance}</b>
<code>${LINE}</code>
${$moon} کل مزید کمائی کے لیے آئیں!`,

    watchAd: "📺 اشتہار دیکھیں  (+$0.01)",
    refresh:  "🔄 بیلنس تازہ کریں",

    adStarted: `${$tv} <b>اشتہار تیار ہے — ابھی دیکھیں!</b>
<code>${SEP}</code>
${$clock} کم از کم <b>10 سیکنڈ</b> دیکھیں
${$check} پھر نیچے <b>میں نے دیکھا</b> دبائیں
<code>${LINE}</code>
<blockquote>${$warn} جلدی دبانے پر = <b>انتباہ جاری</b>
${$lock} ہر اشتہار کا الگ ٹوکن — <b>صرف ایک بار</b></blockquote>`,

    watchNow:   "▶️ اشتہار کھولیں",
    adVerify:   "✅ میں نے دیکھا",
    adComplete: `${$check} <b>+$0.01 کامیابی سے کریڈٹ ہوا!</b>
<code>${SEP}</code>
${$wallet} بیلنس: <b>$ {balance}</b>
${$chart} آج: <b>{watched} / {max}</b> اشتہار دیکھے
<code>${LINE}</code>
${$fire} <i>جاری رکھیں — ہر اشتہار اہم ہے!</i>`,

    adFailed: `${$warn} <b>تصدیق ناکام — بہت جلدی!</b>
<code>${SEP}</code>
تصدیق سے پہلے پورا اشتہار دیکھنا ضروری ہے۔
<code>${LINE}</code>
<blockquote>${$warn} انتباہ <b>{warnCount} / {warnLimit}</b> جاری۔
${$ban} <b>{warnLimit}</b> انتباہ پر → <b>مستقل بین</b></blockquote>`,

    adCheatBan: `${$ban} <b>اکاؤنٹ مستقل بین</b>
<code>${SEP}</code>
<blockquote>آپ نے انتباہ کی حد پار کر لی۔
یہ فیصلہ <b>ناقابل واپسی</b> ہے۔</blockquote>
<code>${LINE}</code>
${$inbox} غلطی لگے تو سپورٹ سے رابطہ کریں۔`,

    adAlreadyPending: `${$hourglass} <b>اشتہار جاری ہے</b> — نیا شروع کرنے سے پہلے مکمل کریں۔`,
    adsLimit: `${$check} <b>آج کے تمام {max} اشتہار دیکھے!</b>
<code>${SEP}</code>
${$wallet} بیلنس: <b>$ {balance}</b>
${$moon} کل واپس آئیں!`,

    channelRequired: `${$lock} <b>پہلے ضروری چینلز جوائن کریں</b>
<code>${SEP}</code>
کمائی شروع کرنے کے لیے <b>تمام</b> چینل جوائن کریں:

{channels}
<code>${LINE}</code>
${$check} جوائن کرنے کے بعد <b>میں نے جوائن کیا</b> دبائیں۔`,

    joinedVerify:      "✅ میں نے سب جوائن کیا",
    channelNotJoined:  "❌ ابھی جوائن نہیں کیا — پہلے جوائن کریں۔",
    channelJoinReward: `${$party} چینل جوائن کیا! <b>+\${reward}</b> کریڈٹ۔`,

    profileMsg: `${$user} <b>میری پروفائل</b>
<code>${SEP}</code>
${$idcard} <i>یوزر ID:</i>     <code>{id}</code>
${$user} <i>نام:</i>          <b>{name}</b>
${$globe} <i>زبان:</i>         {lang}
<code>${LINE}</code>
${$wallet} <i>بیلنس:</i>         <b>$ {balance}</b>
${$up} <i>کل کمائی:</i>      <b>$ {totalEarned}</b>
<code>${LINE}</code>
${$chart} <i>آج کے اشتہار:</i> <b>{adsToday} / {maxAds}</b>
${$people} <i>ریفرل:</i>         <b>{referrals}</b>
${$warn} <i>انتباہ:</i>         <b>{warnings} / {warnLimit}</b>
${$cal} <i>شامل ہوئے:</i>     <b>{joined}</b>
<code>${LINE}</code>
<blockquote>📜 <b>اصول</b>
▸ روزانہ زیادہ سے زیادہ <b>{maxAds}</b> اشتہار
▸ بوٹ یا دھوکہ ممنوع
▸ نکاسی کے لیے کم از کم <b>$ {minWd}</b>
▸ <b>{warnLimit}</b> خلاف ورزی = مستقل بین
▸ ایک شخص — ایک اکاؤنٹ</blockquote>`,

    referralMsg: `${$people} <b>ریفرل پروگرام</b>
<code>${SEP}</code>
${$shine} دوست بلائیں — فی شخص <b>$ {refReward}</b> کمائیں!
<code>${LINE}</code>
${$people} <i>کل ریفرل:</i>    <b>{count}</b>
${$money} <i>ریفرل کمائی:</i> <b>$ {earned}</b>
<code>${LINE}</code>
${$link} <b>آپ کا ریفرل لنک:</b>
<code>{link}</code>
<code>${LINE}</code>
${$share} <i>لنک شیئر کریں — دوست جڑے تو فوری کمائی!</i>`,

    shareLink: "📨 لنک شیئر کریں",

    dailyTaskMsg: `${$clip} <b>روزانہ کام</b>
<code>${SEP}</code>
${$sparkle} تمام کام مکمل کریں — بونس انلاک کریں!
${$refresh} ہر رات 12 بجے ری سیٹ
<code>${LINE}</code>
{tasks}
<code>${LINE}</code>
${$check} پیشرفت: <b>{done} / {total}</b>
${$gift} روزانہ بونس: <b>$ {bonus}</b>`,

    taskWatchAds:   `${$tv} آج <b>{threshold}</b> اشتہار دیکھیں  →  <b>+$ {reward}</b>`,
    taskShare:      `${$share} بوٹ 1 دوست کو شیئر کریں  →  <b>+$ {reward}</b>`,
    taskChannel:    `${$mega} جوائن: <b>{name}</b>  →  <b>+$ {reward}</b>`,
    taskReferral:   `${$people} 1 نیا یوزر لائیں  →  <b>+$ {reward}</b>`,
    taskDonePrefix:    "✅ ",
    taskPendingPrefix: "⬜ ",
    claimBonus:     "🎁 روزانہ بونس لیں",
    bonusClaimed: `${$gift} <b>روزانہ بونس مل گیا!</b>
<code>${SEP}</code>
${$money} بونس: <b>+$ {bonus}</b>
${$wallet} نیا بیلنس: <b>$ {balance}</b>`,

    alreadyClaimed:   `${$check} آج کا بونس پہلے ہی لیا جا چکا!`,
    tasksNotComplete: `${$warn} پہلے تمام کام مکمل کریں!`,
    taskShareBtn:     "📨 بوٹ شیئر کریں",
    taskVerifyBtn:    "✅ تصدیق کریں",

    withdrawMsg: `${$cashfly} <b>نکاسی</b>
<code>${SEP}</code>
${$wallet} آپ کا بیلنس: <b>$ {balance}</b>
${$warn} کم از کم: <b>$ {minWd}</b>
<code>${LINE}</code>
${$phone} <b>ادائیگی کا طریقہ چنیں:</b>`,

    withdrawLow: `${$cross} <b>ناکافی بیلنس</b>
<code>${SEP}</code>
نکاسی کے لیے کم از کم <b>$ {minWd}</b> چاہیے۔
${$wallet} <i>آپ کا بیلنس:</i> <b>$ {balance}</b>`,

    withdrawAddress:  `${$note} اپنا <b>{method}</b> نمبر یا ولٹ پتہ درج کریں:`,
    withdrawConfirm: `${$check} <b>نکاسی کی درخواست جمع!</b>
<code>${SEP}</code>
${$dollar} رقم:    <b>$ {amount}</b>
${$bank} طریقہ:  <b>{method}</b>
${$mailbox} پتہ:    <code>{address}</code>
<code>${LINE}</code>
${$clock} <b>24 گھنٹے</b> میں ادائیگی ہوگی۔`,

    withdrawPending: `${$hourglass} پہلے سے ایک <b>زیر التواء نکاسی</b> ہے۔ انتظار کریں۔`,
    withdrawSelect:  "طریقہ چنیں:",

    banned: `${$ban} <b>اکاؤنٹ بین</b>
<code>${SEP}</code>
<blockquote>اصول کی خلاف ورزی کی وجہ سے اکاؤنٹ بین ہوا۔</blockquote>
<code>${LINE}</code>
${$inbox} غلطی لگے تو سپورٹ سے رابطہ کریں۔`,

    startFirst: `${$warn} شروع کرنے کے لیے /start بھیجیں۔`,
    unknownCmd: `نیویگیٹ کرنے کے لیے مینو بٹن استعمال کریں۔ 👇`,
    profileBtn: "👤 یوزر پروفائل",
    earnBtn: "💰 کمائیں",
    withdrawalBtn: "💸 نکاسی",
    referralBtn: "👥 ریفرل",
    adultBtn2: "🔞 بالغ",
    movieSeriesBtn: "🎬 فلمیں-ڈرامے",
    setWalletBtn: "💳 ولٹ سیٹ",
    changeLangBtn: "🌐 زبان تبدیل",
    watchAdsBtn: "📺 اشتہار دیکھیں",
    dailyTasksBtn: "📋 روزانہ کام",
    confirmBtn: "✅ تصدیق",
    changeMethodBtn: "🔄 طریقہ بدلیں",
    cancelBtn: "❌ منسوخ",
    mainMenuBtn: "🏠 مین مینو",
    backBtn: "⬅️ واپس",
    confirmWalletMsg: `${$check} <b>ولٹ محفوظ کریں</b>\n<code>${SEP}</code>\n💳 طریقہ: <b>{method}</b>\n${$mailbox} پتہ: <code>{address}</code>`,
    confirmWdMsg: `${$check} <b>نکاسی کی تصدیق</b>\n<code>${SEP}</code>\n💳 طریقہ: <b>{method}</b>\n${$mailbox} پتہ: <code>{address}</code>\n${$dollar} رقم: <b>$ {balance}</b>`,
    walletUpdated: `${$check} <b>ولٹ اپڈیٹ ہوا!</b>\n<code>${SEP}</code>\n💳 طریقہ: <b>{method}</b>\n${$mailbox} پتہ: <code>{address}</code>`,
    updateWalletMsg: `💳 <b>ولٹ اپڈیٹ کریں</b>\n<code>${SEP}</code>\n${$phone} ادائیگی کا طریقہ چنیں:`,
    nameUpdated: `${$check} <b>نام اپڈیٹ ہوا!</b>\n<code>${SEP}</code>\n${$user} نیا نام: <b>{name}</b>`,
    earnCategoryMsg: `${$money} <b>کمائی مرکز</b>\n<code>${SEP}</code>\n${$rocket} آج کیسے کمانا ہے چنیں:\n<code>${LINE}</code>\n${$tv} <b>اشتہار دیکھیں</b>  —  +$0.01 فی اشتہار\n${$clip} <b>روزانہ کام</b>  —  مکمل پر بونس\n${$people} <b>ریفرل</b>  —  ہر دوست پر کمائی\n<code>${LINE}</code>\n${$zap} <i>تمام کمائی فوری</i>`,
  },

  // ─────────────────────────── PUNJABI ────────────────────────────
  pa: {
    earn:      "💰 ਕਮਾਈ",
    profile:   "👤 ਪ੍ਰੋਫਾਈਲ",
    dailyTask: "📋 ਰੋਜ਼ਾਨਾ ਕੰਮ",
    referral:  "👥 ਰੈਫਰਲ",
    withdraw:  "💸 ਕਢਵਾਓ",
    language:  "🌐 ਭਾਸ਼ਾ",
    adultBot:  "🔞 Adult",
    movieBot:  "🎬 Movies",
    rules:     "📜 ਨਿਯਮ",

    welcome: `${$movie} <b>DesiXX Video Bot ਵਿੱਚ ਤੁਹਾਡਾ ਸੁਆਗਤ ਹੈ!</b>
<code>${SEP}</code>
${$money} ਇਸ਼ਤਿਹਾਰ ਦੇਖੋ — <b>ਅਸਲੀ ਪੈਸੇ</b> ਕਮਾਓ
${$people} ਦੋਸਤ ਲਿਆਓ — <b>ਤੁਰੰਤ ਬੋਨਸ</b> ਪਾਓ
${$clip} ਰੋਜ਼ਾਨਾ ਕੰਮ — <b>ਵਾਧੂ ਇਨਾਮ</b>
${$cashfly} <b>bKash · Nagad · USDT</b> ਵਿੱਚ ਕਢਵਾਓ
<code>${LINE}</code>
${$globe} <b>ਸ਼ੁਰੂ ਕਰਨ ਲਈ ਆਪਣੀ ਭਾਸ਼ਾ ਚੁਣੋ:</b>`,

    langSet:    `${$check} <b>ਭਾਸ਼ਾ ਪੰਜਾਬੀ ਵਿੱਚ ਸੈੱਟ ਹੋਈ!</b>`,
    menuMsg:    `${$shine} <b>ਮੁੱਖ ਮੀਨੂ</b>\n<code>${LINE}</code>\n${$zap} ਹੇਠਾਂ ਬਟਨ ਦਬਾਓ:`,
    selectLang: `${$globe} <b>ਆਪਣੀ ਭਾਸ਼ਾ ਚੁਣੋ:</b>`,

    earnMsg: `${$money} <b>ਕਮਾਈ ਕੇਂਦਰ</b>
<code>${SEP}</code>
${$chart} <b>ਪ੍ਰਗਤੀ:</b>  <code>{bar}</code>  <b>{watched} / {max}</b>
<code>${LINE}</code>
${$dollar} <i>ਅੱਜ ਕਮਾਈ:</i>    <b>$ {todayEarned}</b>
${$wallet} <i>ਤੁਹਾਡਾ ਬੈਲੇਂਸ:</i> <b>$ {balance}</b>
${$zap} ਪ੍ਰਤੀ ਇਸ਼ਤਿਹਾਰ: <b>$0.01</b>  ·  <b>{remaining}</b> ਬਾਕੀ
<code>${LINE}</code>`,

    earnDone: `${$check} <b>ਅੱਜ ਦੇ ਸਾਰੇ ਇਸ਼ਤਿਹਾਰ ਦੇਖੇ!</b>
<code>${SEP}</code>
${$party} ਸ਼ਾਬਾਸ਼! ਤੁਸੀਂ ਸਾਰੇ <b>{max}</b> ਦੇਖੇ।
${$wallet} <i>ਬੈਲੇਂਸ:</i> <b>$ {balance}</b>
<code>${LINE}</code>
${$moon} ਹੋਰ ਲਈ <b>ਕੱਲ੍ਹ</b> ਆਓ!`,

    watchAd: "📺 ਇਸ਼ਤਿਹਾਰ ਦੇਖੋ  (+$0.01)",
    refresh:  "🔄 ਬੈਲੇਂਸ ਰੀਫਰੈਸ਼",

    adStarted: `${$tv} <b>ਇਸ਼ਤਿਹਾਰ ਤਿਆਰ — ਹੁਣੇ ਦੇਖੋ!</b>
<code>${SEP}</code>
${$clock} ਘੱਟੋ ਘੱਟ <b>10 ਸਕਿੰਟ</b> ਦੇਖੋ
${$check} ਫਿਰ <b>ਮੈਂ ਦੇਖਿਆ</b> ਦਬਾਓ
<code>${LINE}</code>
<blockquote>${$warn} ਜਲਦੀ ਦਬਾਉਣ 'ਤੇ = <b>ਚੇਤਾਵਨੀ ਜਾਰੀ</b>
${$lock} ਹਰ ਇਸ਼ਤਿਹਾਰ ਲਈ ਵੱਖਰਾ ਟੋਕਨ — <b>ਇੱਕ ਵਾਰ</b></blockquote>`,

    watchNow:   "▶️ ਇਸ਼ਤਿਹਾਰ ਖੋਲ੍ਹੋ",
    adVerify:   "✅ ਮੈਂ ਦੇਖਿਆ",
    adComplete: `${$check} <b>+$0.01 ਸਫਲਤਾਪੂਰਵਕ ਕ੍ਰੈਡਿਟ!</b>
<code>${SEP}</code>
${$wallet} ਬੈਲੇਂਸ: <b>$ {balance}</b>
${$chart} ਅੱਜ: <b>{watched} / {max}</b>
<code>${LINE}</code>
${$fire} <i>ਜਾਰੀ ਰੱਖੋ!</i>`,

    adFailed: `${$warn} <b>ਤਸਦੀਕ ਅਸਫਲ — ਬਹੁਤ ਜਲਦੀ!</b>
<code>${SEP}</code>
ਪੂਰਾ ਇਸ਼ਤਿਹਾਰ ਦੇਖਣਾ ਜ਼ਰੂਰੀ ਹੈ।
<code>${LINE}</code>
<blockquote>${$warn} ਚੇਤਾਵਨੀ <b>{warnCount} / {warnLimit}</b> ਜਾਰੀ।
${$ban} <b>{warnLimit}</b> ਤੇ → <b>ਸਥਾਈ ਬੈਨ</b></blockquote>`,

    adCheatBan: `${$ban} <b>ਖਾਤਾ ਸਥਾਈ ਬੈਨ</b>
<code>${SEP}</code>
<blockquote>ਤੁਸੀਂ ਉਲੰਘਣਾ ਸੀਮਾ ਪਾਰ ਕਰ ਲਈ।</blockquote>
<code>${LINE}</code>
${$inbox} ਸਹਾਇਤਾ ਨਾਲ ਸੰਪਰਕ ਕਰੋ।`,

    adAlreadyPending: `${$hourglass} <b>ਇਸ਼ਤਿਹਾਰ ਚੱਲ ਰਿਹਾ ਹੈ</b> — ਪਹਿਲਾਂ ਪੂਰਾ ਕਰੋ।`,
    adsLimit: `${$check} <b>ਅੱਜ ਦੇ {max} ਸਾਰੇ ਇਸ਼ਤਿਹਾਰ!</b>
<code>${SEP}</code>
${$wallet} ਬੈਲੇਂਸ: <b>$ {balance}</b>
${$moon} ਕੱਲ੍ਹ ਆਓ!`,

    channelRequired: `${$lock} <b>ਪਹਿਲਾਂ ਚੈਨਲ ਜੋਇਨ ਕਰੋ</b>
<code>${SEP}</code>
ਕਮਾਈ ਲਈ <b>ਸਾਰੇ</b> ਚੈਨਲ ਜੋਇਨ ਕਰੋ:

{channels}
<code>${LINE}</code>
${$check} ਜੋਇਨ ਕਰਕੇ <b>ਮੈਂ ਜੋਇਨ ਕੀਤਾ</b> ਦਬਾਓ।`,

    joinedVerify:      "✅ ਮੈਂ ਸਭ ਜੋਇਨ ਕੀਤਾ",
    channelNotJoined:  "❌ ਅਜੇ ਜੋਇਨ ਨਹੀਂ — ਪਹਿਲਾਂ ਕਰੋ।",
    channelJoinReward: `${$party} ਚੈਨਲ ਜੋਇਨ! <b>+\${reward}</b> ਕ੍ਰੈਡਿਟ।`,

    profileMsg: `${$user} <b>ਮੇਰੀ ਪ੍ਰੋਫਾਈਲ</b>
<code>${SEP}</code>
${$idcard} <i>ਯੂਜ਼ਰ ID:</i>     <code>{id}</code>
${$user} <i>ਨਾਮ:</i>          <b>{name}</b>
${$globe} <i>ਭਾਸ਼ਾ:</i>         {lang}
<code>${LINE}</code>
${$wallet} <i>ਬੈਲੇਂਸ:</i>       <b>$ {balance}</b>
${$up} <i>ਕੁੱਲ ਕਮਾਈ:</i>   <b>$ {totalEarned}</b>
<code>${LINE}</code>
${$chart} <i>ਅੱਜ ਦੇ ਇਸ਼ਤਿਹਾਰ:</i> <b>{adsToday} / {maxAds}</b>
${$people} <i>ਰੈਫਰਲ:</i>          <b>{referrals}</b>
${$warn} <i>ਚੇਤਾਵਨੀਆਂ:</i>      <b>{warnings} / {warnLimit}</b>
${$cal} <i>ਸ਼ਾਮਲ ਹੋਏ:</i>     <b>{joined}</b>
<code>${LINE}</code>
<blockquote>📜 <b>ਨਿਯਮ</b>
▸ ਰੋਜ਼ਾਨਾ ਵੱਧ ਤੋਂ ਵੱਧ <b>{maxAds}</b> ਇਸ਼ਤਿਹਾਰ
▸ ਬੋਟ ਜਾਂ ਧੋਖਾ ਮਨਾਹੀ
▸ ਘੱਟੋ ਘੱਟ ਕਢਵਾਈ: <b>$ {minWd}</b>
▸ <b>{warnLimit}</b> ਉਲੰਘਣਾ = ਸਥਾਈ ਬੈਨ
▸ ਇੱਕ ਵਿਅਕਤੀ — ਇੱਕ ਖਾਤਾ</blockquote>`,

    referralMsg: `${$people} <b>ਰੈਫਰਲ ਪ੍ਰੋਗਰਾਮ</b>
<code>${SEP}</code>
${$shine} ਦੋਸਤ ਲਿਆਓ — ਪ੍ਰਤੀ ਵਿਅਕਤੀ <b>$ {refReward}</b> ਕਮਾਓ!
<code>${LINE}</code>
${$people} <i>ਕੁੱਲ ਰੈਫਰਲ:</i>   <b>{count}</b>
${$money} <i>ਰੈਫਰਲ ਕਮਾਈ:</i> <b>$ {earned}</b>
<code>${LINE}</code>
${$link} <b>ਤੁਹਾਡਾ ਰੈਫਰਲ ਲਿੰਕ:</b>
<code>{link}</code>
<code>${LINE}</code>
${$share} <i>ਲਿੰਕ ਸ਼ੇਅਰ ਕਰੋ — ਤੁਰੰਤ ਕਮਾਈ!</i>`,

    shareLink: "📨 ਲਿੰਕ ਸ਼ੇਅਰ ਕਰੋ",

    dailyTaskMsg: `${$clip} <b>ਰੋਜ਼ਾਨਾ ਕੰਮ</b>
<code>${SEP}</code>
${$sparkle} ਸਾਰੇ ਕੰਮ ਕਰੋ — ਬੋਨਸ ਪਾਓ!
${$refresh} ਹਰ ਰਾਤ ਰੀਸੈੱਟ
<code>${LINE}</code>
{tasks}
<code>${LINE}</code>
${$check} ਪ੍ਰਗਤੀ: <b>{done} / {total}</b>
${$gift} ਰੋਜ਼ਾਨਾ ਬੋਨਸ: <b>$ {bonus}</b>`,

    taskWatchAds:   `${$tv} ਅੱਜ <b>{threshold}</b> ਇਸ਼ਤਿਹਾਰ ਦੇਖੋ  →  <b>+$ {reward}</b>`,
    taskShare:      `${$share} ਬੋਟ 1 ਦੋਸਤ ਨਾਲ ਸ਼ੇਅਰ ਕਰੋ  →  <b>+$ {reward}</b>`,
    taskChannel:    `${$mega} ਜੋਇਨ: <b>{name}</b>  →  <b>+$ {reward}</b>`,
    taskReferral:   `${$people} 1 ਨਵਾਂ ਯੂਜ਼ਰ ਲਿਆਓ  →  <b>+$ {reward}</b>`,
    taskDonePrefix:    "✅ ",
    taskPendingPrefix: "⬜ ",
    claimBonus:     "🎁 ਰੋਜ਼ਾਨਾ ਬੋਨਸ ਲਓ",
    bonusClaimed: `${$gift} <b>ਰੋਜ਼ਾਨਾ ਬੋਨਸ ਮਿਲਿਆ!</b>
<code>${SEP}</code>
${$money} ਬੋਨਸ: <b>+$ {bonus}</b>
${$wallet} ਨਵਾਂ ਬੈਲੇਂਸ: <b>$ {balance}</b>`,

    alreadyClaimed:   `${$check} ਅੱਜ ਦਾ ਬੋਨਸ ਪਹਿਲਾਂ ਲਿਆ!`,
    tasksNotComplete: `${$warn} ਪਹਿਲਾਂ ਸਾਰੇ ਕੰਮ ਕਰੋ!`,
    taskShareBtn:     "📨 ਬੋਟ ਸ਼ੇਅਰ ਕਰੋ",
    taskVerifyBtn:    "✅ ਤਸਦੀਕ ਕਰੋ",

    withdrawMsg: `${$cashfly} <b>ਕਢਵਾਈ</b>
<code>${SEP}</code>
${$wallet} ਬੈਲੇਂਸ: <b>$ {balance}</b>
${$warn} ਘੱਟੋ ਘੱਟ: <b>$ {minWd}</b>
<code>${LINE}</code>
${$phone} <b>ਭੁਗਤਾਨ ਵਿਧੀ ਚੁਣੋ:</b>`,

    withdrawLow: `${$cross} <b>ਨਾਕਾਫ਼ੀ ਬੈਲੇਂਸ</b>
<code>${SEP}</code>
ਕਢਵਾਈ ਲਈ ਘੱਟੋ ਘੱਟ <b>$ {minWd}</b> ਚਾਹੀਦਾ।
${$wallet} <i>ਬੈਲੇਂਸ:</i> <b>$ {balance}</b>`,

    withdrawAddress:  `${$note} ਆਪਣਾ <b>{method}</b> ਨੰਬਰ ਜਾਂ ਵੈਲੇਟ ਪਤਾ ਦਿਓ:`,
    withdrawConfirm: `${$check} <b>ਕਢਵਾਈ ਬੇਨਤੀ ਜਮ੍ਹਾਂ!</b>
<code>${SEP}</code>
${$dollar} ਰਕਮ:    <b>$ {amount}</b>
${$bank} ਵਿਧੀ:   <b>{method}</b>
${$mailbox} ਪਤਾ:    <code>{address}</code>
<code>${LINE}</code>
${$clock} <b>24 ਘੰਟਿਆਂ</b> ਵਿੱਚ ਭੁਗਤਾਨ।`,

    withdrawPending: `${$hourglass} ਪਹਿਲਾਂ ਹੀ <b>ਲੰਬਿਤ ਕਢਵਾਈ</b> ਹੈ। ਉਡੀਕ ਕਰੋ।`,
    withdrawSelect:  "ਵਿਧੀ ਚੁਣੋ:",

    banned: `${$ban} <b>ਖਾਤਾ ਬੈਨ</b>
<code>${SEP}</code>
<blockquote>ਨਿਯਮਾਂ ਦੀ ਉਲੰਘਣਾ ਕਾਰਨ ਬੈਨ ਹੋਇਆ।</blockquote>
<code>${LINE}</code>
${$inbox} ਸਹਾਇਤਾ ਨਾਲ ਸੰਪਰਕ ਕਰੋ।`,

    startFirst: `${$warn} ਸ਼ੁਰੂ ਕਰਨ ਲਈ /start ਭੇਜੋ।`,
    unknownCmd: `ਮੀਨੂ ਬਟਨ ਵਰਤੋ। 👇`,
    profileBtn: "👤 ਯੂਜ਼ਰ ਪ੍ਰੋਫਾਈਲ",
    earnBtn: "💰 ਕਮਾਓ",
    withdrawalBtn: "💸 ਕਢਵਾਓ",
    referralBtn: "👥 ਰੈਫਰਲ",
    adultBtn2: "🔞 ਬਾਲਗ",
    movieSeriesBtn: "🎬 ਫਿਲਮਾਂ-ਸੀਰੀਜ਼",
    setWalletBtn: "💳 ਵੈਲੇਟ ਸੈੱਟ",
    changeLangBtn: "🌐 ਭਾਸ਼ਾ ਬਦਲੋ",
    watchAdsBtn: "📺 ਇਸ਼ਤਿਹਾਰ ਦੇਖੋ",
    dailyTasksBtn: "📋 ਰੋਜ਼ਾਨਾ ਕੰਮ",
    confirmBtn: "✅ ਪੱਕਾ ਕਰੋ",
    changeMethodBtn: "🔄 ਵਿਧੀ ਬਦਲੋ",
    cancelBtn: "❌ ਰੱਦ ਕਰੋ",
    mainMenuBtn: "🏠 ਮੁੱਖ ਮੀਨੂ",
    backBtn: "⬅️ ਵਾਪਸ",
    confirmWalletMsg: `${$check} <b>ਵੈਲੇਟ ਸੇਵ ਕਰੋ</b>\n<code>${SEP}</code>\n💳 ਵਿਧੀ: <b>{method}</b>\n${$mailbox} ਪਤਾ: <code>{address}</code>`,
    confirmWdMsg: `${$check} <b>ਕਢਵਾਈ ਪੱਕੀ ਕਰੋ</b>\n<code>${SEP}</code>\n💳 ਵਿਧੀ: <b>{method}</b>\n${$mailbox} ਪਤਾ: <code>{address}</code>\n${$dollar} ਰਕਮ: <b>$ {balance}</b>`,
    walletUpdated: `${$check} <b>ਵੈਲੇਟ ਅੱਪਡੇਟ!</b>\n<code>${SEP}</code>\n💳 ਵਿਧੀ: <b>{method}</b>\n${$mailbox} ਪਤਾ: <code>{address}</code>`,
    updateWalletMsg: `💳 <b>ਵੈਲੇਟ ਅੱਪਡੇਟ ਕਰੋ</b>\n<code>${SEP}</code>\n${$phone} ਭੁਗਤਾਨ ਵਿਧੀ ਚੁਣੋ:`,
    nameUpdated: `${$check} <b>ਨਾਮ ਅੱਪਡੇਟ!</b>\n<code>${SEP}</code>\n${$user} ਨਵਾਂ ਨਾਮ: <b>{name}</b>`,
    earnCategoryMsg: `${$money} <b>ਕਮਾਈ ਕੇਂਦਰ</b>\n<code>${SEP}</code>\n${$rocket} ਕਿਵੇਂ ਕਮਾਉਣਾ ਹੈ ਚੁਣੋ:\n<code>${LINE}</code>\n${$tv} <b>ਇਸ਼ਤਿਹਾਰ ਦੇਖੋ</b>  —  +$0.01 ਪ੍ਰਤੀ\n${$clip} <b>ਰੋਜ਼ਾਨਾ ਕੰਮ</b>  —  ਬੋਨਸ\n${$people} <b>ਰੈਫਰਲ</b>  —  ਦੋਸਤ ਪ੍ਰਤੀ ਕਮਾਈ\n<code>${LINE}</code>\n${$zap} <i>ਸਾਰੀ ਕਮਾਈ ਤੁਰੰਤ</i>`,
  },

  // ─────────────────────────── INDONESIAN ─────────────────────────
  id: {
    earn:      "💰 Hasilkan",
    profile:   "👤 Profil",
    dailyTask: "📋 Tugas Harian",
    referral:  "👥 Referral",
    withdraw:  "💸 Tarik Dana",
    language:  "🌐 Bahasa",
    adultBot:  "🔞 Adult",
    movieBot:  "🎬 Film",
    rules:     "📜 Aturan",

    welcome: `${$movie} <b>Selamat Datang di DesiXX Video Bot!</b>
<code>${SEP}</code>
${$money} Tonton iklan — hasilkan <b>uang nyata</b>
${$people} Ajak teman — <b>bonus instan</b>
${$clip} Tugas harian — <b>hadiah ekstra</b>
${$cashfly} Tarik via <b>bKash · Nagad · USDT</b>
<code>${LINE}</code>
${$globe} <b>Pilih bahasa Anda untuk memulai:</b>`,

    langSet:    `${$check} <b>Bahasa diatur ke Indonesia!</b>`,
    menuMsg:    `${$shine} <b>Menu Utama</b>\n<code>${LINE}</code>\n${$zap} Tekan tombol di bawah:`,
    selectLang: `${$globe} <b>Pilih Bahasa Anda:</b>`,

    earnMsg: `${$money} <b>PUSAT PENGHASILAN</b>
<code>${SEP}</code>
${$chart} <b>Progress:</b>  <code>{bar}</code>  <b>{watched} / {max}</b>
<code>${LINE}</code>
${$dollar} <i>Diperoleh Hari Ini:</i>  <b>$ {todayEarned}</b>
${$wallet} <i>Saldo Anda:</i>          <b>$ {balance}</b>
${$zap} Per Iklan: <b>$0.01</b>  ·  <b>{remaining}</b> tersisa
<code>${LINE}</code>`,

    earnDone: `${$check} <b>Semua Iklan Hari Ini Selesai!</b>
<code>${SEP}</code>
${$party} Luar biasa! Sudah menonton semua <b>{max}</b> iklan.
${$wallet} <i>Saldo:</i> <b>$ {balance}</b>
<code>${LINE}</code>
${$moon} Kembali <b>besok</b> untuk lebih banyak!`,

    watchAd: "📺 Tonton Iklan  (+$0.01)",
    refresh:  "🔄 Perbarui Saldo",

    adStarted: `${$tv} <b>Iklan Siap — Tonton Sekarang!</b>
<code>${SEP}</code>
${$clock} Tonton selama minimal <b>10 detik</b>
${$check} Lalu tekan <b>Sudah Ditonton</b>
<code>${LINE}</code>
<blockquote>${$warn} Tekan cepat = <b>Peringatan diberikan</b>
${$lock} Token unik — <b>sekali pakai</b></blockquote>`,

    watchNow:   "▶️ Buka Iklan",
    adVerify:   "✅ Sudah Ditonton",
    adComplete: `${$check} <b>+$0.01 Berhasil Dikreditkan!</b>
<code>${SEP}</code>
${$wallet} Saldo: <b>$ {balance}</b>
${$chart} Hari ini: <b>{watched} / {max}</b> iklan
<code>${LINE}</code>
${$fire} <i>Terus lanjut — setiap iklan berarti!</i>`,

    adFailed: `${$warn} <b>Verifikasi Gagal — Terlalu Cepat!</b>
<code>${SEP}</code>
Anda harus menonton iklan <b>penuh</b> sebelum verifikasi.
<code>${LINE}</code>
<blockquote>${$warn} Peringatan <b>{warnCount} / {warnLimit}</b> diberikan.
${$ban} Pada <b>{warnLimit}</b> peringatan → <b>blokir permanen</b></blockquote>`,

    adCheatBan: `${$ban} <b>Akun Diblokir Permanen</b>
<code>${SEP}</code>
<blockquote>Batas pelanggaran yang diizinkan telah terlampaui.
Keputusan ini <b>tidak dapat diubah</b>.</blockquote>
<code>${LINE}</code>
${$inbox} Hubungi dukungan jika Anda yakin ini kesalahan.`,

    adAlreadyPending: `${$hourglass} <b>Iklan sedang berjalan</b> — selesaikan sebelum memulai yang baru.`,
    adsLimit: `${$check} <b>Semua {max} iklan hari ini sudah ditonton!</b>
<code>${SEP}</code>
${$wallet} Saldo: <b>$ {balance}</b>
${$moon} Sampai <b>besok</b>!`,

    channelRequired: `${$lock} <b>Bergabung ke Channel Wajib Dulu</b>
<code>${SEP}</code>
Anda harus bergabung ke <b>semua</b> channel untuk mulai:

{channels}
<code>${LINE}</code>
${$check} Setelah bergabung, tekan <b>Sudah Bergabung Semua</b>.`,

    joinedVerify:      "✅ Sudah Bergabung Semua",
    channelNotJoined:  "❌ Belum bergabung — silakan bergabung dulu.",
    channelJoinReward: `${$party} Berhasil bergabung! <b>+\${reward}</b> dikreditkan.`,

    profileMsg: `${$user} <b>PROFIL SAYA</b>
<code>${SEP}</code>
${$idcard} <i>ID Pengguna:</i>   <code>{id}</code>
${$user} <i>Nama:</i>          <b>{name}</b>
${$globe} <i>Bahasa:</i>        {lang}
<code>${LINE}</code>
${$wallet} <i>Saldo:</i>           <b>$ {balance}</b>
${$up} <i>Total Diperoleh:</i> <b>$ {totalEarned}</b>
<code>${LINE}</code>
${$chart} <i>Iklan Hari Ini:</i> <b>{adsToday} / {maxAds}</b>
${$people} <i>Referral:</i>       <b>{referrals}</b>
${$warn} <i>Peringatan:</i>     <b>{warnings} / {warnLimit}</b>
${$cal} <i>Bergabung:</i>      <b>{joined}</b>
<code>${LINE}</code>
<blockquote>📜 <b>ATURAN</b>
▸ Maks <b>{maxAds}</b> iklan per hari
▸ Dilarang menggunakan bot atau kecurangan
▸ Minimum penarikan <b>$ {minWd}</b>
▸ <b>{warnLimit}</b> pelanggaran = blokir permanen
▸ Satu akun per orang</blockquote>`,

    referralMsg: `${$people} <b>PROGRAM REFERRAL</b>
<code>${SEP}</code>
${$shine} Ajak teman — dapatkan <b>$ {refReward}</b> per orang!
<code>${LINE}</code>
${$people} <i>Total Referral:</i>   <b>{count}</b>
${$money} <i>Penghasilan Ref:</i>  <b>$ {earned}</b>
<code>${LINE}</code>
${$link} <b>Link Referral Anda:</b>
<code>{link}</code>
<code>${LINE}</code>
${$share} <i>Bagikan link — dapatkan penghasilan instan!</i>`,

    shareLink: "📨 Bagikan Link",

    dailyTaskMsg: `${$clip} <b>TUGAS HARIAN</b>
<code>${SEP}</code>
${$sparkle} Selesaikan semua tugas — buka bonus Anda!
${$refresh} Direset setiap tengah malam
<code>${LINE}</code>
{tasks}
<code>${LINE}</code>
${$check} Progress: <b>{done} / {total}</b>
${$gift} Bonus Harian: <b>$ {bonus}</b>`,

    taskWatchAds:   `${$tv} Tonton <b>{threshold}</b> iklan hari ini  →  <b>+$ {reward}</b>`,
    taskShare:      `${$share} Bagikan bot ke 1 teman  →  <b>+$ {reward}</b>`,
    taskChannel:    `${$mega} Bergabung: <b>{name}</b>  →  <b>+$ {reward}</b>`,
    taskReferral:   `${$people} Ajak 1 pengguna baru  →  <b>+$ {reward}</b>`,
    taskDonePrefix:    "✅ ",
    taskPendingPrefix: "⬜ ",
    claimBonus:     "🎁 Klaim Bonus Harian",
    bonusClaimed: `${$gift} <b>Bonus Harian Diklaim!</b>
<code>${SEP}</code>
${$money} Bonus: <b>+$ {bonus}</b>
${$wallet} Saldo Baru: <b>$ {balance}</b>`,

    alreadyClaimed:   `${$check} Bonus hari ini sudah diklaim!`,
    tasksNotComplete: `${$warn} Selesaikan semua tugas dulu!`,
    taskShareBtn:     "📨 Bagikan Bot",
    taskVerifyBtn:    "✅ Verifikasi",

    withdrawMsg: `${$cashfly} <b>PENARIKAN</b>
<code>${SEP}</code>
${$wallet} Saldo:   <b>$ {balance}</b>
${$warn} Minimum: <b>$ {minWd}</b>
<code>${LINE}</code>
${$phone} <b>Pilih metode pembayaran:</b>`,

    withdrawLow: `${$cross} <b>Saldo Tidak Cukup</b>
<code>${SEP}</code>
Butuh minimal <b>$ {minWd}</b> untuk menarik.
${$wallet} <i>Saldo Anda:</i> <b>$ {balance}</b>`,

    withdrawAddress:  `${$note} Masukkan nomor <b>{method}</b> atau alamat dompet Anda:`,
    withdrawConfirm: `${$check} <b>Permintaan Penarikan Diajukan!</b>
<code>${SEP}</code>
${$dollar} Jumlah:  <b>$ {amount}</b>
${$bank} Metode:  <b>{method}</b>
${$mailbox} Alamat:  <code>{address}</code>
<code>${LINE}</code>
${$clock} Pembayaran dalam <b>24 jam</b>.`,

    withdrawPending: `${$hourglass} Sudah ada <b>permintaan penarikan tertunda</b>.`,
    withdrawSelect:  "Pilih metode:",

    banned: `${$ban} <b>Akun Diblokir</b>
<code>${SEP}</code>
<blockquote>Akun Anda diblokir karena melanggar ketentuan.</blockquote>
<code>${LINE}</code>
${$inbox} Hubungi dukungan jika Anda yakin ini kesalahan.`,

    startFirst: `${$warn} Kirim /start untuk memulai.`,
    unknownCmd: `Gunakan tombol menu di bawah untuk navigasi. 👇`,
    profileBtn: "👤 Profil Pengguna",
    earnBtn: "💰 Hasilkan",
    withdrawalBtn: "💸 Tarik Dana",
    referralBtn: "👥 Referral",
    adultBtn2: "🔞 Dewasa",
    movieSeriesBtn: "🎬 Film-Series",
    setWalletBtn: "💳 Atur Dompet",
    changeLangBtn: "🌐 Ganti Bahasa",
    watchAdsBtn: "📺 Tonton Iklan",
    dailyTasksBtn: "📋 Tugas Harian",
    confirmBtn: "✅ Konfirmasi",
    changeMethodBtn: "🔄 Ganti Metode",
    cancelBtn: "❌ Batal",
    mainMenuBtn: "🏠 Menu Utama",
    backBtn: "⬅️ Kembali",
    confirmWalletMsg: `${$check} <b>Konfirmasi Simpan Dompet</b>\n<code>${SEP}</code>\n💳 Metode: <b>{method}</b>\n${$mailbox} Alamat: <code>{address}</code>`,
    confirmWdMsg: `${$check} <b>Konfirmasi Penarikan</b>\n<code>${SEP}</code>\n💳 Metode: <b>{method}</b>\n${$mailbox} Alamat: <code>{address}</code>\n${$dollar} Jumlah: <b>$ {balance}</b>`,
    walletUpdated: `${$check} <b>Dompet Diperbarui!</b>\n<code>${SEP}</code>\n💳 Metode: <b>{method}</b>\n${$mailbox} Alamat: <code>{address}</code>`,
    updateWalletMsg: `💳 <b>Perbarui Dompet</b>\n<code>${SEP}</code>\n${$phone} Pilih metode pembayaran:`,
    nameUpdated: `${$check} <b>Nama Diperbarui!</b>\n<code>${SEP}</code>\n${$user} Nama baru: <b>{name}</b>`,
    earnCategoryMsg: `${$money} <b>Pusat Penghasilan</b>\n<code>${SEP}</code>\n${$rocket} Pilih cara menghasilkan:\n<code>${LINE}</code>\n${$tv} <b>Tonton Iklan</b>  —  +$0.01 per iklan\n${$clip} <b>Tugas Harian</b>  —  bonus saat selesai\n${$people} <b>Referral</b>  —  hasilkan per teman\n<code>${LINE}</code>\n${$zap} <i>Semua penghasilan instan</i>`,
  },

  // ─────────────────────────── FRENCH ─────────────────────────────
  fr: {
    earn:      "💰 Gagner",
    profile:   "👤 Profil",
    dailyTask: "📋 Tâches",
    referral:  "👥 Parrainage",
    withdraw:  "💸 Retrait",
    language:  "🌐 Langue",
    adultBot:  "🔞 Adult",
    movieBot:  "🎬 Films",
    rules:     "📜 Règles",

    welcome: `${$movie} <b>Bienvenue sur DesiXX Video Bot!</b>
<code>${SEP}</code>
${$money} Regardez des pubs — gagnez de <b>l'argent réel</b>
${$people} Invitez des amis — <b>bonus instantané</b>
${$clip} Tâches quotidiennes — <b>récompenses supplémentaires</b>
${$cashfly} Retirez via <b>bKash · Nagad · USDT</b>
<code>${LINE}</code>
${$globe} <b>Choisissez votre langue pour commencer:</b>`,

    langSet:    `${$check} <b>Langue définie sur Français!</b>`,
    menuMsg:    `${$shine} <b>Menu Principal</b>\n<code>${LINE}</code>\n${$zap} Appuyez sur un bouton:`,
    selectLang: `${$globe} <b>Choisissez votre langue:</b>`,

    earnMsg: `${$money} <b>CENTRE DE GAINS</b>
<code>${SEP}</code>
${$chart} <b>Progression:</b>  <code>{bar}</code>  <b>{watched} / {max}</b>
<code>${LINE}</code>
${$dollar} <i>Gagné aujourd'hui:</i>  <b>$ {todayEarned}</b>
${$wallet} <i>Votre solde:</i>        <b>$ {balance}</b>
${$zap} Par pub: <b>$0.01</b>  ·  <b>{remaining}</b> restantes
<code>${LINE}</code>`,

    earnDone: `${$check} <b>Toutes les pubs du jour regardées!</b>
<code>${SEP}</code>
${$party} Bravo! Vous avez regardé les <b>{max}</b> pubs.
${$wallet} <i>Solde actuel:</i> <b>$ {balance}</b>
<code>${LINE}</code>
${$moon} Revenez <b>demain</b> pour plus!`,

    watchAd: "📺 Regarder la pub  (+$0.01)",
    refresh:  "🔄 Actualiser le solde",

    adStarted: `${$tv} <b>Pub prête — Regardez maintenant!</b>
<code>${SEP}</code>
${$clock} Regardez au moins <b>10 secondes</b>
${$check} Puis appuyez sur <b>J'ai regardé</b>
<code>${LINE}</code>
<blockquote>${$warn} Trop rapide = <b>Avertissement émis</b>
${$lock} Token unique — <b>utilisation unique</b></blockquote>`,

    watchNow:   "▶️ Ouvrir la pub",
    adVerify:   "✅ J'ai regardé",
    adComplete: `${$check} <b>+$0.01 crédité avec succès!</b>
<code>${SEP}</code>
${$wallet} Solde: <b>$ {balance}</b>
${$chart} Aujourd'hui: <b>{watched} / {max}</b> pubs
<code>${LINE}</code>
${$fire} <i>Continuez — chaque pub compte!</i>`,

    adFailed: `${$warn} <b>Trop rapide — Vérification échouée!</b>
<code>${SEP}</code>
Vous devez regarder la pub <b>entière</b> avant de vérifier.
<code>${LINE}</code>
<blockquote>${$warn} Avertissement <b>{warnCount} / {warnLimit}</b> émis.
${$ban} À <b>{warnLimit}</b> avertissements → <b>bannissement permanent</b></blockquote>`,

    adCheatBan: `${$ban} <b>Compte Banni Définitivement</b>
<code>${SEP}</code>
<blockquote>Vous avez dépassé la limite de violations autorisée.
Cette décision est <b>irrévocable</b>.</blockquote>
<code>${LINE}</code>
${$inbox} Contactez le support si vous pensez que c'est une erreur.`,

    adAlreadyPending: `${$hourglass} <b>Pub en cours</b> — terminez-la avant d'en démarrer une nouvelle.`,
    adsLimit: `${$check} <b>Toutes les {max} pubs regardées!</b>
<code>${SEP}</code>
${$wallet} Solde: <b>$ {balance}</b>
${$moon} À <b>demain</b>!`,

    channelRequired: `${$lock} <b>Rejoignez d'abord les chaînes requises</b>
<code>${SEP}</code>
Vous devez rejoindre <b>toutes</b> les chaînes pour commencer:

{channels}
<code>${LINE}</code>
${$check} Après avoir rejoint, appuyez sur <b>J'ai tout rejoint</b>.`,

    joinedVerify:      "✅ J'ai tout rejoint",
    channelNotJoined:  "❌ Pas encore rejoint — rejoignez d'abord.",
    channelJoinReward: `${$party} Chaîne rejointe! <b>+\${reward}</b> crédité.`,

    profileMsg: `${$user} <b>MON PROFIL</b>
<code>${SEP}</code>
${$idcard} <i>ID utilisateur:</i>  <code>{id}</code>
${$user} <i>Nom:</i>             <b>{name}</b>
${$globe} <i>Langue:</i>          {lang}
<code>${LINE}</code>
${$wallet} <i>Solde:</i>              <b>$ {balance}</b>
${$up} <i>Total gagné:</i>       <b>$ {totalEarned}</b>
<code>${LINE}</code>
${$chart} <i>Pubs aujourd'hui:</i> <b>{adsToday} / {maxAds}</b>
${$people} <i>Parrainages:</i>      <b>{referrals}</b>
${$warn} <i>Avertissements:</i>   <b>{warnings} / {warnLimit}</b>
${$cal} <i>Inscrit le:</i>       <b>{joined}</b>
<code>${LINE}</code>
<blockquote>📜 <b>RÈGLES</b>
▸ Max <b>{maxAds}</b> pubs par jour
▸ Bots et triche interdits
▸ Retrait minimum: <b>$ {minWd}</b>
▸ <b>{warnLimit}</b> violations = bannissement permanent
▸ Un compte par personne</blockquote>`,

    referralMsg: `${$people} <b>PROGRAMME DE PARRAINAGE</b>
<code>${SEP}</code>
${$shine} Invitez des amis — gagnez <b>$ {refReward}</b> par personne!
<code>${LINE}</code>
${$people} <i>Total parrainages:</i>  <b>{count}</b>
${$money} <i>Gains parrainage:</i>   <b>$ {earned}</b>
<code>${LINE}</code>
${$link} <b>Votre lien de parrainage:</b>
<code>{link}</code>
<code>${LINE}</code>
${$share} <i>Partagez le lien — gagnez instantanément!</i>`,

    shareLink: "📨 Partager le lien",

    dailyTaskMsg: `${$clip} <b>TÂCHES QUOTIDIENNES</b>
<code>${SEP}</code>
${$sparkle} Complétez toutes les tâches — débloquez votre bonus!
${$refresh} Réinitialisé chaque minuit
<code>${LINE}</code>
{tasks}
<code>${LINE}</code>
${$check} Progression: <b>{done} / {total}</b>
${$gift} Bonus quotidien: <b>$ {bonus}</b>`,

    taskWatchAds:   `${$tv} Regardez <b>{threshold}</b> pubs aujourd'hui  →  <b>+$ {reward}</b>`,
    taskShare:      `${$share} Partagez le bot avec 1 ami  →  <b>+$ {reward}</b>`,
    taskChannel:    `${$mega} Rejoignez: <b>{name}</b>  →  <b>+$ {reward}</b>`,
    taskReferral:   `${$people} Amenez 1 nouvel utilisateur  →  <b>+$ {reward}</b>`,
    taskDonePrefix:    "✅ ",
    taskPendingPrefix: "⬜ ",
    claimBonus:     "🎁 Récupérer le bonus quotidien",
    bonusClaimed: `${$gift} <b>Bonus quotidien récupéré!</b>
<code>${SEP}</code>
${$money} Bonus: <b>+$ {bonus}</b>
${$wallet} Nouveau solde: <b>$ {balance}</b>`,

    alreadyClaimed:   `${$check} Le bonus du jour a déjà été récupéré!`,
    tasksNotComplete: `${$warn} Complétez d'abord toutes les tâches!`,
    taskShareBtn:     "📨 Partager le bot",
    taskVerifyBtn:    "✅ Vérifier",

    withdrawMsg: `${$cashfly} <b>RETRAIT</b>
<code>${SEP}</code>
${$wallet} Solde:   <b>$ {balance}</b>
${$warn} Minimum: <b>$ {minWd}</b>
<code>${LINE}</code>
${$phone} <b>Choisissez votre mode de paiement:</b>`,

    withdrawLow: `${$cross} <b>Solde Insuffisant</b>
<code>${SEP}</code>
Il faut au moins <b>$ {minWd}</b> pour retirer.
${$wallet} <i>Votre solde:</i> <b>$ {balance}</b>`,

    withdrawAddress:  `${$note} Entrez votre numéro <b>{method}</b> ou adresse de portefeuille:`,
    withdrawConfirm: `${$check} <b>Demande de retrait soumise!</b>
<code>${SEP}</code>
${$dollar} Montant:  <b>$ {amount}</b>
${$bank} Méthode:  <b>{method}</b>
${$mailbox} Adresse:  <code>{address}</code>
<code>${LINE}</code>
${$clock} Paiement traité dans <b>24 heures</b>.`,

    withdrawPending: `${$hourglass} Vous avez déjà un <b>retrait en attente</b>. Patientez.`,
    withdrawSelect:  "Choisissez la méthode:",

    banned: `${$ban} <b>Compte Banni</b>
<code>${SEP}</code>
<blockquote>Votre compte a été banni pour violation des règles.</blockquote>
<code>${LINE}</code>
${$inbox} Contactez le support si vous pensez que c'est une erreur.`,

    startFirst: `${$warn} Veuillez envoyer /start pour commencer.`,
    unknownCmd: `Utilisez les boutons du menu pour naviguer. 👇`,
    profileBtn: "👤 Profil utilisateur",
    earnBtn: "💰 Gagner",
    withdrawalBtn: "💸 Retrait",
    referralBtn: "👥 Parrainage",
    adultBtn2: "🔞 Adulte",
    movieSeriesBtn: "🎬 Films-Séries",
    setWalletBtn: "💳 Configurer le portefeuille",
    changeLangBtn: "🌐 Changer la langue",
    watchAdsBtn: "📺 Regarder des pubs",
    dailyTasksBtn: "📋 Tâches quotidiennes",
    confirmBtn: "✅ Confirmer",
    changeMethodBtn: "🔄 Changer de méthode",
    cancelBtn: "❌ Annuler",
    mainMenuBtn: "🏠 Menu principal",
    backBtn: "⬅️ Retour",
    confirmWalletMsg: `${$check} <b>Confirmer la sauvegarde du portefeuille</b>\n<code>${SEP}</code>\n💳 Méthode: <b>{method}</b>\n${$mailbox} Adresse: <code>{address}</code>`,
    confirmWdMsg: `${$check} <b>Confirmer le retrait</b>\n<code>${SEP}</code>\n💳 Méthode: <b>{method}</b>\n${$mailbox} Adresse: <code>{address}</code>\n${$dollar} Montant: <b>$ {balance}</b>`,
    walletUpdated: `${$check} <b>Portefeuille mis à jour!</b>\n<code>${SEP}</code>\n💳 Méthode: <b>{method}</b>\n${$mailbox} Adresse: <code>{address}</code>`,
    updateWalletMsg: `💳 <b>Mettre à jour le portefeuille</b>\n<code>${SEP}</code>\n${$phone} Choisissez votre mode de paiement:`,
    nameUpdated: `${$check} <b>Nom mis à jour!</b>\n<code>${SEP}</code>\n${$user} Nouveau nom: <b>{name}</b>`,
    earnCategoryMsg: `${$money} <b>CENTRE DE GAINS</b>\n<code>${SEP}</code>\n${$rocket} Choisissez comment gagner:\n<code>${LINE}</code>\n${$tv} <b>Regarder des pubs</b>  —  +$0.01 par pub\n${$clip} <b>Tâches quotidiennes</b>  —  bonus à la complétion\n${$people} <b>Parrainage</b>  —  gagnez par ami\n<code>${LINE}</code>\n${$zap} <i>Tous les gains sont instantanés</i>`,
  },

  // ─────────────────────────── SPANISH ─────────────────────────────
  es: {
    earn:      "💰 Ganar",
    profile:   "👤 Perfil",
    dailyTask: "📋 Tareas",
    referral:  "👥 Referidos",
    withdraw:  "💸 Retirar",
    language:  "🌐 Idioma",
    adultBot:  "🔞 Adult",
    movieBot:  "🎬 Películas",
    rules:     "📜 Reglas",

    welcome: `${$movie} <b>¡Bienvenido a DesiXX Video Bot!</b>
<code>${SEP}</code>
${$money} Mira anuncios — gana <b>dinero real</b>
${$people} Invita amigos — <b>bono instantáneo</b>
${$clip} Tareas diarias — <b>recompensas extra</b>
${$cashfly} Retira via <b>bKash · Nagad · USDT</b>
<code>${LINE}</code>
${$globe} <b>Elige tu idioma para comenzar:</b>`,

    langSet:    `${$check} <b>¡Idioma establecido en Español!</b>`,
    menuMsg:    `${$shine} <b>Menú Principal</b>\n<code>${LINE}</code>\n${$zap} Presiona un botón:`,
    selectLang: `${$globe} <b>Selecciona tu idioma:</b>`,

    earnMsg: `${$money} <b>CENTRO DE GANANCIAS</b>
<code>${SEP}</code>
${$chart} <b>Progreso:</b>  <code>{bar}</code>  <b>{watched} / {max}</b>
<code>${LINE}</code>
${$dollar} <i>Ganado hoy:</i>   <b>$ {todayEarned}</b>
${$wallet} <i>Tu saldo:</i>     <b>$ {balance}</b>
${$zap} Por anuncio: <b>$0.01</b>  ·  <b>{remaining}</b> restantes
<code>${LINE}</code>`,

    earnDone: `${$check} <b>¡Todos los anuncios de hoy vistos!</b>
<code>${SEP}</code>
${$party} ¡Excelente! Viste todos los <b>{max}</b> anuncios.
${$wallet} <i>Saldo actual:</i> <b>$ {balance}</b>
<code>${LINE}</code>
${$moon} ¡Vuelve <b>mañana</b> para más!`,

    watchAd: "📺 Ver Anuncio  (+$0.01)",
    refresh:  "🔄 Actualizar Saldo",

    adStarted: `${$tv} <b>¡Anuncio Listo — Mira Ahora!</b>
<code>${SEP}</code>
${$clock} Mira por al menos <b>10 segundos</b>
${$check} Luego presiona <b>Lo Ví</b>
<code>${LINE}</code>
<blockquote>${$warn} Presionar rápido = <b>Advertencia emitida</b>
${$lock} Token único — <b>solo un uso</b></blockquote>`,

    watchNow:   "▶️ Abrir Anuncio",
    adVerify:   "✅ Lo Ví",
    adComplete: `${$check} <b>¡+$0.01 acreditado con éxito!</b>
<code>${SEP}</code>
${$wallet} Saldo: <b>$ {balance}</b>
${$chart} Hoy: <b>{watched} / {max}</b> anuncios
<code>${LINE}</code>
${$fire} <i>¡Sigue adelante — cada anuncio cuenta!</i>`,

    adFailed: `${$warn} <b>¡Demasiado rápido — Verificación fallida!</b>
<code>${SEP}</code>
Debes ver el anuncio <b>completo</b> antes de verificar.
<code>${LINE}</code>
<blockquote>${$warn} Advertencia <b>{warnCount} / {warnLimit}</b> emitida.
${$ban} Con <b>{warnLimit}</b> advertencias → <b>ban permanente</b></blockquote>`,

    adCheatBan: `${$ban} <b>Cuenta Permanentemente Bloqueada</b>
<code>${SEP}</code>
<blockquote>Superaste el límite de violaciones permitidas.
Esta decisión es <b>irrevocable</b>.</blockquote>
<code>${LINE}</code>
${$inbox} Contacta al soporte si crees que es un error.`,

    adAlreadyPending: `${$hourglass} <b>Anuncio en progreso</b> — complétalo antes de iniciar uno nuevo.`,
    adsLimit: `${$check} <b>¡Todos los {max} anuncios vistos hoy!</b>
<code>${SEP}</code>
${$wallet} Saldo: <b>$ {balance}</b>
${$moon} ¡Hasta <b>mañana</b>!`,

    channelRequired: `${$lock} <b>Únete Primero a los Canales Requeridos</b>
<code>${SEP}</code>
Debes unirte a <b>todos</b> los canales para comenzar:

{channels}
<code>${LINE}</code>
${$check} Después de unirte, presiona <b>Me Uní a Todos</b>.`,

    joinedVerify:      "✅ Me Uní a Todos",
    channelNotJoined:  "❌ No te has unido aún — únete primero.",
    channelJoinReward: `${$party} ¡Canal unido! <b>+\${reward}</b> acreditado.`,

    profileMsg: `${$user} <b>MI PERFIL</b>
<code>${SEP}</code>
${$idcard} <i>ID de usuario:</i>  <code>{id}</code>
${$user} <i>Nombre:</i>         <b>{name}</b>
${$globe} <i>Idioma:</i>         {lang}
<code>${LINE}</code>
${$wallet} <i>Saldo:</i>             <b>$ {balance}</b>
${$up} <i>Total ganado:</i>     <b>$ {totalEarned}</b>
<code>${LINE}</code>
${$chart} <i>Anuncios hoy:</i>  <b>{adsToday} / {maxAds}</b>
${$people} <i>Referidos:</i>     <b>{referrals}</b>
${$warn} <i>Advertencias:</i>   <b>{warnings} / {warnLimit}</b>
${$cal} <i>Registrado:</i>     <b>{joined}</b>
<code>${LINE}</code>
<blockquote>📜 <b>REGLAS</b>
▸ Máx <b>{maxAds}</b> anuncios por día
▸ Prohibido bots o trampa
▸ Retiro mínimo: <b>$ {minWd}</b>
▸ <b>{warnLimit}</b> violaciones = ban permanente
▸ Una cuenta por persona</blockquote>`,

    referralMsg: `${$people} <b>PROGRAMA DE REFERIDOS</b>
<code>${SEP}</code>
${$shine} Invita amigos — gana <b>$ {refReward}</b> por persona!
<code>${LINE}</code>
${$people} <i>Total referidos:</i>  <b>{count}</b>
${$money} <i>Ganancias ref:</i>    <b>$ {earned}</b>
<code>${LINE}</code>
${$link} <b>Tu enlace de referido:</b>
<code>{link}</code>
<code>${LINE}</code>
${$share} <i>¡Comparte el enlace — gana al instante!</i>`,

    shareLink: "📨 Compartir Enlace",

    dailyTaskMsg: `${$clip} <b>TAREAS DIARIAS</b>
<code>${SEP}</code>
${$sparkle} ¡Completa todas las tareas — desbloquea tu bono!
${$refresh} Se reinicia cada medianoche
<code>${LINE}</code>
{tasks}
<code>${LINE}</code>
${$check} Progreso: <b>{done} / {total}</b>
${$gift} Bono diario: <b>$ {bonus}</b>`,

    taskWatchAds:   `${$tv} Ve <b>{threshold}</b> anuncios hoy  →  <b>+$ {reward}</b>`,
    taskShare:      `${$share} Comparte el bot con 1 amigo  →  <b>+$ {reward}</b>`,
    taskChannel:    `${$mega} Únete: <b>{name}</b>  →  <b>+$ {reward}</b>`,
    taskReferral:   `${$people} Trae 1 nuevo usuario  →  <b>+$ {reward}</b>`,
    taskDonePrefix:    "✅ ",
    taskPendingPrefix: "⬜ ",
    claimBonus:     "🎁 Reclamar Bono Diario",
    bonusClaimed: `${$gift} <b>¡Bono Diario Reclamado!</b>
<code>${SEP}</code>
${$money} Bono: <b>+$ {bonus}</b>
${$wallet} Nuevo saldo: <b>$ {balance}</b>`,

    alreadyClaimed:   `${$check} ¡El bono de hoy ya fue reclamado!`,
    tasksNotComplete: `${$warn} ¡Completa todas las tareas primero!`,
    taskShareBtn:     "📨 Compartir Bot",
    taskVerifyBtn:    "✅ Verificar",

    withdrawMsg: `${$cashfly} <b>RETIRO</b>
<code>${SEP}</code>
${$wallet} Saldo:   <b>$ {balance}</b>
${$warn} Mínimo: <b>$ {minWd}</b>
<code>${LINE}</code>
${$phone} <b>Selecciona método de pago:</b>`,

    withdrawLow: `${$cross} <b>Saldo Insuficiente</b>
<code>${SEP}</code>
Necesitas al menos <b>$ {minWd}</b> para retirar.
${$wallet} <i>Tu saldo:</i> <b>$ {balance}</b>`,

    withdrawAddress:  `${$note} Ingresa tu número de <b>{method}</b> o dirección de billetera:`,
    withdrawConfirm: `${$check} <b>¡Solicitud de retiro enviada!</b>
<code>${SEP}</code>
${$dollar} Monto:    <b>$ {amount}</b>
${$bank} Método:   <b>{method}</b>
${$mailbox} Dirección: <code>{address}</code>
<code>${LINE}</code>
${$clock} Pago procesado en <b>24 horas</b>.`,

    withdrawPending: `${$hourglass} Ya tienes un <b>retiro pendiente</b>. Por favor espera.`,
    withdrawSelect:  "Selecciona el método:",

    banned: `${$ban} <b>Cuenta Bloqueada</b>
<code>${SEP}</code>
<blockquote>Tu cuenta ha sido bloqueada por violar las reglas.</blockquote>
<code>${LINE}</code>
${$inbox} Contacta al soporte si crees que es un error.`,

    startFirst: `${$warn} Por favor envía /start para comenzar.`,
    unknownCmd: `Usa los botones del menú para navegar. 👇`,
    profileBtn: "👤 Perfil de usuario",
    earnBtn: "💰 Ganar",
    withdrawalBtn: "💸 Retirar",
    referralBtn: "👥 Referidos",
    adultBtn2: "🔞 Adulto",
    movieSeriesBtn: "🎬 Películas-Series",
    setWalletBtn: "💳 Configurar billetera",
    changeLangBtn: "🌐 Cambiar idioma",
    watchAdsBtn: "📺 Ver anuncios",
    dailyTasksBtn: "📋 Tareas diarias",
    confirmBtn: "✅ Confirmar",
    changeMethodBtn: "🔄 Cambiar método",
    cancelBtn: "❌ Cancelar",
    mainMenuBtn: "🏠 Menú principal",
    backBtn: "⬅️ Volver",
    confirmWalletMsg: `${$check} <b>Confirmar guardar billetera</b>\n<code>${SEP}</code>\n💳 Método: <b>{method}</b>\n${$mailbox} Dirección: <code>{address}</code>`,
    confirmWdMsg: `${$check} <b>Confirmar retiro</b>\n<code>${SEP}</code>\n💳 Método: <b>{method}</b>\n${$mailbox} Dirección: <code>{address}</code>\n${$dollar} Monto: <b>$ {balance}</b>`,
    walletUpdated: `${$check} <b>¡Billetera actualizada!</b>\n<code>${SEP}</code>\n💳 Método: <b>{method}</b>\n${$mailbox} Dirección: <code>{address}</code>`,
    updateWalletMsg: `💳 <b>Actualizar billetera</b>\n<code>${SEP}</code>\n${$phone} Selecciona método de pago:`,
    nameUpdated: `${$check} <b>¡Nombre actualizado!</b>\n<code>${SEP}</code>\n${$user} Nuevo nombre: <b>{name}</b>`,
    earnCategoryMsg: `${$money} <b>CENTRO DE GANANCIAS</b>\n<code>${SEP}</code>\n${$rocket} Elige cómo ganar hoy:\n<code>${LINE}</code>\n${$tv} <b>Ver anuncios</b>  —  +$0.01 por anuncio\n${$clip} <b>Tareas diarias</b>  —  bono al completar\n${$people} <b>Referidos</b>  —  gana por amigo\n<code>${LINE}</code>\n${$zap} <i>Todas las ganancias son instantáneas</i>`,
  },

  // ─────────────────────────── PORTUGUESE ─────────────────────────
  pt: {
    earn:      "💰 Ganhar",
    profile:   "👤 Perfil",
    dailyTask: "📋 Tarefas",
    referral:  "👥 Indicações",
    withdraw:  "💸 Sacar",
    language:  "🌐 Idioma",
    adultBot:  "🔞 Adult",
    movieBot:  "🎬 Filmes",
    rules:     "📜 Regras",

    welcome: `${$movie} <b>Bem-vindo ao DesiXX Video Bot!</b>
<code>${SEP}</code>
${$money} Assista anúncios — ganhe <b>dinheiro real</b>
${$people} Indique amigos — <b>bônus instantâneo</b>
${$clip} Tarefas diárias — <b>recompensas extras</b>
${$cashfly} Saque via <b>bKash · Nagad · USDT</b>
<code>${LINE}</code>
${$globe} <b>Escolha seu idioma para começar:</b>`,

    langSet:    `${$check} <b>Idioma definido para Português!</b>`,
    menuMsg:    `${$shine} <b>Menu Principal</b>\n<code>${LINE}</code>\n${$zap} Pressione um botão:`,
    selectLang: `${$globe} <b>Escolha seu idioma:</b>`,

    earnMsg: `${$money} <b>CENTRO DE GANHOS</b>
<code>${SEP}</code>
${$chart} <b>Progresso:</b>  <code>{bar}</code>  <b>{watched} / {max}</b>
<code>${LINE}</code>
${$dollar} <i>Ganho hoje:</i>   <b>$ {todayEarned}</b>
${$wallet} <i>Seu saldo:</i>   <b>$ {balance}</b>
${$zap} Por anúncio: <b>$0.01</b>  ·  <b>{remaining}</b> restantes
<code>${LINE}</code>`,

    earnDone: `${$check} <b>Todos os anúncios de hoje vistos!</b>
<code>${SEP}</code>
${$party} Excelente! Você viu todos os <b>{max}</b> anúncios.
${$wallet} <i>Saldo atual:</i> <b>$ {balance}</b>
<code>${LINE}</code>
${$moon} Volte <b>amanhã</b> para mais!`,

    watchAd: "📺 Ver Anúncio  (+$0.01)",
    refresh:  "🔄 Atualizar Saldo",

    adStarted: `${$tv} <b>Anúncio Pronto — Assista Agora!</b>
<code>${SEP}</code>
${$clock} Assista por pelo menos <b>10 segundos</b>
${$check} Depois pressione <b>Eu Assisti</b>
<code>${LINE}</code>
<blockquote>${$warn} Pressionar cedo = <b>Aviso emitido</b>
${$lock} Token único — <b>uso único</b></blockquote>`,

    watchNow:   "▶️ Abrir Anúncio",
    adVerify:   "✅ Eu Assisti",
    adComplete: `${$check} <b>+$0.01 creditado com sucesso!</b>
<code>${SEP}</code>
${$wallet} Saldo: <b>$ {balance}</b>
${$chart} Hoje: <b>{watched} / {max}</b> anúncios
<code>${LINE}</code>
${$fire} <i>Continue — cada anúncio conta!</i>`,

    adFailed: `${$warn} <b>Rápido demais — Verificação falhou!</b>
<code>${SEP}</code>
Você deve assistir o anúncio <b>completo</b> antes de verificar.
<code>${LINE}</code>
<blockquote>${$warn} Aviso <b>{warnCount} / {warnLimit}</b> emitido.
${$ban} Com <b>{warnLimit}</b> avisos → <b>banimento permanente</b></blockquote>`,

    adCheatBan: `${$ban} <b>Conta Permanentemente Banida</b>
<code>${SEP}</code>
<blockquote>Você excedeu o limite de violações permitidas.
Esta decisão é <b>irrevogável</b>.</blockquote>
<code>${LINE}</code>
${$inbox} Entre em contato com o suporte se achar que é um erro.`,

    adAlreadyPending: `${$hourglass} <b>Anúncio em andamento</b> — conclua antes de iniciar um novo.`,
    adsLimit: `${$check} <b>Todos os {max} anúncios vistos hoje!</b>
<code>${SEP}</code>
${$wallet} Saldo: <b>$ {balance}</b>
${$moon} Até <b>amanhã</b>!`,

    channelRequired: `${$lock} <b>Junte-se Primeiro aos Canais Necessários</b>
<code>${SEP}</code>
Você deve entrar em <b>todos</b> os canais para começar:

{channels}
<code>${LINE}</code>
${$check} Após entrar, pressione <b>Entrei em Todos</b>.`,

    joinedVerify:      "✅ Entrei em Todos",
    channelNotJoined:  "❌ Ainda não entrou — entre primeiro.",
    channelJoinReward: `${$party} Entrou no canal! <b>+\${reward}</b> creditado.`,

    profileMsg: `${$user} <b>MEU PERFIL</b>
<code>${SEP}</code>
${$idcard} <i>ID do usuário:</i>  <code>{id}</code>
${$user} <i>Nome:</i>           <b>{name}</b>
${$globe} <i>Idioma:</i>         {lang}
<code>${LINE}</code>
${$wallet} <i>Saldo:</i>             <b>$ {balance}</b>
${$up} <i>Total ganho:</i>     <b>$ {totalEarned}</b>
<code>${LINE}</code>
${$chart} <i>Anúncios hoje:</i> <b>{adsToday} / {maxAds}</b>
${$people} <i>Indicações:</i>   <b>{referrals}</b>
${$warn} <i>Avisos:</i>        <b>{warnings} / {warnLimit}</b>
${$cal} <i>Registrado:</i>    <b>{joined}</b>
<code>${LINE}</code>
<blockquote>📜 <b>REGRAS</b>
▸ Máx <b>{maxAds}</b> anúncios por dia
▸ Proibido bots ou trapaça
▸ Saque mínimo: <b>$ {minWd}</b>
▸ <b>{warnLimit}</b> violações = banimento permanente
▸ Uma conta por pessoa</blockquote>`,

    referralMsg: `${$people} <b>PROGRAMA DE INDICAÇÕES</b>
<code>${SEP}</code>
${$shine} Indique amigos — ganhe <b>$ {refReward}</b> por pessoa!
<code>${LINE}</code>
${$people} <i>Total indicações:</i>  <b>{count}</b>
${$money} <i>Ganhos indicação:</i> <b>$ {earned}</b>
<code>${LINE}</code>
${$link} <b>Seu link de indicação:</b>
<code>{link}</code>
<code>${LINE}</code>
${$share} <i>Compartilhe o link — ganhe instantaneamente!</i>`,

    shareLink: "📨 Compartilhar Link",

    dailyTaskMsg: `${$clip} <b>TAREFAS DIÁRIAS</b>
<code>${SEP}</code>
${$sparkle} Complete todas as tarefas — desbloqueie seu bônus!
${$refresh} Reinicia toda meia-noite
<code>${LINE}</code>
{tasks}
<code>${LINE}</code>
${$check} Progresso: <b>{done} / {total}</b>
${$gift} Bônus diário: <b>$ {bonus}</b>`,

    taskWatchAds:   `${$tv} Assista <b>{threshold}</b> anúncios hoje  →  <b>+$ {reward}</b>`,
    taskShare:      `${$share} Compartilhe o bot com 1 amigo  →  <b>+$ {reward}</b>`,
    taskChannel:    `${$mega} Entrar: <b>{name}</b>  →  <b>+$ {reward}</b>`,
    taskReferral:   `${$people} Traga 1 novo usuário  →  <b>+$ {reward}</b>`,
    taskDonePrefix:    "✅ ",
    taskPendingPrefix: "⬜ ",
    claimBonus:     "🎁 Resgatar Bônus Diário",
    bonusClaimed: `${$gift} <b>Bônus Diário Resgatado!</b>
<code>${SEP}</code>
${$money} Bônus: <b>+$ {bonus}</b>
${$wallet} Novo saldo: <b>$ {balance}</b>`,

    alreadyClaimed:   `${$check} O bônus de hoje já foi resgatado!`,
    tasksNotComplete: `${$warn} Complete todas as tarefas primeiro!`,
    taskShareBtn:     "📨 Compartilhar Bot",
    taskVerifyBtn:    "✅ Verificar",

    withdrawMsg: `${$cashfly} <b>SAQUE</b>
<code>${SEP}</code>
${$wallet} Saldo:   <b>$ {balance}</b>
${$warn} Mínimo: <b>$ {minWd}</b>
<code>${LINE}</code>
${$phone} <b>Selecione método de pagamento:</b>`,

    withdrawLow: `${$cross} <b>Saldo Insuficiente</b>
<code>${SEP}</code>
Precisa de pelo menos <b>$ {minWd}</b> para sacar.
${$wallet} <i>Seu saldo:</i> <b>$ {balance}</b>`,

    withdrawAddress:  `${$note} Digite seu número <b>{method}</b> ou endereço de carteira:`,
    withdrawConfirm: `${$check} <b>Solicitação de saque enviada!</b>
<code>${SEP}</code>
${$dollar} Valor:    <b>$ {amount}</b>
${$bank} Método:   <b>{method}</b>
${$mailbox} Endereço: <code>{address}</code>
<code>${LINE}</code>
${$clock} Pagamento processado em <b>24 horas</b>.`,

    withdrawPending: `${$hourglass} Você já tem um <b>saque pendente</b>. Aguarde o processamento.`,
    withdrawSelect:  "Selecione o método:",

    banned: `${$ban} <b>Conta Banida</b>
<code>${SEP}</code>
<blockquote>Sua conta foi banida por violar as regras.</blockquote>
<code>${LINE}</code>
${$inbox} Entre em contato com o suporte se achar que é um erro.`,

    startFirst: `${$warn} Por favor envie /start para começar.`,
    unknownCmd: `Use os botões do menu para navegar. 👇`,
    profileBtn: "👤 Perfil do Usuário",
    earnBtn: "💰 Ganhar",
    withdrawalBtn: "💸 Saque",
    referralBtn: "👥 Indicações",
    adultBtn2: "🔞 Adulto",
    movieSeriesBtn: "🎬 Filmes-Séries",
    setWalletBtn: "💳 Definir Carteira",
    changeLangBtn: "🌐 Mudar Idioma",
    watchAdsBtn: "📺 Ver Anúncios",
    dailyTasksBtn: "📋 Tarefas Diárias",
    confirmBtn: "✅ Confirmar",
    changeMethodBtn: "🔄 Mudar Método",
    cancelBtn: "❌ Cancelar",
    mainMenuBtn: "🏠 Menu Principal",
    backBtn: "⬅️ Voltar",
    confirmWalletMsg: `${$check} <b>Confirmar salvar carteira</b>\n<code>${SEP}</code>\n💳 Método: <b>{method}</b>\n${$mailbox} Endereço: <code>{address}</code>`,
    confirmWdMsg: `${$check} <b>Confirmar saque</b>\n<code>${SEP}</code>\n💳 Método: <b>{method}</b>\n${$mailbox} Endereço: <code>{address}</code>\n${$dollar} Valor: <b>$ {balance}</b>`,
    walletUpdated: `${$check} <b>Carteira atualizada!</b>\n<code>${SEP}</code>\n💳 Método: <b>{method}</b>\n${$mailbox} Endereço: <code>{address}</code>`,
    updateWalletMsg: `💳 <b>Atualizar Carteira</b>\n<code>${SEP}</code>\n${$phone} Selecione método de pagamento:`,
    nameUpdated: `${$check} <b>Nome atualizado!</b>\n<code>${SEP}</code>\n${$user} Novo nome: <b>{name}</b>`,
    earnCategoryMsg: `${$money} <b>Centro de ganhos</b>\n<code>${SEP}</code>\n${$rocket} Escolha como ganhar hoje:\n<code>${LINE}</code>\n${$tv} <b>Ver anúncios</b>  —  +$0.01 por anúncio\n${$clip} <b>Tarefas diárias</b>  —  bonus ao completar\n${$people} <b>Indicações</b>  —  ganhe por amigo\n<code>${LINE}</code>\n${$zap} <i>Todos os ganhos são instantâneos</i>`,
  },
};

export function tr_(lang: Lang, key: string, vars: Record<string, string | number> = {}): string {
  let msg = t[lang]?.[key] ?? t["en"]?.[key] ?? key;
  for (const [k, v] of Object.entries(vars)) {
    const safe = typeof v === "string" ? escHtml(v) : String(v);
    msg = msg.replace(new RegExp(`\\{${k}\\}`, "g"), safe);
  }
  return msg;
}
